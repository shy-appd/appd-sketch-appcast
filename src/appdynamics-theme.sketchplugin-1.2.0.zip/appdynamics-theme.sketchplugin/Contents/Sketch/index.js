var globalThis = this;
var global = this;
function __skpm_run (key, context) {
  globalThis.context = context;
  try {

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/index.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./node_modules/@appd/ui-assets/fesm5/appd-ui-assets.js":
/*!**************************************************************!*\
  !*** ./node_modules/@appd/ui-assets/fesm5/appd-ui-assets.js ***!
  \**************************************************************/
/*! exports provided: DesignTokenColors, DesignTokens, IconPathMap, LevitateDarkTheme, LevitateDarkThemeMapping, ParticleIcon */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DesignTokenColors", function() { return DesignTokenColors; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DesignTokens", function() { return DesignTokens; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "IconPathMap", function() { return IconPathMap; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LevitateDarkTheme", function() { return LevitateDarkTheme; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LevitateDarkThemeMapping", function() { return LevitateDarkThemeMapping; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ParticleIcon", function() { return ParticleIcon; });
var IconPathMap = {
    // actions
    "add": "~@appd/ui-assets/inline-images/actions/add.svg",
    "addToDash": "~@appd/ui-assets/inline-images/actions/addToDash.svg",
    "addWidget": "~@appd/ui-assets/inline-images/actions/addWidget.svg",
    "adjust": "~@appd/ui-assets/inline-images/actions/adjust.svg",
    "align": "~@appd/ui-assets/inline-images/actions/align.svg",
    "alignVerticalBottom": "~@appd/ui-assets/inline-images/actions/alignVerticalBottom.svg",
    "alignVerticalCenter": "~@appd/ui-assets/inline-images/actions/alignVerticalCenter.svg",
    "alignVerticalTop": "~@appd/ui-assets/inline-images/actions/alignVerticalTop.svg",
    "analyze": "~@appd/ui-assets/inline-images/actions/analyze.svg",
    "archive": "~@appd/ui-assets/inline-images/actions/archive.svg",
    "associateTierNode": "~@appd/ui-assets/inline-images/actions/associateTierNode.svg",
    "autoFillFlowMap": "~@appd/ui-assets/inline-images/actions/autoFillFlowMap.svg",
    "autoLayoutFlowMap": "~@appd/ui-assets/inline-images/actions/autoLayoutFlowMap.svg",
    "autoRefresh": "~@appd/ui-assets/inline-images/actions/autoRefresh.svg",
    "bottomPanel": "~@appd/ui-assets/inline-images/actions/bottomPanel.svg",
    "calendar": "~@appd/ui-assets/inline-images/actions/calendar.svg",
    "cancel": "~@appd/ui-assets/inline-images/actions/cancel.svg",
    "cardView": "~@appd/ui-assets/inline-images/actions/cardView.svg",
    "circularViewFlowMap": "~@appd/ui-assets/inline-images/actions/circularViewFlowMap.svg",
    "clearConsole": "~@appd/ui-assets/inline-images/actions/clearConsole.svg",
    "compactView": "~@appd/ui-assets/inline-images/actions/compactView.svg",
    "configure": "~@appd/ui-assets/inline-images/actions/configure.svg",
    "copy": "~@appd/ui-assets/inline-images/actions/copy.svg",
    "createPolicyManually": "~@appd/ui-assets/inline-images/actions/createPolicyManually.svg",
    "delete": "~@appd/ui-assets/inline-images/actions/delete.svg",
    "disable": "~@appd/ui-assets/inline-images/actions/disable.svg",
    "download": "~@appd/ui-assets/inline-images/actions/download.svg",
    "duplicate": "~@appd/ui-assets/inline-images/actions/duplicate.svg",
    "edit": "~@appd/ui-assets/inline-images/actions/edit.svg",
    "enabled": "~@appd/ui-assets/inline-images/actions/enabled.svg",
    "export": "~@appd/ui-assets/inline-images/actions/export.svg",
    "feedback": "~@appd/ui-assets/inline-images/actions/feedback.svg",
    "filter": "~@appd/ui-assets/inline-images/actions/filter.svg",
    "findSnapEvent": "~@appd/ui-assets/inline-images/actions/findSnapEvent.svg",
    "generateSessions": "~@appd/ui-assets/inline-images/actions/generateSessions.svg",
    "gridView": "~@appd/ui-assets/inline-images/actions/gridView.svg",
    "group": "~@appd/ui-assets/inline-images/actions/group.svg",
    "help": "~@appd/ui-assets/inline-images/actions/help.svg",
    "import": "~@appd/ui-assets/inline-images/actions/import.svg",
    "importApp": "~@appd/ui-assets/inline-images/actions/importApp.svg",
    "info": "~@appd/ui-assets/inline-images/actions/info.svg",
    "launchInfo": "~@appd/ui-assets/inline-images/actions/launchInfo.svg",
    "linearView": "~@appd/ui-assets/inline-images/actions/linearView.svg",
    "link": "~@appd/ui-assets/inline-images/actions/link.svg",
    "logarithmicView": "~@appd/ui-assets/inline-images/actions/logarithmicView.svg",
    "logout": "~@appd/ui-assets/inline-images/actions/logout.svg",
    "minus": "~@appd/ui-assets/inline-images/actions/minus.svg",
    "order": "~@appd/ui-assets/inline-images/actions/order.svg",
    "paste": "~@appd/ui-assets/inline-images/actions/paste.svg",
    "play": "~@appd/ui-assets/inline-images/actions/play.svg",
    "popOut": "~@appd/ui-assets/inline-images/actions/popOut.svg",
    "redo": "~@appd/ui-assets/inline-images/actions/redo.svg",
    "refresh": "~@appd/ui-assets/inline-images/actions/refresh.svg",
    "save": "~@appd/ui-assets/inline-images/actions/save.svg",
    "saveAs": "~@appd/ui-assets/inline-images/actions/saveAs.svg",
    "search": "~@appd/ui-assets/inline-images/actions/search.svg",
    "searchSnapshot": "~@appd/ui-assets/inline-images/actions/searchSnapshot.svg",
    "share": "~@appd/ui-assets/inline-images/actions/share.svg",
    "sidePanel": "~@appd/ui-assets/inline-images/actions/sidePanel.svg",
    "stop": "~@appd/ui-assets/inline-images/actions/stop.svg",
    "symbolicate": "~@appd/ui-assets/inline-images/actions/symbolicate.svg",
    "testEmail": "~@appd/ui-assets/inline-images/actions/testEmail.svg",
    "testHttpRequest": "~@appd/ui-assets/inline-images/actions/testHttpRequest.svg",
    "textAlignCenter": "~@appd/ui-assets/inline-images/actions/textAlignCenter.svg",
    "textAlignLeft": "~@appd/ui-assets/inline-images/actions/textAlignLeft.svg",
    "textAlignRight": "~@appd/ui-assets/inline-images/actions/textAlignRight.svg",
    "thumbDown": "~@appd/ui-assets/inline-images/actions/thumbDown.svg",
    "thumbUp": "~@appd/ui-assets/inline-images/actions/thumbUp.svg",
    "treeView": "~@appd/ui-assets/inline-images/actions/treeView.svg",
    "undo": "~@appd/ui-assets/inline-images/actions/undo.svg",
    "ungroup": "~@appd/ui-assets/inline-images/actions/ungroup.svg",
    "upgrade": "~@appd/ui-assets/inline-images/actions/upgrade.svg",
    "upload": "~@appd/ui-assets/inline-images/actions/upload.svg",
    "viewDetails": "~@appd/ui-assets/inline-images/actions/viewDetails.svg",
    "viewDiagnosticSession": "~@appd/ui-assets/inline-images/actions/viewDiagnosticSession.svg",
    "viewMobile": "~@appd/ui-assets/inline-images/actions/viewMobile.svg",
    "viewSnapshot": "~@appd/ui-assets/inline-images/actions/viewSnapshot.svg",
    // agentTypes
    "aws": "~@appd/ui-assets/inline-images/agentTypes/aws.svg",
    "googleCloud": "~@appd/ui-assets/inline-images/agentTypes/googleCloud.svg",
    "microsoftAzure": "~@appd/ui-assets/inline-images/agentTypes/microsoftAzure.svg",
    "thousandEyes": "~@appd/ui-assets/inline-images/agentTypes/thousandEyes.svg",
    // browsers
    "chrome": "~@appd/ui-assets/inline-images/browsers/chrome.svg",
    "firefox": "~@appd/ui-assets/inline-images/browsers/firefox.svg",
    "ie": "~@appd/ui-assets/inline-images/browsers/ie.svg",
    "netscape": "~@appd/ui-assets/inline-images/browsers/netscape.svg",
    "opera": "~@appd/ui-assets/inline-images/browsers/opera.svg",
    "other": "~@appd/ui-assets/inline-images/browsers/other.svg",
    "safari": "~@appd/ui-assets/inline-images/browsers/safari.svg",
    // chartTypes
    "area": "~@appd/ui-assets/inline-images/chartTypes/area.svg",
    "circlePack": "~@appd/ui-assets/inline-images/chartTypes/circlePack.svg",
    "column": "~@appd/ui-assets/inline-images/chartTypes/column.svg",
    "donut": "~@appd/ui-assets/inline-images/chartTypes/donut.svg",
    "funnel": "~@appd/ui-assets/inline-images/chartTypes/funnel.svg",
    "histogram": "~@appd/ui-assets/inline-images/chartTypes/histogram.svg",
    "line": "~@appd/ui-assets/inline-images/chartTypes/line.svg",
    "list": "~@appd/ui-assets/inline-images/chartTypes/list.svg",
    "numeric": "~@appd/ui-assets/inline-images/chartTypes/numeric.svg",
    "pie": "~@appd/ui-assets/inline-images/chartTypes/pie.svg",
    "scatter": "~@appd/ui-assets/inline-images/chartTypes/scatter.svg",
    "table": "~@appd/ui-assets/inline-images/chartTypes/table.svg",
    "treeMap": "~@appd/ui-assets/inline-images/chartTypes/treeMap.svg",
    "worldMap": "~@appd/ui-assets/inline-images/chartTypes/worldMap.svg",
    // carousel
    "arrowBackDarkViolet": "~@appd/ui-assets/inline-images/components/carousel/arrowBackDarkViolet.svg",
    "arrowForwardDarkViolet": "~@appd/ui-assets/inline-images/components/carousel/arrowForwardDarkViolet.svg",
    // checkBox
    "indetermined": "~@appd/ui-assets/inline-images/components/checkBox/indetermined.svg",
    "indeterminedDisabled": "~@appd/ui-assets/inline-images/components/checkBox/indeterminedDisabled.svg",
    "indeterminedFocused": "~@appd/ui-assets/inline-images/components/checkBox/indeterminedFocused.svg",
    "indeterminedHover": "~@appd/ui-assets/inline-images/components/checkBox/indeterminedHover.svg",
    "notSelected": "~@appd/ui-assets/inline-images/components/checkBox/notSelected.svg",
    "notSelectedDisabled": "~@appd/ui-assets/inline-images/components/checkBox/notSelectedDisabled.svg",
    "notSelectedFocused": "~@appd/ui-assets/inline-images/components/checkBox/notSelectedFocused.svg",
    "notSelectedHover": "~@appd/ui-assets/inline-images/components/checkBox/notSelectedHover.svg",
    "selected": "~@appd/ui-assets/inline-images/components/checkBox/selected.svg",
    "selectedDisabled": "~@appd/ui-assets/inline-images/components/checkBox/selectedDisabled.svg",
    "selectedFocused": "~@appd/ui-assets/inline-images/components/checkBox/selectedFocused.svg",
    "selectedHover": "~@appd/ui-assets/inline-images/components/checkBox/selectedHover.svg",
    // gauge
    "baseline": "~@appd/ui-assets/inline-images/components/gauge/baseline.svg",
    "triangleMarker": "~@appd/ui-assets/inline-images/components/gauge/triangleMarker.svg",
    "triangleMarkerSmall": "~@appd/ui-assets/inline-images/components/gauge/triangleMarkerSmall.svg",
    // journeyMap
    "criticalOutline": "~@appd/ui-assets/inline-images/components/journeyMap/criticalOutline.svg",
    "infoMessageOutline": "~@appd/ui-assets/inline-images/components/journeyMap/infoMessageOutline.svg",
    "normalOutline": "~@appd/ui-assets/inline-images/components/journeyMap/normalOutline.svg",
    "stallOutline": "~@appd/ui-assets/inline-images/components/journeyMap/stallOutline.svg",
    "verySlowOutline": "~@appd/ui-assets/inline-images/components/journeyMap/verySlowOutline.svg",
    "warningOutline": "~@appd/ui-assets/inline-images/components/journeyMap/warningOutline.svg",
    // numberfield
    "numberArrowDropDown": "~@appd/ui-assets/inline-images/components/numberfield/numberArrowDropDown.svg",
    "numberArrowDropUp": "~@appd/ui-assets/inline-images/components/numberfield/numberArrowDropUp.svg",
    // splitter
    "dragHandleHorizontal": "~@appd/ui-assets/inline-images/components/splitter/dragHandleHorizontal.svg",
    "dragHandleVertical": "~@appd/ui-assets/inline-images/components/splitter/dragHandleVertical.svg",
    // timeScrubber
    "scrubberDragHandle": "~@appd/ui-assets/inline-images/components/timeScrubber/scrubberDragHandle.svg",
    // wizard
    "errorDefault": "~@appd/ui-assets/inline-images/components/wizard/errorDefault.svg",
    "errorSmall": "~@appd/ui-assets/inline-images/components/wizard/errorSmall.svg",
    // dataTypes
    "boolean": "~@appd/ui-assets/inline-images/dataTypes/boolean.svg",
    "currency": "~@appd/ui-assets/inline-images/dataTypes/currency.svg",
    "number": "~@appd/ui-assets/inline-images/dataTypes/number.svg",
    "object": "~@appd/ui-assets/inline-images/dataTypes/object.svg",
    "text": "~@appd/ui-assets/inline-images/dataTypes/text.svg",
    // health
    "critical": "~@appd/ui-assets/inline-images/health/critical.svg",
    "criticalThemable": "~@appd/ui-assets/inline-images/health/criticalThemable.svg",
    "infoMessage": "~@appd/ui-assets/inline-images/health/infoMessage.svg",
    "infoMessageThemable": "~@appd/ui-assets/inline-images/health/infoMessageThemable.svg",
    "normal": "~@appd/ui-assets/inline-images/health/normal.svg",
    "normalThemable": "~@appd/ui-assets/inline-images/health/normalThemable.svg",
    "stall": "~@appd/ui-assets/inline-images/health/stall.svg",
    "verySlow": "~@appd/ui-assets/inline-images/health/verySlow.svg",
    "warning": "~@appd/ui-assets/inline-images/health/warning.svg",
    "warning3": "~@appd/ui-assets/inline-images/health/warning3.svg",
    "warningThemable": "~@appd/ui-assets/inline-images/health/warningThemable.svg",
    // languages
    "cpp": "~@appd/ui-assets/inline-images/languages/cpp.svg",
    "elixir": "~@appd/ui-assets/inline-images/languages/elixir.svg",
    "erlang": "~@appd/ui-assets/inline-images/languages/erlang.svg",
    "goLang": "~@appd/ui-assets/inline-images/languages/goLang.svg",
    "java": "~@appd/ui-assets/inline-images/languages/java.svg",
    "net": "~@appd/ui-assets/inline-images/languages/net.svg",
    "nodeJs": "~@appd/ui-assets/inline-images/languages/nodeJs.svg",
    "php": "~@appd/ui-assets/inline-images/languages/php.svg",
    "python": "~@appd/ui-assets/inline-images/languages/python.svg",
    "ruby": "~@appd/ui-assets/inline-images/languages/ruby.svg",
    "rust": "~@appd/ui-assets/inline-images/languages/rust.svg",
    // locations
    "actionSuspended": "~@appd/ui-assets/inline-images/locations/actionSuspended.svg",
    "actions": "~@appd/ui-assets/inline-images/locations/actions.svg",
    "alertAndRespond": "~@appd/ui-assets/inline-images/locations/alertAndRespond.svg",
    "anomalyDetection": "~@appd/ui-assets/inline-images/locations/anomalyDetection.svg",
    "apm": "~@appd/ui-assets/inline-images/locations/apm.svg",
    "applicationServers": "~@appd/ui-assets/inline-images/locations/applicationServers.svg",
    "biq": "~@appd/ui-assets/inline-images/locations/biq.svg",
    "bts": "~@appd/ui-assets/inline-images/locations/bts.svg",
    "businessJourneys": "~@appd/ui-assets/inline-images/locations/businessJourneys.svg",
    "cloudAutoScaling": "~@appd/ui-assets/inline-images/locations/cloudAutoScaling.svg",
    "cloudBackend": "~@appd/ui-assets/inline-images/locations/cloudBackend.svg",
    "codeIssues": "~@appd/ui-assets/inline-images/locations/codeIssues.svg",
    "community": "~@appd/ui-assets/inline-images/locations/community.svg",
    "comparison": "~@appd/ui-assets/inline-images/locations/comparison.svg",
    "container": "~@appd/ui-assets/inline-images/locations/container.svg",
    "dashboards": "~@appd/ui-assets/inline-images/locations/dashboards.svg",
    "dataPipeline": "~@appd/ui-assets/inline-images/locations/dataPipeline.svg",
    "diagnosticSessions": "~@appd/ui-assets/inline-images/locations/diagnosticSessions.svg",
    "docs": "~@appd/ui-assets/inline-images/locations/docs.svg",
    "emailAction": "~@appd/ui-assets/inline-images/locations/emailAction.svg",
    "emailDigest": "~@appd/ui-assets/inline-images/locations/emailDigest.svg",
    "eum": "~@appd/ui-assets/inline-images/locations/eum.svg",
    "eumCloud": "~@appd/ui-assets/inline-images/locations/eumCloud.svg",
    "eumSessions": "~@appd/ui-assets/inline-images/locations/eumSessions.svg",
    "eumWebApp": "~@appd/ui-assets/inline-images/locations/eumWebApp.svg",
    "events": "~@appd/ui-assets/inline-images/locations/events.svg",
    "eventsService": "~@appd/ui-assets/inline-images/locations/eventsService.svg",
    "experienceLevelManagement": "~@appd/ui-assets/inline-images/locations/experienceLevelManagement.svg",
    "healthRuleViolation": "~@appd/ui-assets/inline-images/locations/healthRuleViolation.svg",
    "healthRules": "~@appd/ui-assets/inline-images/locations/healthRules.svg",
    "helpCenter": "~@appd/ui-assets/inline-images/locations/helpCenter.svg",
    "home": "~@appd/ui-assets/inline-images/locations/home.svg",
    "host": "~@appd/ui-assets/inline-images/locations/host.svg",
    "httpAction": "~@appd/ui-assets/inline-images/locations/httpAction.svg",
    "javascriptErrors": "~@appd/ui-assets/inline-images/locations/javascriptErrors.svg",
    "jobsManager": "~@appd/ui-assets/inline-images/locations/jobsManager.svg",
    "journeyMap": "~@appd/ui-assets/inline-images/locations/journeyMap.svg",
    "logAnalytics": "~@appd/ui-assets/inline-images/locations/logAnalytics.svg",
    "metricBrowser": "~@appd/ui-assets/inline-images/locations/metricBrowser.svg",
    "mobileApp": "~@appd/ui-assets/inline-images/locations/mobileApp.svg",
    "networkRequests": "~@appd/ui-assets/inline-images/locations/networkRequests.svg",
    "onDemandPageSnap": "~@appd/ui-assets/inline-images/locations/onDemandPageSnap.svg",
    "pages": "~@appd/ui-assets/inline-images/locations/pages.svg",
    "pagesAndAjax": "~@appd/ui-assets/inline-images/locations/pagesAndAjax.svg",
    "policies": "~@appd/ui-assets/inline-images/locations/policies.svg",
    "remoteServices": "~@appd/ui-assets/inline-images/locations/remoteServices.svg",
    "reports": "~@appd/ui-assets/inline-images/locations/reports.svg",
    "resourcePerformance": "~@appd/ui-assets/inline-images/locations/resourcePerformance.svg",
    "searches": "~@appd/ui-assets/inline-images/locations/searches.svg",
    "servers": "~@appd/ui-assets/inline-images/locations/servers.svg",
    "serviceAvailability": "~@appd/ui-assets/inline-images/locations/serviceAvailability.svg",
    "serviceEndPoint": "~@appd/ui-assets/inline-images/locations/serviceEndPoint.svg",
    "synthetic": "~@appd/ui-assets/inline-images/locations/synthetic.svg",
    "syntheticSessions": "~@appd/ui-assets/inline-images/locations/syntheticSessions.svg",
    "tierAndNode": "~@appd/ui-assets/inline-images/locations/tierAndNode.svg",
    "tools": "~@appd/ui-assets/inline-images/locations/tools.svg",
    "transactionAnalytics": "~@appd/ui-assets/inline-images/locations/transactionAnalytics.svg",
    "troubleshoot": "~@appd/ui-assets/inline-images/locations/troubleshoot.svg",
    "userAnalytics": "~@appd/ui-assets/inline-images/locations/userAnalytics.svg",
    "videos": "~@appd/ui-assets/inline-images/locations/videos.svg",
    "virtualPages": "~@appd/ui-assets/inline-images/locations/virtualPages.svg",
    // logo
    "AppDynamicsLogo": "~@appd/ui-assets/inline-images/logo/AppDynamicsLogo.svg",
    "AppDynamicsLogo_emblem": "~@appd/ui-assets/inline-images/logo/AppDynamicsLogo_emblem.svg",
    "AppDynamicsLogo_emblem_black": "~@appd/ui-assets/inline-images/logo/AppDynamicsLogo_emblem_black.svg",
    "AppDynamicsLogo_emblem_deepSpace": "~@appd/ui-assets/inline-images/logo/AppDynamicsLogo_emblem_deepSpace.svg",
    "AppDynamicsLogo_emblem_electricIndigo": "~@appd/ui-assets/inline-images/logo/AppDynamicsLogo_emblem_electricIndigo.svg",
    "AppDynamicsLogo_emblem_white": "~@appd/ui-assets/inline-images/logo/AppDynamicsLogo_emblem_white.svg",
    "AppDynamicsLogo_full_black": "~@appd/ui-assets/inline-images/logo/AppDynamicsLogo_full_black.svg",
    "AppDynamicsLogo_full_deepSpace": "~@appd/ui-assets/inline-images/logo/AppDynamicsLogo_full_deepSpace.svg",
    "AppDynamicsLogo_full_electricIndigo": "~@appd/ui-assets/inline-images/logo/AppDynamicsLogo_full_electricIndigo.svg",
    "AppDynamicsLogo_full_white": "~@appd/ui-assets/inline-images/logo/AppDynamicsLogo_full_white.svg",
    "TE-Logo-Alternate": "~@appd/ui-assets/inline-images/logo/TE-Logo-Alternate.svg",
    // navigation
    "arrowBack": "~@appd/ui-assets/inline-images/navigation/arrowBack.svg",
    "arrowDown": "~@appd/ui-assets/inline-images/navigation/arrowDown.svg",
    "arrowDropDown": "~@appd/ui-assets/inline-images/navigation/arrowDropDown.svg",
    "arrowDropUp": "~@appd/ui-assets/inline-images/navigation/arrowDropUp.svg",
    "arrowForward": "~@appd/ui-assets/inline-images/navigation/arrowForward.svg",
    "arrowUp": "~@appd/ui-assets/inline-images/navigation/arrowUp.svg",
    "chevronDown": "~@appd/ui-assets/inline-images/navigation/chevronDown.svg",
    "chevronLeft": "~@appd/ui-assets/inline-images/navigation/chevronLeft.svg",
    "chevronRight": "~@appd/ui-assets/inline-images/navigation/chevronRight.svg",
    "chevronUp": "~@appd/ui-assets/inline-images/navigation/chevronUp.svg",
    "close": "~@appd/ui-assets/inline-images/navigation/close.svg",
    "doubleChevronLeft": "~@appd/ui-assets/inline-images/navigation/doubleChevronLeft.svg",
    "doubleChevronRight": "~@appd/ui-assets/inline-images/navigation/doubleChevronRight.svg",
    "dragHandle": "~@appd/ui-assets/inline-images/navigation/dragHandle.svg",
    "dragIndicator": "~@appd/ui-assets/inline-images/navigation/dragIndicator.svg",
    "firstPage": "~@appd/ui-assets/inline-images/navigation/firstPage.svg",
    "fullScreen": "~@appd/ui-assets/inline-images/navigation/fullScreen.svg",
    "fullScreenExit": "~@appd/ui-assets/inline-images/navigation/fullScreenExit.svg",
    "lastPage": "~@appd/ui-assets/inline-images/navigation/lastPage.svg",
    "menu": "~@appd/ui-assets/inline-images/navigation/menu.svg",
    "minimize": "~@appd/ui-assets/inline-images/navigation/minimize.svg",
    "moreHorizontal": "~@appd/ui-assets/inline-images/navigation/moreHorizontal.svg",
    "moreVertical": "~@appd/ui-assets/inline-images/navigation/moreVertical.svg",
    // objects
    "activity": "~@appd/ui-assets/inline-images/objects/activity.svg",
    "amazonS3": "~@appd/ui-assets/inline-images/objects/amazonS3.svg",
    "amazonSns": "~@appd/ui-assets/inline-images/objects/amazonSns.svg",
    "bidirectedTraffic": "~@appd/ui-assets/inline-images/objects/bidirectedTraffic.svg",
    "blitz": "~@appd/ui-assets/inline-images/objects/blitz.svg",
    "breadcrumb": "~@appd/ui-assets/inline-images/objects/breadcrumb.svg",
    "callGraphFull": "~@appd/ui-assets/inline-images/objects/callGraphFull.svg",
    "callGraphPartial": "~@appd/ui-assets/inline-images/objects/callGraphPartial.svg",
    "callGraphPossible": "~@appd/ui-assets/inline-images/objects/callGraphPossible.svg",
    "callIncoming": "~@appd/ui-assets/inline-images/objects/callIncoming.svg",
    "callOutgoing": "~@appd/ui-assets/inline-images/objects/callOutgoing.svg",
    "cassandra": "~@appd/ui-assets/inline-images/objects/cassandra.svg",
    "class": "~@appd/ui-assets/inline-images/objects/class.svg",
    "clock": "~@appd/ui-assets/inline-images/objects/clock.svg",
    "cloudHttp": "~@appd/ui-assets/inline-images/objects/cloudHttp.svg",
    "cloudMod": "~@appd/ui-assets/inline-images/objects/cloudMod.svg",
    "cloudWs": "~@appd/ui-assets/inline-images/objects/cloudWs.svg",
    "cluster": "~@appd/ui-assets/inline-images/objects/cluster.svg",
    "couchbase": "~@appd/ui-assets/inline-images/objects/couchbase.svg",
    "customExitpoint": "~@appd/ui-assets/inline-images/objects/customExitpoint.svg",
    "customMetric": "~@appd/ui-assets/inline-images/objects/customMetric.svg",
    "customTimer": "~@appd/ui-assets/inline-images/objects/customTimer.svg",
    "database": "~@appd/ui-assets/inline-images/objects/database.svg",
    "databaseServer": "~@appd/ui-assets/inline-images/objects/databaseServer.svg",
    "databaseShard": "~@appd/ui-assets/inline-images/objects/databaseShard.svg",
    "docker": "~@appd/ui-assets/inline-images/objects/docker.svg",
    "endpointTcp": "~@appd/ui-assets/inline-images/objects/endpointTcp.svg",
    "exitpointCache": "~@appd/ui-assets/inline-images/objects/exitpointCache.svg",
    "fileAttachment": "~@appd/ui-assets/inline-images/objects/fileAttachment.svg",
    "fileServer": "~@appd/ui-assets/inline-images/objects/fileServer.svg",
    "fragment": "~@appd/ui-assets/inline-images/objects/fragment.svg",
    "healthRuleTemplate": "~@appd/ui-assets/inline-images/objects/healthRuleTemplate.svg",
    "iFrameEum": "~@appd/ui-assets/inline-images/objects/iFrameEum.svg",
    "image": "~@appd/ui-assets/inline-images/objects/image.svg",
    "incomingTraffic": "~@appd/ui-assets/inline-images/objects/incomingTraffic.svg",
    "infoPoint": "~@appd/ui-assets/inline-images/objects/infoPoint.svg",
    "interactions": "~@appd/ui-assets/inline-images/objects/interactions.svg",
    "key": "~@appd/ui-assets/inline-images/objects/key.svg",
    "loadBalancer": "~@appd/ui-assets/inline-images/objects/loadBalancer.svg",
    "location": "~@appd/ui-assets/inline-images/objects/location.svg",
    "mainframe": "~@appd/ui-assets/inline-images/objects/mainframe.svg",
    "messageProcessor": "~@appd/ui-assets/inline-images/objects/messageProcessor.svg",
    "messagingServer": "~@appd/ui-assets/inline-images/objects/messagingServer.svg",
    "method": "~@appd/ui-assets/inline-images/objects/method.svg",
    "metricTreeFolder": "~@appd/ui-assets/inline-images/objects/metricTreeFolder.svg",
    "mobileCustomMetric": "~@appd/ui-assets/inline-images/objects/mobileCustomMetric.svg",
    "mobileInfoPointDynamic": "~@appd/ui-assets/inline-images/objects/mobileInfoPointDynamic.svg",
    "mongoDB": "~@appd/ui-assets/inline-images/objects/mongoDB.svg",
    "monitoringStatus": "~@appd/ui-assets/inline-images/objects/monitoringStatus.svg",
    "networkRequest": "~@appd/ui-assets/inline-images/objects/networkRequest.svg",
    "noData": "~@appd/ui-assets/inline-images/objects/noData.svg",
    "node": "~@appd/ui-assets/inline-images/objects/node.svg",
    "openTelemetry": "~@appd/ui-assets/inline-images/objects/openTelemetry.svg",
    "outgoingTraffic": "~@appd/ui-assets/inline-images/objects/outgoingTraffic.svg",
    "page": "~@appd/ui-assets/inline-images/objects/page.svg",
    "participants": "~@appd/ui-assets/inline-images/objects/participants.svg",
    "placeholder": "~@appd/ui-assets/inline-images/objects/placeholder.svg",
    "platform": "~@appd/ui-assets/inline-images/objects/platform.svg",
    "presenter": "~@appd/ui-assets/inline-images/objects/presenter.svg",
    "realUser": "~@appd/ui-assets/inline-images/objects/realUser.svg",
    "resources": "~@appd/ui-assets/inline-images/objects/resources.svg",
    "server": "~@appd/ui-assets/inline-images/objects/server.svg",
    "sessionFrame": "~@appd/ui-assets/inline-images/objects/sessionFrame.svg",
    "snapshotStartingPoint": "~@appd/ui-assets/inline-images/objects/snapshotStartingPoint.svg",
    "socket": "~@appd/ui-assets/inline-images/objects/socket.svg",
    "sqs": "~@appd/ui-assets/inline-images/objects/sqs.svg",
    "storage": "~@appd/ui-assets/inline-images/objects/storage.svg",
    "stream": "~@appd/ui-assets/inline-images/objects/stream.svg",
    "streamProcessor": "~@appd/ui-assets/inline-images/objects/streamProcessor.svg",
    "syntheticUser": "~@appd/ui-assets/inline-images/objects/syntheticUser.svg",
    "systemEvent": "~@appd/ui-assets/inline-images/objects/systemEvent.svg",
    "timer": "~@appd/ui-assets/inline-images/objects/timer.svg",
    "txDiscoveryAuto": "~@appd/ui-assets/inline-images/objects/txDiscoveryAuto.svg",
    "txDiscoveryCustom": "~@appd/ui-assets/inline-images/objects/txDiscoveryCustom.svg",
    "txDiscoveryCustomExclude": "~@appd/ui-assets/inline-images/objects/txDiscoveryCustomExclude.svg",
    "unresolvedDatabase": "~@appd/ui-assets/inline-images/objects/unresolvedDatabase.svg",
    "web": "~@appd/ui-assets/inline-images/objects/web.svg",
    "webServer": "~@appd/ui-assets/inline-images/objects/webServer.svg",
    "websphereMQ": "~@appd/ui-assets/inline-images/objects/websphereMQ.svg",
    // os
    "android": "~@appd/ui-assets/inline-images/os/android.svg",
    "ios": "~@appd/ui-assets/inline-images/os/ios.svg",
    // status
    "appNotResponding": "~@appd/ui-assets/inline-images/status/appNotResponding.svg",
    "arrowDownCritical": "~@appd/ui-assets/inline-images/status/arrowDownCritical.svg",
    "arrowDownNormal": "~@appd/ui-assets/inline-images/status/arrowDownNormal.svg",
    "arrowUpCritical": "~@appd/ui-assets/inline-images/status/arrowUpCritical.svg",
    "arrowUpNormal": "~@appd/ui-assets/inline-images/status/arrowUpNormal.svg",
    "broken": "~@appd/ui-assets/inline-images/status/broken.svg",
    "charging": "~@appd/ui-assets/inline-images/status/charging.svg",
    "cloudCritical": "~@appd/ui-assets/inline-images/status/cloudCritical.svg",
    "cloudVerySlow": "~@appd/ui-assets/inline-images/status/cloudVerySlow.svg",
    "cloudWarning": "~@appd/ui-assets/inline-images/status/cloudWarning.svg",
    "codeCritical": "~@appd/ui-assets/inline-images/status/codeCritical.svg",
    "codeVerySlow": "~@appd/ui-assets/inline-images/status/codeVerySlow.svg",
    "codeWarning": "~@appd/ui-assets/inline-images/status/codeWarning.svg",
    "crash": "~@appd/ui-assets/inline-images/status/crash.svg",
    "databaseCritical": "~@appd/ui-assets/inline-images/status/databaseCritical.svg",
    "databaseDisconnected": "~@appd/ui-assets/inline-images/status/databaseDisconnected.svg",
    "databaseNormal": "~@appd/ui-assets/inline-images/status/databaseNormal.svg",
    "databaseVerySlow": "~@appd/ui-assets/inline-images/status/databaseVerySlow.svg",
    "databaseWarning": "~@appd/ui-assets/inline-images/status/databaseWarning.svg",
    "diagnosticSessionCritical": "~@appd/ui-assets/inline-images/status/diagnosticSessionCritical.svg",
    "diagnosticSessionVerySlow": "~@appd/ui-assets/inline-images/status/diagnosticSessionVerySlow.svg",
    "diagnosticSessionWarning": "~@appd/ui-assets/inline-images/status/diagnosticSessionWarning.svg",
    "down": "~@appd/ui-assets/inline-images/status/down.svg",
    "error": "~@appd/ui-assets/inline-images/status/error.svg",
    "error2": "~@appd/ui-assets/inline-images/status/error2.svg",
    "infoStatus": "~@appd/ui-assets/inline-images/status/infoStatus.svg",
    "lowCharge": "~@appd/ui-assets/inline-images/status/lowCharge.svg",
    "mobileEUMCrash": "~@appd/ui-assets/inline-images/status/mobileEUMCrash.svg",
    "mobileEUMError": "~@appd/ui-assets/inline-images/status/mobileEUMError.svg",
    "mobileEUMInfo": "~@appd/ui-assets/inline-images/status/mobileEUMInfo.svg",
    "mobileEUMNormal": "~@appd/ui-assets/inline-images/status/mobileEUMNormal.svg",
    "mobileEUMUnknown": "~@appd/ui-assets/inline-images/status/mobileEUMUnknown.svg",
    "running": "~@appd/ui-assets/inline-images/status/running.svg",
    "sleeping": "~@appd/ui-assets/inline-images/status/sleeping.svg",
    "stepComplete": "~@appd/ui-assets/inline-images/status/stepComplete.svg",
    "success": "~@appd/ui-assets/inline-images/status/success.svg",
    "syntheticSessionsCritical": "~@appd/ui-assets/inline-images/status/syntheticSessionsCritical.svg",
    "syntheticSessionsNormal": "~@appd/ui-assets/inline-images/status/syntheticSessionsNormal.svg",
    "syntheticSessionsWarning": "~@appd/ui-assets/inline-images/status/syntheticSessionsWarning.svg",
    "terminated": "~@appd/ui-assets/inline-images/status/terminated.svg",
    "unknown": "~@appd/ui-assets/inline-images/status/unknown.svg",
    "up": "~@appd/ui-assets/inline-images/status/up.svg",
    "warning2": "~@appd/ui-assets/inline-images/status/warning2.svg",
    "warningStatus": "~@appd/ui-assets/inline-images/status/warningStatus.svg",
    "zombie": "~@appd/ui-assets/inline-images/status/zombie.svg",
    // widgets
    "analytics": "~@appd/ui-assets/inline-images/widgets/analytics.svg",
    "custom": "~@appd/ui-assets/inline-images/widgets/custom.svg",
    "flowMap": "~@appd/ui-assets/inline-images/widgets/flowMap.svg",
    "funnelWidget": "~@appd/ui-assets/inline-images/widgets/funnelWidget.svg",
    "gauge": "~@appd/ui-assets/inline-images/widgets/gauge.svg",
    "graph": "~@appd/ui-assets/inline-images/widgets/graph.svg",
    "healthList": "~@appd/ui-assets/inline-images/widgets/healthList.svg",
    "iFrame": "~@appd/ui-assets/inline-images/widgets/iFrame.svg",
    "imageWidget": "~@appd/ui-assets/inline-images/widgets/imageWidget.svg",
    "listWidget": "~@appd/ui-assets/inline-images/widgets/listWidget.svg",
    "metric": "~@appd/ui-assets/inline-images/widgets/metric.svg",
    "pieWidget": "~@appd/ui-assets/inline-images/widgets/pieWidget.svg",
    "statusLight": "~@appd/ui-assets/inline-images/widgets/statusLight.svg",
    "streamingGraph": "~@appd/ui-assets/inline-images/widgets/streamingGraph.svg",
    "textWidget": "~@appd/ui-assets/inline-images/widgets/textWidget.svg"
};

var ParticleIcon;
(function (ParticleIcon) {
    // actions
    ParticleIcon["Add"] = "add";
    ParticleIcon["AddToDash"] = "addToDash";
    ParticleIcon["AddWidget"] = "addWidget";
    ParticleIcon["Adjust"] = "adjust";
    ParticleIcon["Align"] = "align";
    ParticleIcon["AlignVerticalBottom"] = "alignVerticalBottom";
    ParticleIcon["AlignVerticalCenter"] = "alignVerticalCenter";
    ParticleIcon["AlignVerticalTop"] = "alignVerticalTop";
    ParticleIcon["Analyze"] = "analyze";
    ParticleIcon["Archive"] = "archive";
    ParticleIcon["AssociateTierNode"] = "associateTierNode";
    ParticleIcon["AutoFillFlowMap"] = "autoFillFlowMap";
    ParticleIcon["AutoLayoutFlowMap"] = "autoLayoutFlowMap";
    ParticleIcon["AutoRefresh"] = "autoRefresh";
    ParticleIcon["BottomPanel"] = "bottomPanel";
    ParticleIcon["Calendar"] = "calendar";
    ParticleIcon["Cancel"] = "cancel";
    ParticleIcon["CardView"] = "cardView";
    ParticleIcon["CircularViewFlowMap"] = "circularViewFlowMap";
    ParticleIcon["ClearConsole"] = "clearConsole";
    ParticleIcon["CompactView"] = "compactView";
    ParticleIcon["Configure"] = "configure";
    ParticleIcon["Copy"] = "copy";
    ParticleIcon["CreatePolicyManually"] = "createPolicyManually";
    ParticleIcon["Delete"] = "delete";
    ParticleIcon["Disable"] = "disable";
    ParticleIcon["Download"] = "download";
    ParticleIcon["Duplicate"] = "duplicate";
    ParticleIcon["Edit"] = "edit";
    ParticleIcon["Enabled"] = "enabled";
    ParticleIcon["Export"] = "export";
    ParticleIcon["Feedback"] = "feedback";
    ParticleIcon["Filter"] = "filter";
    ParticleIcon["FindSnapEvent"] = "findSnapEvent";
    ParticleIcon["GenerateSessions"] = "generateSessions";
    ParticleIcon["GridView"] = "gridView";
    ParticleIcon["Group"] = "group";
    ParticleIcon["Help"] = "help";
    ParticleIcon["Import"] = "import";
    ParticleIcon["ImportApp"] = "importApp";
    ParticleIcon["Info"] = "info";
    ParticleIcon["LaunchInfo"] = "launchInfo";
    ParticleIcon["LinearView"] = "linearView";
    ParticleIcon["Link"] = "link";
    ParticleIcon["LogarithmicView"] = "logarithmicView";
    ParticleIcon["Logout"] = "logout";
    ParticleIcon["Minus"] = "minus";
    ParticleIcon["Order"] = "order";
    ParticleIcon["Paste"] = "paste";
    ParticleIcon["Play"] = "play";
    ParticleIcon["PopOut"] = "popOut";
    ParticleIcon["Redo"] = "redo";
    ParticleIcon["Refresh"] = "refresh";
    ParticleIcon["Save"] = "save";
    ParticleIcon["SaveAs"] = "saveAs";
    ParticleIcon["Search"] = "search";
    ParticleIcon["SearchSnapshot"] = "searchSnapshot";
    ParticleIcon["Share"] = "share";
    ParticleIcon["SidePanel"] = "sidePanel";
    ParticleIcon["Stop"] = "stop";
    ParticleIcon["Symbolicate"] = "symbolicate";
    ParticleIcon["TestEmail"] = "testEmail";
    ParticleIcon["TestHttpRequest"] = "testHttpRequest";
    ParticleIcon["TextAlignCenter"] = "textAlignCenter";
    ParticleIcon["TextAlignLeft"] = "textAlignLeft";
    ParticleIcon["TextAlignRight"] = "textAlignRight";
    ParticleIcon["ThumbDown"] = "thumbDown";
    ParticleIcon["ThumbUp"] = "thumbUp";
    ParticleIcon["TreeView"] = "treeView";
    ParticleIcon["Undo"] = "undo";
    ParticleIcon["Ungroup"] = "ungroup";
    ParticleIcon["Upgrade"] = "upgrade";
    ParticleIcon["Upload"] = "upload";
    ParticleIcon["ViewDetails"] = "viewDetails";
    ParticleIcon["ViewDiagnosticSession"] = "viewDiagnosticSession";
    ParticleIcon["ViewMobile"] = "viewMobile";
    ParticleIcon["ViewSnapshot"] = "viewSnapshot";
    // agentTypes
    ParticleIcon["Aws"] = "aws";
    ParticleIcon["GoogleCloud"] = "googleCloud";
    ParticleIcon["MicrosoftAzure"] = "microsoftAzure";
    ParticleIcon["ThousandEyes"] = "thousandEyes";
    // browsers
    ParticleIcon["Chrome"] = "chrome";
    ParticleIcon["Firefox"] = "firefox";
    ParticleIcon["Ie"] = "ie";
    ParticleIcon["Netscape"] = "netscape";
    ParticleIcon["Opera"] = "opera";
    ParticleIcon["Other"] = "other";
    ParticleIcon["Safari"] = "safari";
    // chartTypes
    ParticleIcon["Area"] = "area";
    ParticleIcon["CirclePack"] = "circlePack";
    ParticleIcon["Column"] = "column";
    ParticleIcon["Donut"] = "donut";
    ParticleIcon["Funnel"] = "funnel";
    ParticleIcon["Histogram"] = "histogram";
    ParticleIcon["Line"] = "line";
    ParticleIcon["List"] = "list";
    ParticleIcon["Numeric"] = "numeric";
    ParticleIcon["Pie"] = "pie";
    ParticleIcon["Scatter"] = "scatter";
    ParticleIcon["Table"] = "table";
    ParticleIcon["TreeMap"] = "treeMap";
    ParticleIcon["WorldMap"] = "worldMap";
    // carousel
    ParticleIcon["ArrowBackDarkViolet"] = "arrowBackDarkViolet";
    ParticleIcon["ArrowForwardDarkViolet"] = "arrowForwardDarkViolet";
    // checkBox
    ParticleIcon["Indetermined"] = "indetermined";
    ParticleIcon["IndeterminedDisabled"] = "indeterminedDisabled";
    ParticleIcon["IndeterminedFocused"] = "indeterminedFocused";
    ParticleIcon["IndeterminedHover"] = "indeterminedHover";
    ParticleIcon["NotSelected"] = "notSelected";
    ParticleIcon["NotSelectedDisabled"] = "notSelectedDisabled";
    ParticleIcon["NotSelectedFocused"] = "notSelectedFocused";
    ParticleIcon["NotSelectedHover"] = "notSelectedHover";
    ParticleIcon["Selected"] = "selected";
    ParticleIcon["SelectedDisabled"] = "selectedDisabled";
    ParticleIcon["SelectedFocused"] = "selectedFocused";
    ParticleIcon["SelectedHover"] = "selectedHover";
    // gauge
    ParticleIcon["Baseline"] = "baseline";
    ParticleIcon["TriangleMarker"] = "triangleMarker";
    ParticleIcon["TriangleMarkerSmall"] = "triangleMarkerSmall";
    // journeyMap
    ParticleIcon["CriticalOutline"] = "criticalOutline";
    ParticleIcon["InfoMessageOutline"] = "infoMessageOutline";
    ParticleIcon["NormalOutline"] = "normalOutline";
    ParticleIcon["StallOutline"] = "stallOutline";
    ParticleIcon["VerySlowOutline"] = "verySlowOutline";
    ParticleIcon["WarningOutline"] = "warningOutline";
    // numberfield
    ParticleIcon["NumberArrowDropDown"] = "numberArrowDropDown";
    ParticleIcon["NumberArrowDropUp"] = "numberArrowDropUp";
    // splitter
    ParticleIcon["DragHandleHorizontal"] = "dragHandleHorizontal";
    ParticleIcon["DragHandleVertical"] = "dragHandleVertical";
    // timeScrubber
    ParticleIcon["ScrubberDragHandle"] = "scrubberDragHandle";
    // wizard
    ParticleIcon["ErrorDefault"] = "errorDefault";
    ParticleIcon["ErrorSmall"] = "errorSmall";
    // dataTypes
    ParticleIcon["Boolean"] = "boolean";
    ParticleIcon["Currency"] = "currency";
    ParticleIcon["Number"] = "number";
    ParticleIcon["Object"] = "object";
    ParticleIcon["Text"] = "text";
    // health
    ParticleIcon["Critical"] = "critical";
    ParticleIcon["CriticalThemable"] = "criticalThemable";
    ParticleIcon["InfoMessage"] = "infoMessage";
    ParticleIcon["InfoMessageThemable"] = "infoMessageThemable";
    ParticleIcon["Normal"] = "normal";
    ParticleIcon["NormalThemable"] = "normalThemable";
    ParticleIcon["Stall"] = "stall";
    ParticleIcon["VerySlow"] = "verySlow";
    ParticleIcon["Warning"] = "warning";
    ParticleIcon["Warning3"] = "warning3";
    ParticleIcon["WarningThemable"] = "warningThemable";
    // languages
    ParticleIcon["Cpp"] = "cpp";
    ParticleIcon["Elixir"] = "elixir";
    ParticleIcon["Erlang"] = "erlang";
    ParticleIcon["GoLang"] = "goLang";
    ParticleIcon["Java"] = "java";
    ParticleIcon["Net"] = "net";
    ParticleIcon["NodeJs"] = "nodeJs";
    ParticleIcon["Php"] = "php";
    ParticleIcon["Python"] = "python";
    ParticleIcon["Ruby"] = "ruby";
    ParticleIcon["Rust"] = "rust";
    // locations
    ParticleIcon["ActionSuspended"] = "actionSuspended";
    ParticleIcon["Actions"] = "actions";
    ParticleIcon["AlertAndRespond"] = "alertAndRespond";
    ParticleIcon["AnomalyDetection"] = "anomalyDetection";
    ParticleIcon["Apm"] = "apm";
    ParticleIcon["ApplicationServers"] = "applicationServers";
    ParticleIcon["Biq"] = "biq";
    ParticleIcon["Bts"] = "bts";
    ParticleIcon["BusinessJourneys"] = "businessJourneys";
    ParticleIcon["CloudAutoScaling"] = "cloudAutoScaling";
    ParticleIcon["CloudBackend"] = "cloudBackend";
    ParticleIcon["CodeIssues"] = "codeIssues";
    ParticleIcon["Community"] = "community";
    ParticleIcon["Comparison"] = "comparison";
    ParticleIcon["Container"] = "container";
    ParticleIcon["Dashboards"] = "dashboards";
    ParticleIcon["DataPipeline"] = "dataPipeline";
    ParticleIcon["DiagnosticSessions"] = "diagnosticSessions";
    ParticleIcon["Docs"] = "docs";
    ParticleIcon["EmailAction"] = "emailAction";
    ParticleIcon["EmailDigest"] = "emailDigest";
    ParticleIcon["Eum"] = "eum";
    ParticleIcon["EumCloud"] = "eumCloud";
    ParticleIcon["EumSessions"] = "eumSessions";
    ParticleIcon["EumWebApp"] = "eumWebApp";
    ParticleIcon["Events"] = "events";
    ParticleIcon["EventsService"] = "eventsService";
    ParticleIcon["ExperienceLevelManagement"] = "experienceLevelManagement";
    ParticleIcon["HealthRuleViolation"] = "healthRuleViolation";
    ParticleIcon["HealthRules"] = "healthRules";
    ParticleIcon["HelpCenter"] = "helpCenter";
    ParticleIcon["Home"] = "home";
    ParticleIcon["Host"] = "host";
    ParticleIcon["HttpAction"] = "httpAction";
    ParticleIcon["JavascriptErrors"] = "javascriptErrors";
    ParticleIcon["JobsManager"] = "jobsManager";
    ParticleIcon["JourneyMap"] = "journeyMap";
    ParticleIcon["LogAnalytics"] = "logAnalytics";
    ParticleIcon["MetricBrowser"] = "metricBrowser";
    ParticleIcon["MobileApp"] = "mobileApp";
    ParticleIcon["NetworkRequests"] = "networkRequests";
    ParticleIcon["OnDemandPageSnap"] = "onDemandPageSnap";
    ParticleIcon["Pages"] = "pages";
    ParticleIcon["PagesAndAjax"] = "pagesAndAjax";
    ParticleIcon["Policies"] = "policies";
    ParticleIcon["RemoteServices"] = "remoteServices";
    ParticleIcon["Reports"] = "reports";
    ParticleIcon["ResourcePerformance"] = "resourcePerformance";
    ParticleIcon["Searches"] = "searches";
    ParticleIcon["Servers"] = "servers";
    ParticleIcon["ServiceAvailability"] = "serviceAvailability";
    ParticleIcon["ServiceEndPoint"] = "serviceEndPoint";
    ParticleIcon["Synthetic"] = "synthetic";
    ParticleIcon["SyntheticSessions"] = "syntheticSessions";
    ParticleIcon["TierAndNode"] = "tierAndNode";
    ParticleIcon["Tools"] = "tools";
    ParticleIcon["TransactionAnalytics"] = "transactionAnalytics";
    ParticleIcon["Troubleshoot"] = "troubleshoot";
    ParticleIcon["UserAnalytics"] = "userAnalytics";
    ParticleIcon["Videos"] = "videos";
    ParticleIcon["VirtualPages"] = "virtualPages";
    // navigation
    ParticleIcon["ArrowBack"] = "arrowBack";
    ParticleIcon["ArrowDown"] = "arrowDown";
    ParticleIcon["ArrowDropDown"] = "arrowDropDown";
    ParticleIcon["ArrowDropUp"] = "arrowDropUp";
    ParticleIcon["ArrowForward"] = "arrowForward";
    ParticleIcon["ArrowUp"] = "arrowUp";
    ParticleIcon["ChevronDown"] = "chevronDown";
    ParticleIcon["ChevronLeft"] = "chevronLeft";
    ParticleIcon["ChevronRight"] = "chevronRight";
    ParticleIcon["ChevronUp"] = "chevronUp";
    ParticleIcon["Close"] = "close";
    ParticleIcon["DoubleChevronLeft"] = "doubleChevronLeft";
    ParticleIcon["DoubleChevronRight"] = "doubleChevronRight";
    ParticleIcon["DragHandle"] = "dragHandle";
    ParticleIcon["DragIndicator"] = "dragIndicator";
    ParticleIcon["FirstPage"] = "firstPage";
    ParticleIcon["FullScreen"] = "fullScreen";
    ParticleIcon["FullScreenExit"] = "fullScreenExit";
    ParticleIcon["LastPage"] = "lastPage";
    ParticleIcon["Menu"] = "menu";
    ParticleIcon["Minimize"] = "minimize";
    ParticleIcon["MoreHorizontal"] = "moreHorizontal";
    ParticleIcon["MoreVertical"] = "moreVertical";
    // objects
    ParticleIcon["Activity"] = "activity";
    ParticleIcon["AmazonS3"] = "amazonS3";
    ParticleIcon["AmazonSns"] = "amazonSns";
    ParticleIcon["BidirectedTraffic"] = "bidirectedTraffic";
    ParticleIcon["Blitz"] = "blitz";
    ParticleIcon["Breadcrumb"] = "breadcrumb";
    ParticleIcon["CallGraphFull"] = "callGraphFull";
    ParticleIcon["CallGraphPartial"] = "callGraphPartial";
    ParticleIcon["CallGraphPossible"] = "callGraphPossible";
    ParticleIcon["CallIncoming"] = "callIncoming";
    ParticleIcon["CallOutgoing"] = "callOutgoing";
    ParticleIcon["Cassandra"] = "cassandra";
    ParticleIcon["Class"] = "class";
    ParticleIcon["Clock"] = "clock";
    ParticleIcon["CloudHttp"] = "cloudHttp";
    ParticleIcon["CloudMod"] = "cloudMod";
    ParticleIcon["CloudWs"] = "cloudWs";
    ParticleIcon["Cluster"] = "cluster";
    ParticleIcon["Couchbase"] = "couchbase";
    ParticleIcon["CustomExitpoint"] = "customExitpoint";
    ParticleIcon["CustomMetric"] = "customMetric";
    ParticleIcon["CustomTimer"] = "customTimer";
    ParticleIcon["Database"] = "database";
    ParticleIcon["DatabaseServer"] = "databaseServer";
    ParticleIcon["DatabaseShard"] = "databaseShard";
    ParticleIcon["Docker"] = "docker";
    ParticleIcon["EndpointTcp"] = "endpointTcp";
    ParticleIcon["ExitpointCache"] = "exitpointCache";
    ParticleIcon["FileAttachment"] = "fileAttachment";
    ParticleIcon["FileServer"] = "fileServer";
    ParticleIcon["Fragment"] = "fragment";
    ParticleIcon["HealthRuleTemplate"] = "healthRuleTemplate";
    ParticleIcon["IFrameEum"] = "iFrameEum";
    ParticleIcon["Image"] = "image";
    ParticleIcon["IncomingTraffic"] = "incomingTraffic";
    ParticleIcon["InfoPoint"] = "infoPoint";
    ParticleIcon["Interactions"] = "interactions";
    ParticleIcon["Key"] = "key";
    ParticleIcon["LoadBalancer"] = "loadBalancer";
    ParticleIcon["Location"] = "location";
    ParticleIcon["Mainframe"] = "mainframe";
    ParticleIcon["MessageProcessor"] = "messageProcessor";
    ParticleIcon["MessagingServer"] = "messagingServer";
    ParticleIcon["Method"] = "method";
    ParticleIcon["MetricTreeFolder"] = "metricTreeFolder";
    ParticleIcon["MobileCustomMetric"] = "mobileCustomMetric";
    ParticleIcon["MobileInfoPointDynamic"] = "mobileInfoPointDynamic";
    ParticleIcon["MongoDB"] = "mongoDB";
    ParticleIcon["MonitoringStatus"] = "monitoringStatus";
    ParticleIcon["NetworkRequest"] = "networkRequest";
    ParticleIcon["NoData"] = "noData";
    ParticleIcon["Node"] = "node";
    ParticleIcon["OpenTelemetry"] = "openTelemetry";
    ParticleIcon["OutgoingTraffic"] = "outgoingTraffic";
    ParticleIcon["Page"] = "page";
    ParticleIcon["Participants"] = "participants";
    ParticleIcon["Placeholder"] = "placeholder";
    ParticleIcon["Platform"] = "platform";
    ParticleIcon["Presenter"] = "presenter";
    ParticleIcon["RealUser"] = "realUser";
    ParticleIcon["Resources"] = "resources";
    ParticleIcon["Server"] = "server";
    ParticleIcon["SessionFrame"] = "sessionFrame";
    ParticleIcon["SnapshotStartingPoint"] = "snapshotStartingPoint";
    ParticleIcon["Socket"] = "socket";
    ParticleIcon["Sqs"] = "sqs";
    ParticleIcon["Storage"] = "storage";
    ParticleIcon["Stream"] = "stream";
    ParticleIcon["StreamProcessor"] = "streamProcessor";
    ParticleIcon["SyntheticUser"] = "syntheticUser";
    ParticleIcon["SystemEvent"] = "systemEvent";
    ParticleIcon["Timer"] = "timer";
    ParticleIcon["TxDiscoveryAuto"] = "txDiscoveryAuto";
    ParticleIcon["TxDiscoveryCustom"] = "txDiscoveryCustom";
    ParticleIcon["TxDiscoveryCustomExclude"] = "txDiscoveryCustomExclude";
    ParticleIcon["UnresolvedDatabase"] = "unresolvedDatabase";
    ParticleIcon["Web"] = "web";
    ParticleIcon["WebServer"] = "webServer";
    ParticleIcon["WebsphereMQ"] = "websphereMQ";
    // os
    ParticleIcon["Android"] = "android";
    ParticleIcon["Ios"] = "ios";
    // status
    ParticleIcon["AppNotResponding"] = "appNotResponding";
    ParticleIcon["ArrowDownCritical"] = "arrowDownCritical";
    ParticleIcon["ArrowDownNormal"] = "arrowDownNormal";
    ParticleIcon["ArrowUpCritical"] = "arrowUpCritical";
    ParticleIcon["ArrowUpNormal"] = "arrowUpNormal";
    ParticleIcon["Broken"] = "broken";
    ParticleIcon["Charging"] = "charging";
    ParticleIcon["CloudCritical"] = "cloudCritical";
    ParticleIcon["CloudVerySlow"] = "cloudVerySlow";
    ParticleIcon["CloudWarning"] = "cloudWarning";
    ParticleIcon["CodeCritical"] = "codeCritical";
    ParticleIcon["CodeVerySlow"] = "codeVerySlow";
    ParticleIcon["CodeWarning"] = "codeWarning";
    ParticleIcon["Crash"] = "crash";
    ParticleIcon["DatabaseCritical"] = "databaseCritical";
    ParticleIcon["DatabaseDisconnected"] = "databaseDisconnected";
    ParticleIcon["DatabaseNormal"] = "databaseNormal";
    ParticleIcon["DatabaseVerySlow"] = "databaseVerySlow";
    ParticleIcon["DatabaseWarning"] = "databaseWarning";
    ParticleIcon["DiagnosticSessionCritical"] = "diagnosticSessionCritical";
    ParticleIcon["DiagnosticSessionVerySlow"] = "diagnosticSessionVerySlow";
    ParticleIcon["DiagnosticSessionWarning"] = "diagnosticSessionWarning";
    ParticleIcon["Down"] = "down";
    ParticleIcon["Error"] = "error";
    ParticleIcon["Error2"] = "error2";
    ParticleIcon["InfoStatus"] = "infoStatus";
    ParticleIcon["LowCharge"] = "lowCharge";
    ParticleIcon["MobileEUMCrash"] = "mobileEUMCrash";
    ParticleIcon["MobileEUMError"] = "mobileEUMError";
    ParticleIcon["MobileEUMInfo"] = "mobileEUMInfo";
    ParticleIcon["MobileEUMNormal"] = "mobileEUMNormal";
    ParticleIcon["MobileEUMUnknown"] = "mobileEUMUnknown";
    ParticleIcon["Running"] = "running";
    ParticleIcon["Sleeping"] = "sleeping";
    ParticleIcon["StepComplete"] = "stepComplete";
    ParticleIcon["Success"] = "success";
    ParticleIcon["SyntheticSessionsCritical"] = "syntheticSessionsCritical";
    ParticleIcon["SyntheticSessionsNormal"] = "syntheticSessionsNormal";
    ParticleIcon["SyntheticSessionsWarning"] = "syntheticSessionsWarning";
    ParticleIcon["Terminated"] = "terminated";
    ParticleIcon["Unknown"] = "unknown";
    ParticleIcon["Up"] = "up";
    ParticleIcon["Warning2"] = "warning2";
    ParticleIcon["WarningStatus"] = "warningStatus";
    ParticleIcon["Zombie"] = "zombie";
    // widgets
    ParticleIcon["Analytics"] = "analytics";
    ParticleIcon["Custom"] = "custom";
    ParticleIcon["FlowMap"] = "flowMap";
    ParticleIcon["FunnelWidget"] = "funnelWidget";
    ParticleIcon["Gauge"] = "gauge";
    ParticleIcon["Graph"] = "graph";
    ParticleIcon["HealthList"] = "healthList";
    ParticleIcon["IFrame"] = "iFrame";
    ParticleIcon["ImageWidget"] = "imageWidget";
    ParticleIcon["ListWidget"] = "listWidget";
    ParticleIcon["Metric"] = "metric";
    ParticleIcon["PieWidget"] = "pieWidget";
    ParticleIcon["StatusLight"] = "statusLight";
    ParticleIcon["StreamingGraph"] = "streamingGraph";
    ParticleIcon["TextWidget"] = "textWidget";
})(ParticleIcon || (ParticleIcon = {}));

/**
 * @appd/ui-assets/js/DesignTokens.ts
 *
 * DO NOT EDIT - This file is generated automatically when publishing ui-assets.
 */
var DesignTokens;
(function (DesignTokens) {
    DesignTokens["particleLinkBlue"] = "#0040b6";
    DesignTokens["particleIceBlue"] = "#f6fbff";
    DesignTokens["particleRainBlue"] = "#bedfff";
    DesignTokens["particleDeepSkyBlue"] = "#006ff0";
    DesignTokens["particleLilacViolet"] = "#ece9ff";
    DesignTokens["particlePeriwinkle"] = "#9d8eff";
    DesignTokens["particleElectricIndigo"] = "#7b66ff";
    DesignTokens["particleDarkViolet"] = "#5845db";
    DesignTokens["particlePeranoBlue"] = "#b0c5ff";
    DesignTokens["particleSwitchBlue"] = "#c6e1fa";
    DesignTokens["particleWhite"] = "#fff";
    DesignTokens["particleStardustGrey"] = "#f8f9fa";
    DesignTokens["particleCloudGrey"] = "#f1f3f5";
    DesignTokens["particleStormGrey"] = "#e5e8ea";
    DesignTokens["particleWinterGrey"] = "#dee1e2";
    DesignTokens["particleSiberianGrey"] = "#dbdfe2";
    DesignTokens["particleMatterGrey"] = "#a2a6ab";
    DesignTokens["particleAnthraciteGrey"] = "#585e67";
    DesignTokens["particleDeepSpaceGrey"] = "#19212b";
    DesignTokens["particleValidationRed"] = "#df0d00";
    DesignTokens["particleValidationOrange"] = "#ff7f32";
    DesignTokens["particleValidationGreen"] = "#1da624";
    DesignTokens["particleSignalGreen"] = "#00d270";
    DesignTokens["particleSignalGreenLight"] = "#e6fff3";
    DesignTokens["particleAzureLight"] = "#0076ff";
    DesignTokens["particleAzureBlue"] = "#0076ff";
    DesignTokens["particleAzureBlueLight"] = "#e6f1ff";
    DesignTokens["particleTorchRed"] = "#f0213a";
    DesignTokens["particleTorchRedLight"] = "#fee9eb";
    DesignTokens["particleSaffronYellow"] = "#ffd00e";
    DesignTokens["particleSaffronYellowLight"] = "#fffae6";
    DesignTokens["particleLavaOrange"] = "#ff7f32";
    DesignTokens["particleLavaOrangeLight"] = "#ffe8db";
    DesignTokens["particleUltraViolet"] = "#840fa6";
    DesignTokens["particleUnknownGrey"] = "#585e67";
    DesignTokens["particleDynamicUltra"] = "#4e3eb1";
    DesignTokens["particleIris"] = "#241774";
    DesignTokens["particleSlowDancer"] = "#fda7e0";
    DesignTokens["particleLensFlare"] = "#8e00ce";
    DesignTokens["particleFusion"] = "#ff212f";
    DesignTokens["particleAfterBurner"] = "#ff7f32";
    DesignTokens["particleApollo"] = "#ffd400";
    DesignTokens["particleAurora"] = "#00d180";
    DesignTokens["particleCodeBlue"] = "#47a83f";
    DesignTokens["particleGlobalControl"] = "#b8bec4";
    DesignTokens["particleDeepSpace1"] = "#19212b";
    DesignTokens["particleDeepSpace2"] = "#535960";
    DesignTokens["particleDeepSpace3"] = "#8c9095";
    DesignTokens["particleDeepSpace4"] = "#c5c7ca";
    DesignTokens["particleAtmosphere1"] = "#e4e7ec";
    DesignTokens["particleAtmosphere2"] = "#ebedf1";
    DesignTokens["particleAtmosphere3"] = "#f1f3f5";
    DesignTokens["particleAtmosphere4"] = "#f8f9fa";
    DesignTokens["particleChart1"] = "#5a4daa";
    DesignTokens["particleChart2"] = "#53abff";
    DesignTokens["particleChart3"] = "#71dec0";
    DesignTokens["particleChart4"] = "#ffbf54";
    DesignTokens["particleChart5"] = "#f7729a";
    DesignTokens["particleChart6"] = "#907eff";
    DesignTokens["particleChart7"] = "#f8a0ff";
    DesignTokens["particleChart8"] = "#00b582";
    DesignTokens["particleChart9"] = "#ffe95f";
    DesignTokens["particleChart10"] = "#bd8d78";
    DesignTokens["particleChart11"] = "#a6a0ce";
    DesignTokens["particleChart12"] = "#a9d4ff";
    DesignTokens["particleChart13"] = "#b8eedf";
    DesignTokens["particleChart14"] = "#ffdfa9";
    DesignTokens["particleChart15"] = "#fbb8cc";
    DesignTokens["particleChart16"] = "#ded9ff";
    DesignTokens["particleChart17"] = "#fbcfff";
    DesignTokens["particleChart18"] = "#7fdac0";
    DesignTokens["particleChart19"] = "#d2f0b8";
    DesignTokens["particleChart20"] = "#dec6bb";
    DesignTokens["particleChart21"] = "#3b3270";
    DesignTokens["particleChart22"] = "#458ed4";
    DesignTokens["particleChart23"] = "#5db89f";
    DesignTokens["particleChart24"] = "#d49e45";
    DesignTokens["particleChart25"] = "#cd5e80";
    DesignTokens["particleChart26"] = "#6757d4";
    DesignTokens["particleChart27"] = "#ce85d4";
    DesignTokens["particleChart28"] = "#00966c";
    DesignTokens["particleChart29"] = "#88ba5e";
    DesignTokens["particleChart30"] = "#9b7462";
    DesignTokens["particleSideNavColorDefault"] = "#585e67";
    DesignTokens["particleSideNavColorActive"] = "#7a66ff";
    DesignTokens["particleDarkStatusWarning"] = "#ffd769";
    DesignTokens["particleDarkStatusCritical"] = "#f9565b";
    DesignTokens["particleDarkStatusNormal"] = "#49dc80";
    DesignTokens["particleLineDefault"] = "1px";
    DesignTokens["particleLineMedium"] = "2px";
    DesignTokens["particleLineThick"] = "3px";
    DesignTokens["particleLineFat"] = "4px";
    DesignTokens["particleDurationFast"] = "100ms";
    DesignTokens["particleDurationMedium"] = "200ms";
    DesignTokens["particleDurationLazy"] = "400ms";
    DesignTokens["particleDurationSlow"] = "600ms";
    DesignTokens["particleEasingLinear"] = "cubic-bezier(0,0,1,1)";
    DesignTokens["particleEasingStandard"] = "cubic-bezier(0.4,0,0.2,1)";
    DesignTokens["particleEasingDecelerate"] = "cubic-bezier(0,0,0.2,1)";
    DesignTokens["particleEasingAccelerate"] = "cubic-bezier(0.4,0,1,1)";
    DesignTokens["particleRadiusDefault"] = "3px";
    DesignTokens["particleRadiusHeavy"] = "6px";
    DesignTokens["particleRadiusFull"] = "50%";
    DesignTokens["particleSpacing1x"] = "4px";
    DesignTokens["particleSpacing2x"] = "8px";
    DesignTokens["particleSpacing3x"] = "12px";
    DesignTokens["particleSpacing4x"] = "16px";
    DesignTokens["particleSpacing5x"] = "20px";
    DesignTokens["particleSpacing6x"] = "24px";
    DesignTokens["particleFallbackFontFamily"] = "'Helvetica Neue', Helvetica, Arial, sans-serif";
    DesignTokens["particleFallbackFontFamilyFixedWidth"] = "monospace";
    DesignTokens["particleIconColor"] = "#19212b";
    DesignTokens["particleIconColorHover"] = "#5845db";
    DesignTokens["particleIconColorActive"] = "#9d8eff";
    DesignTokens["particleIconDimensionSmall"] = "18px";
    DesignTokens["particleIconDimensionMedium"] = "24px";
    DesignTokens["particleIconDimensionLarge"] = "48px";
})(DesignTokens || (DesignTokens = {}));

/**
 * @appd/ui-assets/js/DesignTokenColors.ts
 *
 * DO NOT EDIT - This file is generated automatically when publishing ui-assets.
 */
var DesignTokenColors;
(function (DesignTokenColors) {
    DesignTokenColors["particleLinkBlue"] = "#0040b6";
    DesignTokenColors["particleIceBlue"] = "#f6fbff";
    DesignTokenColors["particleRainBlue"] = "#bedfff";
    DesignTokenColors["particleDeepSkyBlue"] = "#006ff0";
    DesignTokenColors["particleLilacViolet"] = "#ece9ff";
    DesignTokenColors["particlePeriwinkle"] = "#9d8eff";
    DesignTokenColors["particleElectricIndigo"] = "#7b66ff";
    DesignTokenColors["particleDarkViolet"] = "#5845db";
    DesignTokenColors["particlePeranoBlue"] = "#b0c5ff";
    DesignTokenColors["particleSwitchBlue"] = "#c6e1fa";
    DesignTokenColors["particleWhite"] = "#fff";
    DesignTokenColors["particleStardustGrey"] = "#f8f9fa";
    DesignTokenColors["particleCloudGrey"] = "#f1f3f5";
    DesignTokenColors["particleStormGrey"] = "#e5e8ea";
    DesignTokenColors["particleWinterGrey"] = "#dee1e2";
    DesignTokenColors["particleSiberianGrey"] = "#dbdfe2";
    DesignTokenColors["particleMatterGrey"] = "#a2a6ab";
    DesignTokenColors["particleAnthraciteGrey"] = "#585e67";
    DesignTokenColors["particleDeepSpaceGrey"] = "#19212b";
    DesignTokenColors["particleValidationRed"] = "#df0d00";
    DesignTokenColors["particleValidationOrange"] = "#ff7f32";
    DesignTokenColors["particleValidationGreen"] = "#1da624";
    DesignTokenColors["particleSignalGreen"] = "#00d270";
    DesignTokenColors["particleSignalGreenLight"] = "#e6fff3";
    DesignTokenColors["particleAzureLight"] = "#0076ff";
    DesignTokenColors["particleAzureBlue"] = "#0076ff";
    DesignTokenColors["particleAzureBlueLight"] = "#e6f1ff";
    DesignTokenColors["particleTorchRed"] = "#f0213a";
    DesignTokenColors["particleTorchRedLight"] = "#fee9eb";
    DesignTokenColors["particleSaffronYellow"] = "#ffd00e";
    DesignTokenColors["particleSaffronYellowLight"] = "#fffae6";
    DesignTokenColors["particleLavaOrange"] = "#ff7f32";
    DesignTokenColors["particleLavaOrangeLight"] = "#ffe8db";
    DesignTokenColors["particleUltraViolet"] = "#840fa6";
    DesignTokenColors["particleUnknownGrey"] = "#585e67";
    DesignTokenColors["particleDynamicUltra"] = "#4e3eb1";
    DesignTokenColors["particleIris"] = "#241774";
    DesignTokenColors["particleSlowDancer"] = "#fda7e0";
    DesignTokenColors["particleLensFlare"] = "#8e00ce";
    DesignTokenColors["particleFusion"] = "#ff212f";
    DesignTokenColors["particleAfterBurner"] = "#ff7f32";
    DesignTokenColors["particleApollo"] = "#ffd400";
    DesignTokenColors["particleAurora"] = "#00d180";
    DesignTokenColors["particleCodeBlue"] = "#47a83f";
    DesignTokenColors["particleGlobalControl"] = "#b8bec4";
    DesignTokenColors["particleDeepSpace1"] = "#19212b";
    DesignTokenColors["particleDeepSpace2"] = "#535960";
    DesignTokenColors["particleDeepSpace3"] = "#8c9095";
    DesignTokenColors["particleDeepSpace4"] = "#c5c7ca";
    DesignTokenColors["particleAtmosphere1"] = "#e4e7ec";
    DesignTokenColors["particleAtmosphere2"] = "#ebedf1";
    DesignTokenColors["particleAtmosphere3"] = "#f1f3f5";
    DesignTokenColors["particleAtmosphere4"] = "#f8f9fa";
    DesignTokenColors["particleChart1"] = "#5a4daa";
    DesignTokenColors["particleChart2"] = "#53abff";
    DesignTokenColors["particleChart3"] = "#71dec0";
    DesignTokenColors["particleChart4"] = "#ffbf54";
    DesignTokenColors["particleChart5"] = "#f7729a";
    DesignTokenColors["particleChart6"] = "#907eff";
    DesignTokenColors["particleChart7"] = "#f8a0ff";
    DesignTokenColors["particleChart8"] = "#00b582";
    DesignTokenColors["particleChart9"] = "#ffe95f";
    DesignTokenColors["particleChart10"] = "#bd8d78";
    DesignTokenColors["particleChart11"] = "#a6a0ce";
    DesignTokenColors["particleChart12"] = "#a9d4ff";
    DesignTokenColors["particleChart13"] = "#b8eedf";
    DesignTokenColors["particleChart14"] = "#ffdfa9";
    DesignTokenColors["particleChart15"] = "#fbb8cc";
    DesignTokenColors["particleChart16"] = "#ded9ff";
    DesignTokenColors["particleChart17"] = "#fbcfff";
    DesignTokenColors["particleChart18"] = "#7fdac0";
    DesignTokenColors["particleChart19"] = "#d2f0b8";
    DesignTokenColors["particleChart20"] = "#dec6bb";
    DesignTokenColors["particleChart21"] = "#3b3270";
    DesignTokenColors["particleChart22"] = "#458ed4";
    DesignTokenColors["particleChart23"] = "#5db89f";
    DesignTokenColors["particleChart24"] = "#d49e45";
    DesignTokenColors["particleChart25"] = "#cd5e80";
    DesignTokenColors["particleChart26"] = "#6757d4";
    DesignTokenColors["particleChart27"] = "#ce85d4";
    DesignTokenColors["particleChart28"] = "#00966c";
    DesignTokenColors["particleChart29"] = "#88ba5e";
    DesignTokenColors["particleChart30"] = "#9b7462";
    DesignTokenColors["particleSideNavColorDefault"] = "#585e67";
    DesignTokenColors["particleSideNavColorActive"] = "#7a66ff";
    DesignTokenColors["particleDarkStatusWarning"] = "#ffd769";
    DesignTokenColors["particleDarkStatusCritical"] = "#f9565b";
    DesignTokenColors["particleDarkStatusNormal"] = "#49dc80";
})(DesignTokenColors || (DesignTokenColors = {}));

/**
 * @appd/ui-assets/js/LevitateDarkTheme.ts
 *
 * DO NOT EDIT - This file is generated automatically when publishing ui-assets.
 */
var LevitateDarkTheme;
(function (LevitateDarkTheme) {
    LevitateDarkTheme["particleDarkPrimaryHigh"] = "#8a5fff";
    LevitateDarkTheme["particleDarkPrimaryMedium"] = "rgba(138,95,255,0.6)";
    LevitateDarkTheme["particleDarkPrimaryLow"] = "rgba(138,95,255,0.28)";
    LevitateDarkTheme["particleDarkSecondaryHigh"] = "#cbadff";
    LevitateDarkTheme["particleDarkSecondaryMedium"] = "rgba(203,173,255,0.6)";
    LevitateDarkTheme["particleDarkSecondaryLow"] = "rgba(203,173,255,0.38)";
    LevitateDarkTheme["particleDarkSurface1"] = "#4f5361";
    LevitateDarkTheme["particleDarkSurface2"] = "#3c4050";
    LevitateDarkTheme["particleDarkSurface3"] = "#323433";
    LevitateDarkTheme["particleDarkSurface4"] = "#262939";
    LevitateDarkTheme["particleDarkSurface5"] = "#16192a";
    LevitateDarkTheme["particleDarkHighlightHighIcon"] = "white";
    LevitateDarkTheme["particleDarkHighlightHigh"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkHighlightMedium"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkHighlightLow"] = "rgba(255,255,255,0.38)";
    LevitateDarkTheme["particleDarkStateDefault"] = "rgba(255,255,255,0.1)";
    LevitateDarkTheme["particleDarkStateHoverOrDisabled"] = "rgba(255,255,255,0.34)";
    LevitateDarkTheme["particleDarkStateLow"] = "rgba(255,255,255,0.06)";
    LevitateDarkTheme["particleDarkStatePressed"] = "rgba(0,0,0,0.1)";
    LevitateDarkTheme["particleDarkPrimary300"] = "#9e7eff";
    LevitateDarkTheme["particleDarkPrimary200"] = "#bca5ff";
    LevitateDarkTheme["particleDarkPrimary100"] = "#d7c9fe";
    LevitateDarkTheme["particleDarkPrimary50"] = "#f0eaff";
    LevitateDarkTheme["particleDarkGrey700"] = "#6f7182";
    LevitateDarkTheme["particleDarkGrey500"] = "#b1b5ca";
    LevitateDarkTheme["particleDarkStatusNormal300"] = "#49dc80";
    LevitateDarkTheme["particleDarkStatusNormal200"] = "#6be398";
    LevitateDarkTheme["particleDarkStatusNormalLow"] = "rgba(73,220,128,0.28)";
    LevitateDarkTheme["particleDarkStatusNormalGraph"] = "rgba(107,227,152,0.83)";
    LevitateDarkTheme["particleDarkStatusWarning300"] = "#ffd769";
    LevitateDarkTheme["particleDarkStatusWarning200"] = "#ffe292";
    LevitateDarkTheme["particleDarkStatusWarningLow"] = "rgba(255,215,105,0.28)";
    LevitateDarkTheme["particleDarkStatusCritical300"] = "#f9565b";
    LevitateDarkTheme["particleDarkStatusCritical200"] = "#fa7d81";
    LevitateDarkTheme["particleDarkStatusCriticalLow"] = "rgba(249,86,91,0.28)";
    LevitateDarkTheme["particleDarkStatusInfo300"] = "#64a1ff";
    LevitateDarkTheme["particleDarkStatusInfo200"] = "#8dbaff";
    LevitateDarkTheme["particleDarkStatusInfoLow"] = "rgba(100,161,255,0.28)";
    LevitateDarkTheme["particleDarkValidationInfoHigh"] = "#5a9aff";
    LevitateDarkTheme["particleDarkValidationInfoLow"] = "rgba(90,154,255,0.28)";
    LevitateDarkTheme["particleDarkValidationSuccessHigh"] = "#48db81";
    LevitateDarkTheme["particleDarkValidationSuccessLow"] = "rgba(72,219,129,0.28)";
    LevitateDarkTheme["particleDarkValidationWarningHigh"] = "#ff9e59";
    LevitateDarkTheme["particleDarkValidationWarningLow"] = "rgba(255,158,89,0.28)";
    LevitateDarkTheme["particleDarkValidationErrorHigh"] = "#f95670";
    LevitateDarkTheme["particleDarkValidationErrorLow"] = "rgba(249,86,112,0.28)";
    LevitateDarkTheme["particleDarkDividerLine"] = "rgba(255,255,255,0.15)";
    LevitateDarkTheme["particleDarkChartColor1"] = "#d3bbff";
    LevitateDarkTheme["particleDarkChartColor2"] = "#7b5dff";
    LevitateDarkTheme["particleDarkChartColor3"] = "#68cfce";
    LevitateDarkTheme["particleDarkChartColor4"] = "#f072a9";
    LevitateDarkTheme["particleDarkChartColor5"] = "#6a97ff";
    LevitateDarkTheme["particleDarkChartColor6"] = "#fdc960";
    LevitateDarkTheme["particleDarkChartColor7"] = "#089192";
    LevitateDarkTheme["particleDarkChartColor8"] = "#e14874";
    LevitateDarkTheme["particleDarkChartColor9"] = "#ffeaea";
    LevitateDarkTheme["particleDarkChartColor10"] = "#c77963";
    LevitateDarkTheme["particleDarkChartColor11"] = "white";
    LevitateDarkTheme["particleDarkChartColor12"] = "#cec3ff";
    LevitateDarkTheme["particleDarkChartColor13"] = "#b5e8e7";
    LevitateDarkTheme["particleDarkChartColor14"] = "#facee1";
    LevitateDarkTheme["particleDarkChartColor15"] = "#d0deff";
    LevitateDarkTheme["particleDarkChartColor16"] = "#feebc5";
    LevitateDarkTheme["particleDarkChartColor17"] = "#0ef0f2";
    LevitateDarkTheme["particleDarkChartColor18"] = "#efa0b7";
    LevitateDarkTheme["particleDarkChartColor19"] = "white";
    LevitateDarkTheme["particleDarkChartColor20"] = "#e2b9ae";
    LevitateDarkTheme["particleDarkChartColor21"] = "#9155ff";
    LevitateDarkTheme["particleDarkChartColor22"] = "#2e00f6";
    LevitateDarkTheme["particleDarkChartColor23"] = "#329f9e";
    LevitateDarkTheme["particleDarkChartColor24"] = "#e41871";
    LevitateDarkTheme["particleDarkChartColor25"] = "#0450ff";
    LevitateDarkTheme["particleDarkChartColor26"] = "#f4a403";
    LevitateDarkTheme["particleDarkChartColor27"] = "#033131";
    LevitateDarkTheme["particleDarkChartColor28"] = "#a81b44";
    LevitateDarkTheme["particleDarkChartColor29"] = "#ff8484";
    LevitateDarkTheme["particleDarkChartColor30"] = "#904834";
    LevitateDarkTheme["particleDarkTransparent"] = "rgba(255,255,255,0)";
    LevitateDarkTheme["particleDarkGlobalFontColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkLinkColor"] = "rgba(138,95,255,0.28)";
    LevitateDarkTheme["particleDarkFocusBoxColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkInvalidBackgroundColor"] = "rgba(249,86,91,0.28)";
    LevitateDarkTheme["particleDarkShadowColor"] = "rgba(0,0,0,0.1)";
    LevitateDarkTheme["particleDarkHtmlColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkBodyColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkH1Color"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkH1ErrorColor"] = "#f95670";
    LevitateDarkTheme["particleDarkH2Color"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkH3Color"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkH4Color"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkAColor"] = "#cbadff";
    LevitateDarkTheme["particleDarkAHoverColor"] = "#cbadff";
    LevitateDarkTheme["particleDarkSubtitleColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkWizardStepLabelColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkWizardStepLabelHoverColor"] = "#cbadff";
    LevitateDarkTheme["particleDarkButtonLabelColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkButtonLabelDisabledColor"] = "rgba(255,255,255,0.38)";
    LevitateDarkTheme["particleDarkNavigationButtonDefaultColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkNavigationButtonSelectedColor"] = "#cbadff";
    LevitateDarkTheme["particleDarkSectionHeaderColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkPanelHeaderColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkTextLabelColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkTextSelectedColor"] = "#cbadff";
    LevitateDarkTheme["particleDarkTextHoverColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkTextDisabledColor"] = "rgba(255,255,255,0.38)";
    LevitateDarkTheme["particleDarkTextPlaceholderColor"] = "rgba(255,255,255,0.38)";
    LevitateDarkTheme["particleDarkTextHintColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkTextValidationErrorColor"] = "#f95670";
    LevitateDarkTheme["particleDarkTextValidationWarningColor"] = "#ff9e59";
    LevitateDarkTheme["particleDarkTextValidationSuccessColor"] = "#48db81";
    LevitateDarkTheme["particleDarkBodyErrorColor"] = "#f95670";
    LevitateDarkTheme["particleDarkBodyWarningColor"] = "#ff9e59";
    LevitateDarkTheme["particleDarkBodySuccessColor"] = "#48db81";
    LevitateDarkTheme["particleDarkGridHeaderColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkBodySmallColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkBodySmallLabelColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkBodyFixedWidthColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkBodyFixedWidthWhiteColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkCardTitleEditInPlaceColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkCardSubtitleColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkCardDrilldownTitleTextColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkNavigationMainBackgroundColor"] = "#262939";
    LevitateDarkTheme["particleDarkNavigationMainItemFocusedBorderColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkNavigationMainItemHoverBackgroundColor"] = "rgba(216,216,216,0.18)";
    LevitateDarkTheme["particleDarkNavigationMainItemIconDefaultColor"] = "rgba(255,255,255,0.46)";
    LevitateDarkTheme["particleDarkNavigationMainItemIconFocusedColor"] = "rgba(255,255,255,0.6)";
    LevitateDarkTheme["particleDarkNavigationMainItemIconHoverColor"] = "rgba(255,255,255,0.7)";
    LevitateDarkTheme["particleDarkNavigationMainItemIconSelectedColor"] = "white";
    LevitateDarkTheme["particleDarkBannerErrorBackgroundColor"] = "rgba(249,86,91,0.28)";
    LevitateDarkTheme["particleDarkBannerErrorBorderColor"] = "#fa7d81";
    LevitateDarkTheme["particleDarkBannerInfoBackgroundColor"] = "rgba(100,161,255,0.28)";
    LevitateDarkTheme["particleDarkBannerInfoBorderColor"] = "#8dbaff";
    LevitateDarkTheme["particleDarkBannerMessageTextColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkBannerSuccessBackgroundColor"] = "rgba(73,220,128,0.28)";
    LevitateDarkTheme["particleDarkBannerSuccessBorderColor"] = "#6be398";
    LevitateDarkTheme["particleDarkBannerTitleTextColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkBannerWarningBackgroundColor"] = "rgba(255,215,105,0.28)";
    LevitateDarkTheme["particleDarkBannerWarningBorderColor"] = "#ffe292";
    LevitateDarkTheme["particleDarkButtonBackgroundColor"] = "rgba(255,255,255,0.1)";
    LevitateDarkTheme["particleDarkButtonHoverBackgroundColor"] = "rgba(255,255,255,0.34)";
    LevitateDarkTheme["particleDarkButtonCdkKeyboardFocusedBoxShadow"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkButtonMaterialColor"] = "rgba(255,255,255,0.38)";
    LevitateDarkTheme["particleDarkButtonMaterialRoleBackgroundColor"] = "rgba(255,255,255,0.06)";
    LevitateDarkTheme["particleDarkButtonRolePrimaryBackgroundColor"] = "#8a5fff";
    LevitateDarkTheme["particleDarkButtonRolePrimaryCdkKeyboardFocusedBoxShadow"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkButtonRolePrimaryColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkButtonRolePrimaryHoverBackgroundColor"] = "#9e7eff";
    LevitateDarkTheme["particleDarkButtonTextColorDisabled"] = "rgba(255,255,255,0.38)";
    LevitateDarkTheme["particleDarkButtonTextColorInverse"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkButtonTextColorPrimary"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkButtonToggledBackgroundColor"] = "#8a5fff";
    LevitateDarkTheme["particleDarkButtonToggledColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkButtonIconBackgroundColor"] = "#323433";
    LevitateDarkTheme["particleDarkButtonIconHoverColor"] = "rgba(255,255,255,0.34)";
    LevitateDarkTheme["particleDarkBreadcrumbTextColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkBreadcrumbTextSelectedColor"] = "#cbadff";
    LevitateDarkTheme["particleDarkBreadcrumbPopoverTextColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkCardBackgroundColor"] = "#16192a";
    LevitateDarkTheme["particleDarkCardHoverToolbarBackgroundColor"] = "#16192a";
    LevitateDarkTheme["particleDarkCardSelectedBorderColor"] = "#9e7eff";
    LevitateDarkTheme["particleDarkChartAxisTextColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkChartLegendTextColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkChartTextColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkChartTooltipBackground"] = "#3c4050";
    LevitateDarkTheme["particleDarkChartTooltipBackgroundColor"] = "#3c4050";
    LevitateDarkTheme["particleDarkChartTooltipTextColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkIconDisabledColor"] = "rgba(255,255,255,0.06)";
    LevitateDarkTheme["particleDarkIconInverseColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkIconNavActiveColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkIconNormalColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkIconSelectedColor"] = "#cbadff";
    LevitateDarkTheme["particleDarkLegendItemHoverNotSelectedBackgroundColor"] = "#323433";
    LevitateDarkTheme["particleDarkLegendItemHoverSelectedBackgroundColor"] = "#9e7eff";
    LevitateDarkTheme["particleDarkLegendItemSelectedBackgroundColor"] = "#bca5ff";
    LevitateDarkTheme["particleDarkLegendItemTextColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkCartesianAxisLabelTextColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkCartesianAxisTitleTextColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkCartesianLegendHoverBackgroundColor"] = "rgba(255,255,255,0.34)";
    LevitateDarkTheme["particleDarkCartesianGridBorderColor"] = "rgba(255,255,255,0.38)";
    LevitateDarkTheme["particleDarkCartesianPlotBandNeutralColor"] = "#b1b5ca";
    LevitateDarkTheme["particleDarkCartesianPlotBandCriticalColor"] = "#f9565b";
    LevitateDarkTheme["particleDarkCartesianPlotBandWarningColor"] = "#ffd769";
    LevitateDarkTheme["particleDarkCartesianTimeScrubberSelectedBackgroundColor"] = "#9e7eff";
    LevitateDarkTheme["particleDarkCartesianTimeScrubberTickMarkLineColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkCartesianTimeScrubberBorderColor"] = "rgba(255,255,255,0.34)";
    LevitateDarkTheme["particleDarkCartesianTimeScrubberDragLineColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkSparkLineBarFillColor"] = "#d3bbff";
    LevitateDarkTheme["particleDarkSparkLineStrokeColor"] = "#d3bbff";
    LevitateDarkTheme["particleDarkChartsLabelTextColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkChartsLegendItemHoverBackgroundColor"] = "#323433";
    LevitateDarkTheme["particleDarkChartsLegendTextColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkChartsPieCenterLabelTextColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkChartsPieZeroBorderColor"] = "rgba(255,255,255,0.38)";
    LevitateDarkTheme["particleDarkChartsPieNullFill"] = "rgba(255,255,255,0.1)";
    LevitateDarkTheme["particleDarkChartsTooltipBackgroundColor"] = "#323433";
    LevitateDarkTheme["particleDarkChartsTooltipTextColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkDescriptionColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkCarouselDescriptionColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkCarouselBackgroundColor"] = "#4f5361";
    LevitateDarkTheme["particleDarkCarouselPaginateCircleBackgroundColor"] = "rgba(255,255,255,0.38)";
    LevitateDarkTheme["particleDarkCarouselPaginateCircleHoverBackgroundColor"] = "rgba(255,255,255,0.38)";
    LevitateDarkTheme["particleDarkCarouselPaginateCircleSelectedBackgroundColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkCarouselPaginateIconColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkContextMenuItemHoverBackgroundColor"] = "#3c4050";
    LevitateDarkTheme["particleDarkCheckboxBorderColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkCheckboxCheckColor"] = "white";
    LevitateDarkTheme["particleDarkCheckboxCheckedBackgroundColor"] = "#9e7eff";
    LevitateDarkTheme["particleDarkCheckboxDisabledBackgroundColor"] = "rgba(255,255,255,0.34)";
    LevitateDarkTheme["particleDarkCheckboxDisabledCheckColor"] = "#323433";
    LevitateDarkTheme["particleDarkCheckboxDisabledBorderColor"] = "rgba(255,255,255,0.34)";
    LevitateDarkTheme["particleDarkCheckboxIndeterminateCheckColor"] = "white";
    LevitateDarkTheme["particleDarkCheckboxMixedColor"] = "white";
    LevitateDarkTheme["particleDarkDatePickerBackgroundColor"] = "#3c4050";
    LevitateDarkTheme["particleDarkDatePickerBorderColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkDatePickerCalendarHoverColor"] = "#9e7eff";
    LevitateDarkTheme["particleDarkDatePickerCalendarTextColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkDatePickerDisabledTextColor"] = "rgba(255,255,255,0.38)";
    LevitateDarkTheme["particleDarkDatePickerErrorBackgroundColor"] = "rgba(249,86,112,0.28)";
    LevitateDarkTheme["particleDarkDatePickerErrorBorderColor"] = "rgba(249,86,112,0.28)";
    LevitateDarkTheme["particleDarkDatePickerFocusBackgroundColor"] = "rgba(255,255,255,0.1)";
    LevitateDarkTheme["particleDarkDatePickerFocusBorderColor"] = "#9e7eff";
    LevitateDarkTheme["particleDarkDatePickerFocusHoverColor"] = "rgba(255,255,255,0.1)";
    LevitateDarkTheme["particleDarkDatePickerFocusUnderlineColor"] = "#9e7eff";
    LevitateDarkTheme["particleDarkDatePickerHoverUnderlineColor"] = "#9e7eff";
    LevitateDarkTheme["particleDarkDatePickerInputTextColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkDatePickerInvalidUnderlineColor"] = "rgba(249,86,112,0.28)";
    LevitateDarkTheme["particleDarkDatePickerSelectedColor"] = "#8a5fff";
    LevitateDarkTheme["particleDarkDialogConfirmationFooterBackgroundColor"] = "#4f5361";
    LevitateDarkTheme["particleDarkDialogConfirmationMessageBackgroundColor"] = "#4f5361";
    LevitateDarkTheme["particleDarkDialogContentBackgroundColor"] = "#4f5361";
    LevitateDarkTheme["particleDarkDialogHeaderBackgroundColor"] = "rgba(255,255,255,0.06)";
    LevitateDarkTheme["particleDarkDialogHeaderBorderBottomColor"] = "rgba(255,255,255,0.15)";
    LevitateDarkTheme["particleDarkEditableLabelTextareaCdkKeyboardFocusedColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkEditableLabelTextareaColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkExpanderHeaderCdkKeyboardFocusedBorder"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkExpanderHeaderHoverBackgroundColor"] = "#323433";
    LevitateDarkTheme["particleDarkExpanderLabelColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkFilterPanelOverlayBackgroundColor"] = "#262939";
    LevitateDarkTheme["particleDarkFilterPanelOverlayFooterBorderTopColor"] = "rgba(255,255,255,0.38)";
    LevitateDarkTheme["particleDarkFilterPanelOverlayResizeHoverBackgroundColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkFilterPanelTriggerCountBackgroundColor"] = "#3c4050";
    LevitateDarkTheme["particleDarkFilterPanelTriggerCountColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkFormCheckboxDescriptionColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkFormCheckboxLabelColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkFormCheckboxRightLabelColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkFormCheckboxNotSelectedStrokeColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkFormCheckboxNotSelectedDisabledStrokeColor"] = "rgba(255,255,255,0.34)";
    LevitateDarkTheme["particleDarkFormCheckboxNotSelectedHoverStrokeColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkFormCheckboxNotSelectedFocusedStrokeColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkFormCheckboxNotSelectedHoverBackgroundColor"] = "rgba(255,255,255,0.34)";
    LevitateDarkTheme["particleDarkFormCheckboxSelectedStrokeColor"] = "#9e7eff";
    LevitateDarkTheme["particleDarkFormCheckboxSelectedCheckStrokeColor"] = "white";
    LevitateDarkTheme["particleDarkFormCheckboxSelectedFillColor"] = "#9e7eff";
    LevitateDarkTheme["particleDarkFormCheckboxSelectedFocusedStrokeColor"] = "#9e7eff";
    LevitateDarkTheme["particleDarkFormCheckboxSelectedFocusedCheckStrokeColor"] = "white";
    LevitateDarkTheme["particleDarkFormCheckboxSelectedFocusedFillColor"] = "#9e7eff";
    LevitateDarkTheme["particleDarkFormCheckboxSelectedDisabledStrokeColor"] = "rgba(255,255,255,0.34)";
    LevitateDarkTheme["particleDarkFormCheckboxSelectedDisabledCheckStrokeColor"] = "rgba(255,255,255,0.38)";
    LevitateDarkTheme["particleDarkFormCheckboxSelectedDisabledFillColor"] = "rgba(255,255,255,0.34)";
    LevitateDarkTheme["particleDarkFormRadiobuttonNotSelectedStrokeColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkFormRadiobuttonNotSelectedFillColor"] = "#323433";
    LevitateDarkTheme["particleDarkFormRadiobuttonNotSelectedDisabledStrokeColor"] = "rgba(255,255,255,0.34)";
    LevitateDarkTheme["particleDarkFormRadiobuttonNotSelectedHoverStrokeColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkFormRadiobuttonNotSelectedHoverBackgroundColor"] = "rgba(255,255,255,0.1)";
    LevitateDarkTheme["particleDarkFormRadiobuttonNotSelectedFocusedStrokeColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkFormRadiobuttonSelectedStrokeColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkFormRadiobuttonSelectedFillColor"] = "#9e7eff";
    LevitateDarkTheme["particleDarkFormRadiobuttonSelectedDisabledStrokeColor"] = "rgba(255,255,255,0.34)";
    LevitateDarkTheme["particleDarkFormRadiobuttonSelectedDisabledFillColor"] = "rgba(255,255,255,0.34)";
    LevitateDarkTheme["particleDarkFormRadiobuttonSelectedHoverStrokeColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkFormRadiobuttonSelectedHoverFillColor"] = "#9e7eff";
    LevitateDarkTheme["particleDarkFormRadiobuttonSelectedHoverBackgroundColor"] = "rgba(255,255,255,0.1)";
    LevitateDarkTheme["particleDarkFormRadiobuttonSelectedFocusedStrokeColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkFormRadiobuttonSelectedFocusedFillColor"] = "#9e7eff";
    LevitateDarkTheme["particleDarkFormContainerBackgroundColor"] = "#3c4050";
    LevitateDarkTheme["particleDarkFormFieldBackgroundColor"] = "rgba(255,255,255,0.06)";
    LevitateDarkTheme["particleDarkFormFieldBorderBottom"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkFormFieldBorderColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkFormFieldClearBackgroundColor"] = "#323433";
    LevitateDarkTheme["particleDarkFormFieldDisabledBackgroundColor"] = "rgba(255,255,255,0.34)";
    LevitateDarkTheme["particleDarkFormFieldErrorBackgroundColor"] = "rgba(249,86,112,0.28)";
    LevitateDarkTheme["particleDarkFormFieldInvalidBorderColor"] = "#f95670";
    LevitateDarkTheme["particleDarkFormInputBackgroundColor"] = "rgba(255,255,255,0.06)";
    LevitateDarkTheme["particleDarkFormInputFocusedBackgroundColor"] = "rgba(255,255,255,0.1)";
    LevitateDarkTheme["particleDarkFormInputFocusedBorderColor"] = "#9e7eff";
    LevitateDarkTheme["particleDarkFormInputDisabledBackgroundColor"] = "#323433";
    LevitateDarkTheme["particleDarkFormInputDisabledColor"] = "rgba(255,255,255,0.38)";
    LevitateDarkTheme["particleDarkFormInputErrorBackgroundColor"] = "rgba(249,86,112,0.28)";
    LevitateDarkTheme["particleDarkFormInputErrorBorderColor"] = "#f95670";
    LevitateDarkTheme["particleDarkFormInputIconFill"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkFormInputNumberIconFill"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkGaugeBaselineColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkGaugeLabelTextColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkGaugeNeedleColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkGaugeTargetColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkGaugeBackgroundColor"] = "rgba(255,255,255,0.06)";
    LevitateDarkTheme["particleDarkGaugeZeroBorderColor"] = "rgba(255,255,255,0.1)";
    LevitateDarkTheme["particleDarkGaugeTooltipBackgroundColor"] = "#323433";
    LevitateDarkTheme["particleDarkGridLoadingRowGradientEnd"] = "transparent";
    LevitateDarkTheme["particleDarkGridLoadingRowGradientStart"] = "#6f7182";
    LevitateDarkTheme["particleDarkGridBackgroundColor"] = "transparent";
    LevitateDarkTheme["particleDarkGridFooterBackgroundColor"] = "transparent";
    LevitateDarkTheme["particleDarkGridFooterTextColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkGridHeaderTextColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkGridHeaderBackgroundColor"] = "transparent";
    LevitateDarkTheme["particleDarkGridRowBackgroundColor"] = "transparent";
    LevitateDarkTheme["particleDarkGridRowTextColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkGridIconCheckboxBackgroundColor"] = "transparent";
    LevitateDarkTheme["particleDarkGridRowHoverBackgroundColor"] = "rgba(138,95,255,0.28)";
    LevitateDarkTheme["particleDarkGridRowHoverTextColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkGridRowBorderColor"] = "rgba(255,255,255,0.15)";
    LevitateDarkTheme["particleDarkGridRowSelectedBackgroundColor"] = "rgba(138,95,255,0.6)";
    LevitateDarkTheme["particleDarkGridRowSelectedTextColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkHealthBarCriticalStatusBackgroundColor"] = "#f9565b";
    LevitateDarkTheme["particleDarkHealthBarNoDataStatusBackgroundColor"] = "rgba(255,255,255,0.06)";
    LevitateDarkTheme["particleDarkHealthBarNormalStatusBackgroundColor"] = "#49dc80";
    LevitateDarkTheme["particleDarkHealthBarUnknownStatusBackgroundColor"] = "#b1b5ca";
    LevitateDarkTheme["particleDarkHealthBarWarningStatusBackgroundColor"] = "#ffd769";
    LevitateDarkTheme["particleDarkHealthBarZeroBorderColor"] = "rgba(255,255,255,0.15)";
    LevitateDarkTheme["particleDarkHoverToolbarCardBackgroundColor"] = "#323433";
    LevitateDarkTheme["particleDarkHoverToolbarCardHoverToolbarBackgroundColor"] = "rgba(255,255,255,0.34)";
    LevitateDarkTheme["particleDarkListFooterBorderColor"] = "rgba(255,255,255,0.15)";
    LevitateDarkTheme["particleDarkListBackgroundColor"] = "#262939";
    LevitateDarkTheme["particleDarkListRowBorderColor"] = "rgba(255,255,255,0.15)";
    LevitateDarkTheme["particleDarkListRowHoverBackgroundColor"] = "rgba(138,95,255,0.28)";
    LevitateDarkTheme["particleDarkListRowSelectedBackgroundColor"] = "rgba(138,95,255,0.6)";
    LevitateDarkTheme["particleDarkListFooterTextColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkListRowFocusedBackgroundColor"] = "rgba(138,95,255,0.28)";
    LevitateDarkTheme["particleDarkListRowFocusedBorderLeftColor"] = "#8a5fff";
    LevitateDarkTheme["particleDarkListRowSelectedBorderLeftColor"] = "#8a5fff";
    LevitateDarkTheme["particleDarkListTextColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkLookupDialogDescriptionBorderBottomColor"] = "rgba(255,255,255,0.15)";
    LevitateDarkTheme["particleDarkLookupDropdownActionFocused"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkLookupDropdownActive"] = "#3c4050";
    LevitateDarkTheme["particleDarkLookupDropdownBorderBottom"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkLookupDropdownFocusBorderBottom"] = "#9e7eff";
    LevitateDarkTheme["particleDarkLookupDropdownHostBackgroundColor"] = "rgba(255,255,255,0.06)";
    LevitateDarkTheme["particleDarkLookupDropdownHoverBackgroundColor"] = "rgba(255,255,255,0.06)";
    LevitateDarkTheme["particleDarkLookupDropdownOptionFocused"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkLookupSearchBackgroundColor"] = "rgba(255,255,255,0.06)";
    LevitateDarkTheme["particleDarkLookupSearchFocusBackgroundColor"] = "rgba(255,255,255,0.1)";
    LevitateDarkTheme["particleDarkLookupSearchContainerDisabledBackgroundColor"] = "#262939";
    LevitateDarkTheme["particleDarkLookupSearchContainerDisabledColor"] = "rgba(255,255,255,0.38)";
    LevitateDarkTheme["particleDarkLookupSearchContainerInvalidBackgroundColor"] = "rgba(249,86,112,0.28)";
    LevitateDarkTheme["particleDarkMasterDetailsCardBackgroundColor"] = "#323433";
    LevitateDarkTheme["particleDarkMenuGroupActiveStateBackgroundColor"] = "#8a5fff";
    LevitateDarkTheme["particleDarkMenuGroupBackgroundColor"] = "#3c4050";
    LevitateDarkTheme["particleDarkMenuGroupLabelTextColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkMenuGroupLabelTextColorInverse"] = "#9e7eff";
    LevitateDarkTheme["particleDarkMenuGroupMatButtonDisabledColor"] = "rgba(255,255,255,0.06)";
    LevitateDarkTheme["particleDarkMenuItemButtonFocusBackgroundColor"] = "rgba(255,255,255,0.38)";
    LevitateDarkTheme["particleDarkMenuItemButtonHoverBackgroundColor"] = "rgba(138,95,255,0.6)";
    LevitateDarkTheme["particleDarkMenuItemButtonSecondaryColor"] = "rgba(203,173,255,0.6)";
    LevitateDarkTheme["particleDarkMenuItemDividerBorderColor"] = "rgba(255,255,255,0.15)";
    LevitateDarkTheme["particleDarkMenuItemSelectedColor"] = "#8a5fff";
    LevitateDarkTheme["particleDarkMenuItemFocusBackgroundColor"] = "rgba(255,255,255,0.38)";
    LevitateDarkTheme["particleDarkMenuItemHoverBackgroundColor"] = "rgba(138,95,255,0.6)";
    LevitateDarkTheme["particleDarkMenuBackgroundColor"] = "#3c4050";
    LevitateDarkTheme["particleDarkNumericLabelDeltaContainerLabelGreen"] = "#49dc80";
    LevitateDarkTheme["particleDarkNumericLabelDeltaContainerLabelRed"] = "#f9565b";
    LevitateDarkTheme["particleDarkPanelBackgroundColor"] = "#262939";
    LevitateDarkTheme["particleDarkPanelBorderColor"] = "#f95670";
    LevitateDarkTheme["particleDarkPanelTextColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkPillBackgroundColor"] = "rgba(255,255,255,0.34)";
    LevitateDarkTheme["particleDarkPillIconColor"] = "rgba(255,255,255,0.38)";
    LevitateDarkTheme["particleDarkPillHoverIconColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkPillDisabledBackgroundColor"] = "rgba(255,255,255,0.1)";
    LevitateDarkTheme["particleDarkPillDisabledIconColor"] = "rgba(255,255,255,0.15)";
    LevitateDarkTheme["particleDarkPillFocusedBackgroundColor"] = "rgba(255,255,255,0.38)";
    LevitateDarkTheme["particleDarkPillFocusedBorderColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkPillFocusedIconColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkPillBorderColor"] = "rgba(255,255,255,0.34)";
    LevitateDarkTheme["particleDarkProgressBarContainerBackgroundColor"] = "#b1b5ca";
    LevitateDarkTheme["particleDarkProgressBarGradientEnd"] = "#6f7182";
    LevitateDarkTheme["particleDarkProgressBarGradientStart"] = "#9e7eff";
    LevitateDarkTheme["particleDarkProgressBarLoadedBackgroundColor"] = "#b1b5ca";
    LevitateDarkTheme["particleDarkRepeaterActiveBorderColor"] = "#bca5ff";
    LevitateDarkTheme["particleDarkRadioDotBorderColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkRadioBackgroundHoverColor"] = "rgba(255,255,255,0.34)";
    LevitateDarkTheme["particleDarkRadioDotBorderFocusedColor"] = "rgba(255,255,255,0.34)";
    LevitateDarkTheme["particleDarkRadioDotColor"] = "#9e7eff";
    LevitateDarkTheme["particleDarkRadioDotDisabledColor"] = "rgba(255,255,255,0.34)";
    LevitateDarkTheme["particleDarkRadioTextColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkRadioTextDisabledColor"] = "rgba(255,255,255,0.38)";
    LevitateDarkTheme["particleDarkRepeaterAddButtonActiveBorderColor"] = "rgba(255,255,255,0.34)";
    LevitateDarkTheme["particleDarkRepeaterBorderColor"] = "rgba(255,255,255,0.34)";
    LevitateDarkTheme["particleDarkRepeaterHoverBorderColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkScoreBarRemainingStatusBackgroundColor"] = "rgba(255,255,255,0.06)";
    LevitateDarkTheme["particleDarkScoreBarZeroBorderColor"] = "rgba(255,255,255,0.15)";
    LevitateDarkTheme["particleDarkScrollBoxScrollbarColor"] = "rgba(255,255,255,0.38)";
    LevitateDarkTheme["particleDarkScrollBoxScrollbarFocusColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkSearchBoxContainerBorderColor"] = "#323433";
    LevitateDarkTheme["particleDarkSearchBoxContainerFocusWithinBorder"] = "#9e7eff";
    LevitateDarkTheme["particleDarkSearchBoxHoverBorderColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkSearchBoxSearchIconsSeparatorColor"] = "rgba(255,255,255,0.38)";
    LevitateDarkTheme["particleDarkSearchBoxBackgroundColor"] = "rgba(255,255,255,0.06)";
    LevitateDarkTheme["particleDarkSearchBoxHoverBackgroundColor"] = "rgba(255,255,255,0.1)";
    LevitateDarkTheme["particleDarkSelectDropdownBorderBottom"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkSelectDropdownActiveBackgroundColor"] = "rgba(255,255,255,0.1)";
    LevitateDarkTheme["particleDarkSelectDropdownActiveBorderColor"] = "#9e7eff";
    LevitateDarkTheme["particleDarkSelectDropdownHostBackgroundColor"] = "rgba(255,255,255,0.06)";
    LevitateDarkTheme["particleDarkSelectDropdownHoverBackgroundColor"] = "rgba(255,255,255,0.1)";
    LevitateDarkTheme["particleDarkSelectDropdownOptionActive"] = "rgba(138,95,255,0.6)";
    LevitateDarkTheme["particleDarkSelectDropdownOptionFocused"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkSelectListOptionActiveBackgroundColor"] = "rgba(138,95,255,0.6)";
    LevitateDarkTheme["particleDarkSelectListOptionHoverBackgroundColor"] = "rgba(138,95,255,0.6)";
    LevitateDarkTheme["particleDarkSelectListOptionSelectedBackgroundColor"] = "#8a5fff";
    LevitateDarkTheme["particleDarkSelectPlaceholderBackgroundColor"] = "rgba(138,95,255,0.6)";
    LevitateDarkTheme["particleDarkSelectPlaceholderColor"] = "rgba(255,255,255,0.38)";
    LevitateDarkTheme["particleDarkSelectPlaceholderErrorBackgroundColor"] = "rgba(249,86,112,0.28)";
    LevitateDarkTheme["particleDarkSelectSelectedValuesBackgroundColor"] = "#8a5fff";
    LevitateDarkTheme["particleDarkSelectSelectedValuesColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkSelectionTileBackgroundColor"] = "rgba(255,255,255,0.1)";
    LevitateDarkTheme["particleDarkSelectionTileContentColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkSelectionTileTitleColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkSelectionTileDisabledBackgroundColor"] = "rgba(255,255,255,0.06)";
    LevitateDarkTheme["particleDarkSelectionTileDisabledColor"] = "rgba(138,95,255,0.28)";
    LevitateDarkTheme["particleDarkSelectionTileHoverBackgroundColor"] = "rgba(138,95,255,0.28)";
    LevitateDarkTheme["particleDarkSelectionTileHoverColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkSelectionTileSelectedBackgroundColor"] = "rgba(138,95,255,0.6)";
    LevitateDarkTheme["particleDarkSelectionTileSelectedLineColor"] = "rgba(138,95,255,0.6)";
    LevitateDarkTheme["particleDarkSelectionTileFocusBorderColor"] = "white";
    LevitateDarkTheme["particleDarkShimmerBarGradientEnd"] = "#6f7182";
    LevitateDarkTheme["particleDarkShimmerBarGradientStart"] = "#b1b5ca";
    LevitateDarkTheme["particleDarkShimmerCheckboxGradientEnd"] = "#6f7182";
    LevitateDarkTheme["particleDarkShimmerCheckboxGradientStart"] = "#b1b5ca";
    LevitateDarkTheme["particleDarkSparkBarEmptyBackgroundColor"] = "rgba(255,255,255,0.06)";
    LevitateDarkTheme["particleDarkTabHeaderActiveBarBackgroundColor"] = "#8a5fff";
    LevitateDarkTheme["particleDarkTabHeaderHorizontalBarBackgroundColor"] = "rgba(255,255,255,0.15)";
    LevitateDarkTheme["particleDarkTabHeaderHostVerticalBorderRight"] = "rgba(255,255,255,0.15)";
    LevitateDarkTheme["particleDarkTabHeaderLabelWrapperActiveColor"] = "#8a5fff";
    LevitateDarkTheme["particleDarkTabHeaderLabelWrapperCdkFocusedBorderColor"] = "rgba(138,95,255,0.6)";
    LevitateDarkTheme["particleDarkTabHeaderLabelWrapperDisabledColor"] = "rgba(255,255,255,0.38)";
    LevitateDarkTheme["particleDarkTabHeaderLabelWrapperHoverColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkTextareaFormFieldBackgroundColor"] = "rgba(255,255,255,0.06)";
    LevitateDarkTheme["particleDarkTextareaFormFieldBorderBottom"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkTextareaFormFieldCaretColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkTextareaFormFieldDisabledBackgroundColor"] = "#323433";
    LevitateDarkTheme["particleDarkTextareaFormFieldDisabledColor"] = "rgba(255,255,255,0.38)";
    LevitateDarkTheme["particleDarkTextareaFormFieldErrorBackgroundColor"] = "rgba(249,86,112,0.28)";
    LevitateDarkTheme["particleDarkTextareaFormFieldErrorColor"] = "rgba(249,86,112,0.28)";
    LevitateDarkTheme["particleDarkTextareaFormFieldFocusBackgroundColor"] = "rgba(255,255,255,0.1)";
    LevitateDarkTheme["particleDarkTextareaFormFieldFocusBorderColor"] = "#9e7eff";
    LevitateDarkTheme["particleDarkTextareaFormFieldHoverBorderColor"] = "#9e7eff";
    LevitateDarkTheme["particleDarkTimePickerDisabledIconColor"] = "rgba(255,255,255,0.06)";
    LevitateDarkTheme["particleDarkTimePickerDisabledInputBackgroundColor"] = "#323433";
    LevitateDarkTheme["particleDarkTimePickerDisabledInputColor"] = "rgba(255,255,255,0.38)";
    LevitateDarkTheme["particleDarkTimePickerErrorBackgroundColor"] = "rgba(249,86,112,0.28)";
    LevitateDarkTheme["particleDarkTimePickerIconFill"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkTimePickerInputBackgroundColor"] = "rgba(255,255,255,0.06)";
    LevitateDarkTheme["particleDarkTimePickerInputFocusBackgroundColor"] = "rgba(255,255,255,0.1)";
    LevitateDarkTheme["particleDarkTimePickerInputFocusBorderColor"] = "#9e7eff";
    LevitateDarkTheme["particleDarkTimePickerInputBorderColor"] = "#9e7eff";
    LevitateDarkTheme["particleDarkTimeRangeSelectorCustomDividerColor"] = "rgba(255,255,255,0.15)";
    LevitateDarkTheme["particleDarkTimeRangeSelectorCustomManageGrid"] = "white";
    LevitateDarkTheme["particleDarkTimeRangeSelectorOverlayBackgroundColor"] = "#3c4050";
    LevitateDarkTheme["particleDarkTimeRangeSelectorStandardDividerColor"] = "rgba(255,255,255,0.15)";
    LevitateDarkTheme["particleDarkTimelineBarBackgroundColor"] = "rgba(255,255,255,0.1)";
    LevitateDarkTheme["particleDarkTimelineBarDefaultCriticalColor"] = "#f9565b";
    LevitateDarkTheme["particleDarkTimelineBarDefaultStallColor"] = "#d3bbff";
    LevitateDarkTheme["particleDarkTimelineBarDefaultSuccessColor"] = "#49dc80";
    LevitateDarkTheme["particleDarkTimelineBarDefaultWarningColor"] = "#ffd769";
    LevitateDarkTheme["particleDarkTimelineBarDefaultVerySlowColor"] = "#ffe292";
    LevitateDarkTheme["particleDarkTimelineBarGridLineColor"] = "rgba(255,255,255,0.15)";
    LevitateDarkTheme["particleDarkTimelineBarLabelTextColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkTimelineBarLabelTextOutlineColor"] = "#323433";
    LevitateDarkTheme["particleDarkTimelineBarSelectedBorderColor"] = "#cbadff";
    LevitateDarkTheme["particleDarkTimelineBarTitleTextColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkTimelineBarTitleTextOutlineColor"] = "#323433";
    LevitateDarkTheme["particleDarkToastBackgroundColor"] = "#3c4050";
    LevitateDarkTheme["particleDarkToastHoverBackgroundColor"] = "#323433";
    LevitateDarkTheme["particleDarkToastTextLabelColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkToastTextMessageColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkToggleGroupToggleOptionBackgroundColor"] = "#323433";
    LevitateDarkTheme["particleDarkToggleGroupToggleOptionCheckedBackgroundColor"] = "#8a5fff";
    LevitateDarkTheme["particleDarkToggleGroupToggleOptionCheckedColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkToggleGroupToggleOptionChecked"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkToggleGroupToggleOptionDisabledBackgroundColor"] = "#323433";
    LevitateDarkTheme["particleDarkToggleGroupToggleOptionDisabledColor"] = "rgba(138,95,255,0.28)";
    LevitateDarkTheme["particleDarkToggleGroupToggleOptionFocusBackgroundColor"] = "#323433";
    LevitateDarkTheme["particleDarkToggleGroupToggleOptionHoverBackgroundColor"] = "rgba(255,255,255,0.34)";
    LevitateDarkTheme["particleDarkToggleGroupToggleOptionHoverColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkToggleGroupTextColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkToggleGroupTextColorDisabled"] = "rgba(255,255,255,0.38)";
    LevitateDarkTheme["particleDarkToggleGroupTextColorSelected"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkToggleSwitchOffBarColor"] = "rgba(255,255,255,0.1)";
    LevitateDarkTheme["particleDarkToggleSwitchOffThumbColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkToggleSwitchOnBarColor"] = "rgba(255,255,255,0.1)";
    LevitateDarkTheme["particleDarkToggleSwitchOnThumbColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkToggleSwitchOffBackgroundColor"] = "rgba(255,255,255,0.1)";
    LevitateDarkTheme["particleDarkToggleSwitchOffCircleColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkToggleSwitchOffFocusBorderColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkToggleSwitchOffDisabledBackgroundColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkToggleSwitchOffDisabledCircleColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkToggleSwitchOnBackgroundColor"] = "rgba(255,255,255,0.1)";
    LevitateDarkTheme["particleDarkToggleSwitchOnCircleColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkToggleSwitchOnFocusBorderColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkToggleSwitchOnDisabledBackgroundColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkToggleSwitchOnDisabledCircleColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkToolbarBorderColor"] = "rgba(255,255,255,0.15)";
    LevitateDarkTheme["particleDarkToolbarDividerColor"] = "rgba(255,255,255,0.15)";
    LevitateDarkTheme["particleDarkToolbarStandaloneBackgroundColor"] = "#323433";
    LevitateDarkTheme["particleDarkTooltipExitButtonBackgroundColor"] = "#323433";
    LevitateDarkTheme["particleDarkWizardBannerBackgroundColor"] = "#323433";
    LevitateDarkTheme["particleDarkWizardBannerBorderColor"] = "rgba(255,255,255,0.15)";
    LevitateDarkTheme["particleDarkWizardNavigationActiveIconBackgroundColor"] = "#8a5fff";
    LevitateDarkTheme["particleDarkWizardNavigationActiveIconColor"] = "rgba(255,255,255,0.94)";
    LevitateDarkTheme["particleDarkWizardNavigationDividerColor"] = "rgba(255,255,255,0.15)";
    LevitateDarkTheme["particleDarkWizardNavigationErrorIconBorderColor"] = "#f95670";
    LevitateDarkTheme["particleDarkWizardNavigationFadeContainerGradientColor"] = "rgba(255,255,255,0.64)";
    LevitateDarkTheme["particleDarkWizardNavigationHostBackgroundColor"] = "#323433";
    LevitateDarkTheme["particleDarkWizardNavigationUnvisitableBorderColor"] = "rgba(255,255,255,0.34)";
    LevitateDarkTheme["particleDarkWizardNavigationUnvisitableColor"] = "rgba(255,255,255,0.34)";
    LevitateDarkTheme["particleDarkWizardNavigationValidBorderColor"] = "#9e7eff";
    LevitateDarkTheme["particleDarkWizardNavigationValidDividerColor"] = "#9e7eff";
    LevitateDarkTheme["particleDarkWizardNavigationVisitableBorderColor"] = "#9e7eff";
    LevitateDarkTheme["particleDarkWizardNavigationVisitableColor"] = "rgba(255,255,255,0.64)";
})(LevitateDarkTheme || (LevitateDarkTheme = {}));

var LevitateDarkThemeMapping = [
    {
        "name": "$particle-dark-primary-high",
        "value": "#8a5fff",
        "compiledValue": "#8a5fff"
    },
    {
        "name": "$particle-dark-primary-medium",
        "value": "change-color($particle-dark-primary-high, $alpha:0.6)",
        "mapValue": [
            {
                "name": "alpha",
                "value": "0.6",
                "compiledValue": "0.6"
            }
        ],
        "compiledValue": "rgba(138, 95, 255, 0.6)"
    },
    {
        "name": "$particle-dark-primary-low",
        "value": "change-color($particle-dark-primary-high, $alpha:0.28)",
        "mapValue": [
            {
                "name": "alpha",
                "value": "0.28",
                "compiledValue": "0.28"
            }
        ],
        "compiledValue": "rgba(138, 95, 255, 0.28)"
    },
    {
        "name": "$particle-dark-secondary-high",
        "value": "#cbadff",
        "compiledValue": "#cbadff"
    },
    {
        "name": "$particle-dark-secondary-medium",
        "value": "change-color($particle-dark-secondary-high, $alpha:0.6)",
        "mapValue": [
            {
                "name": "alpha",
                "value": "0.6",
                "compiledValue": "0.6"
            }
        ],
        "compiledValue": "rgba(203, 173, 255, 0.6)"
    },
    {
        "name": "$particle-dark-secondary-low",
        "value": "change-color($particle-dark-secondary-high, $alpha:0.38)",
        "mapValue": [
            {
                "name": "alpha",
                "value": "0.38",
                "compiledValue": "0.38"
            }
        ],
        "compiledValue": "rgba(203, 173, 255, 0.38)"
    },
    {
        "name": "$particle-dark-surface-1",
        "value": "#4f5361",
        "compiledValue": "#4f5361"
    },
    {
        "name": "$particle-dark-surface-2",
        "value": "#3c4050",
        "compiledValue": "#3c4050"
    },
    {
        "name": "$particle-dark-surface-3",
        "value": "#323433",
        "compiledValue": "#323433"
    },
    {
        "name": "$particle-dark-surface-4",
        "value": "#262939",
        "compiledValue": "#262939"
    },
    {
        "name": "$particle-dark-surface-5",
        "value": "#16192a",
        "compiledValue": "#16192a"
    },
    {
        "name": "$particle-dark-highlight-high-icon",
        "value": "white",
        "compiledValue": "white"
    },
    {
        "name": "$particle-dark-highlight-high",
        "value": "change-color($particle-dark-highlight-high-icon, $alpha:0.94)",
        "mapValue": [
            {
                "name": "alpha",
                "value": "0.94",
                "compiledValue": "0.94"
            }
        ],
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-highlight-medium",
        "value": "change-color($particle-dark-highlight-high-icon, $alpha:0.64)",
        "mapValue": [
            {
                "name": "alpha",
                "value": "0.64",
                "compiledValue": "0.64"
            }
        ],
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-highlight-low",
        "value": "change-color($particle-dark-highlight-high-icon, $alpha:0.38)",
        "mapValue": [
            {
                "name": "alpha",
                "value": "0.38",
                "compiledValue": "0.38"
            }
        ],
        "compiledValue": "rgba(255, 255, 255, 0.38)"
    },
    {
        "name": "$particle-dark-state-default",
        "value": "change-color(white,$alpha:0.10)",
        "mapValue": [
            {
                "name": "alpha",
                "value": "0.10",
                "compiledValue": "0.1"
            }
        ],
        "compiledValue": "rgba(255, 255, 255, 0.1)"
    },
    {
        "name": "$particle-dark-state-hover-or-disabled",
        "value": "change-color(white,$alpha:0.34)",
        "mapValue": [
            {
                "name": "alpha",
                "value": "0.34",
                "compiledValue": "0.34"
            }
        ],
        "compiledValue": "rgba(255, 255, 255, 0.34)"
    },
    {
        "name": "$particle-dark-state-low",
        "value": "change-color(white,$alpha:0.06)",
        "mapValue": [
            {
                "name": "alpha",
                "value": "0.06",
                "compiledValue": "0.06"
            }
        ],
        "compiledValue": "rgba(255, 255, 255, 0.06)"
    },
    {
        "name": "$particle-dark-state-pressed",
        "value": "change-color(black,$alpha:0.10)",
        "mapValue": [
            {
                "name": "alpha",
                "value": "0.10",
                "compiledValue": "0.1"
            }
        ],
        "compiledValue": "rgba(0, 0, 0, 0.1)"
    },
    {
        "name": "$particle-dark-primary-300",
        "value": "#9e7eff",
        "compiledValue": "#9e7eff"
    },
    {
        "name": "$particle-dark-primary-200",
        "value": "#bca5ff",
        "compiledValue": "#bca5ff"
    },
    {
        "name": "$particle-dark-primary-100",
        "value": "#d7c9fe",
        "compiledValue": "#d7c9fe"
    },
    {
        "name": "$particle-dark-primary-50",
        "value": "#f0eaff",
        "compiledValue": "#f0eaff"
    },
    {
        "name": "$particle-dark-grey-700",
        "value": "#6F7182",
        "compiledValue": "#6F7182"
    },
    {
        "name": "$particle-dark-grey-500",
        "value": "#B1B5CA",
        "compiledValue": "#B1B5CA"
    },
    {
        "name": "$particle-dark-status-normal-300",
        "value": "#49dc80",
        "compiledValue": "#49dc80"
    },
    {
        "name": "$particle-dark-status-normal-200",
        "value": "lighten($particle-dark-status-normal-300, 8%)",
        "compiledValue": "#6be398"
    },
    {
        "name": "$particle-dark-status-normal-low",
        "value": "change-color($particle-dark-status-normal-300, $alpha:0.28)",
        "mapValue": [
            {
                "name": "alpha",
                "value": "0.28",
                "compiledValue": "0.28"
            }
        ],
        "compiledValue": "rgba(73, 220, 128, 0.28)"
    },
    {
        "name": "$particle-dark-status-normal-graph",
        "value": "change-color($particle-dark-status-normal-200, $alpha:0.83)",
        "mapValue": [
            {
                "name": "alpha",
                "value": "0.83",
                "compiledValue": "0.83"
            }
        ],
        "compiledValue": "rgba(107, 227, 152, 0.83)"
    },
    {
        "name": "$particle-dark-status-warning-300",
        "value": "#ffd769",
        "compiledValue": "#ffd769"
    },
    {
        "name": "$particle-dark-status-warning-200",
        "value": "lighten($particle-dark-status-warning-300, 8%)",
        "compiledValue": "#ffe292"
    },
    {
        "name": "$particle-dark-status-warning-low",
        "value": "change-color($particle-dark-status-warning-300, $alpha:0.28)",
        "mapValue": [
            {
                "name": "alpha",
                "value": "0.28",
                "compiledValue": "0.28"
            }
        ],
        "compiledValue": "rgba(255, 215, 105, 0.28)"
    },
    {
        "name": "$particle-dark-status-critical-300",
        "value": "#f9565b",
        "compiledValue": "#f9565b"
    },
    {
        "name": "$particle-dark-status-critical-200",
        "value": "lighten($particle-dark-status-critical-300, 8%)",
        "compiledValue": "#fa7d81"
    },
    {
        "name": "$particle-dark-status-critical-low",
        "value": "change-color($particle-dark-status-critical-300, $alpha:0.28)",
        "mapValue": [
            {
                "name": "alpha",
                "value": "0.28",
                "compiledValue": "0.28"
            }
        ],
        "compiledValue": "rgba(249, 86, 91, 0.28)"
    },
    {
        "name": "$particle-dark-status-info-300",
        "value": "#64a1ff",
        "compiledValue": "#64a1ff"
    },
    {
        "name": "$particle-dark-status-info-200",
        "value": "lighten($particle-dark-status-info-300, 8%)",
        "compiledValue": "#8dbaff"
    },
    {
        "name": "$particle-dark-status-info-low",
        "value": "change-color($particle-dark-status-info-300, $alpha:0.28)",
        "mapValue": [
            {
                "name": "alpha",
                "value": "0.28",
                "compiledValue": "0.28"
            }
        ],
        "compiledValue": "rgba(100, 161, 255, 0.28)"
    },
    {
        "name": "$particle-dark-validation-info-high",
        "value": "#5a9aff",
        "compiledValue": "#5a9aff"
    },
    {
        "name": "$particle-dark-validation-info-low",
        "value": "change-color($particle-dark-validation-info-high, $alpha:0.28)",
        "mapValue": [
            {
                "name": "alpha",
                "value": "0.28",
                "compiledValue": "0.28"
            }
        ],
        "compiledValue": "rgba(90, 154, 255, 0.28)"
    },
    {
        "name": "$particle-dark-validation-success-high",
        "value": "#48db81",
        "compiledValue": "#48db81"
    },
    {
        "name": "$particle-dark-validation-success-low",
        "value": "change-color($particle-dark-validation-success-high, $alpha:0.28)",
        "mapValue": [
            {
                "name": "alpha",
                "value": "0.28",
                "compiledValue": "0.28"
            }
        ],
        "compiledValue": "rgba(72, 219, 129, 0.28)"
    },
    {
        "name": "$particle-dark-validation-warning-high",
        "value": "#ff9e59",
        "compiledValue": "#ff9e59"
    },
    {
        "name": "$particle-dark-validation-warning-low",
        "value": "change-color($particle-dark-validation-warning-high, $alpha:0.28)",
        "mapValue": [
            {
                "name": "alpha",
                "value": "0.28",
                "compiledValue": "0.28"
            }
        ],
        "compiledValue": "rgba(255, 158, 89, 0.28)"
    },
    {
        "name": "$particle-dark-validation-error-high",
        "value": "#f95670",
        "compiledValue": "#f95670"
    },
    {
        "name": "$particle-dark-validation-error-low",
        "value": "change-color($particle-dark-validation-error-high, $alpha:0.28)",
        "mapValue": [
            {
                "name": "alpha",
                "value": "0.28",
                "compiledValue": "0.28"
            }
        ],
        "compiledValue": "rgba(249, 86, 112, 0.28)"
    },
    {
        "name": "$particle-dark-divider-line",
        "value": "change-color(white,$alpha:0.15)",
        "mapValue": [
            {
                "name": "alpha",
                "value": "0.15",
                "compiledValue": "0.15"
            }
        ],
        "compiledValue": "rgba(255, 255, 255, 0.15)"
    },
    {
        "name": "$particle-dark-chart-color-1",
        "value": "#d3bbff",
        "compiledValue": "#d3bbff"
    },
    {
        "name": "$particle-dark-chart-color-2",
        "value": "#7b5dff",
        "compiledValue": "#7b5dff"
    },
    {
        "name": "$particle-dark-chart-color-3",
        "value": "#68cfce",
        "compiledValue": "#68cfce"
    },
    {
        "name": "$particle-dark-chart-color-4",
        "value": "#f072a9",
        "compiledValue": "#f072a9"
    },
    {
        "name": "$particle-dark-chart-color-5",
        "value": "#6a97ff",
        "compiledValue": "#6a97ff"
    },
    {
        "name": "$particle-dark-chart-color-6",
        "value": "#fdc960",
        "compiledValue": "#fdc960"
    },
    {
        "name": "$particle-dark-chart-color-7",
        "value": "#089192",
        "compiledValue": "#089192"
    },
    {
        "name": "$particle-dark-chart-color-8",
        "value": "#e14874",
        "compiledValue": "#e14874"
    },
    {
        "name": "$particle-dark-chart-color-9",
        "value": "#ffeaea",
        "compiledValue": "#ffeaea"
    },
    {
        "name": "$particle-dark-chart-color-10",
        "value": "#c77963",
        "compiledValue": "#c77963"
    },
    {
        "name": "$particle-dark-chart-color-11",
        "value": "lighten($particle-dark-chart-color-1, 20%)",
        "compiledValue": "white"
    },
    {
        "name": "$particle-dark-chart-color-12",
        "value": "lighten($particle-dark-chart-color-2, 20%)",
        "compiledValue": "#cec3ff"
    },
    {
        "name": "$particle-dark-chart-color-13",
        "value": "lighten($particle-dark-chart-color-3, 20%)",
        "compiledValue": "#b5e8e7"
    },
    {
        "name": "$particle-dark-chart-color-14",
        "value": "lighten($particle-dark-chart-color-4, 20%)",
        "compiledValue": "#facee1"
    },
    {
        "name": "$particle-dark-chart-color-15",
        "value": "lighten($particle-dark-chart-color-5, 20%)",
        "compiledValue": "#d0deff"
    },
    {
        "name": "$particle-dark-chart-color-16",
        "value": "lighten($particle-dark-chart-color-6, 20%)",
        "compiledValue": "#feebc5"
    },
    {
        "name": "$particle-dark-chart-color-17",
        "value": "lighten($particle-dark-chart-color-7, 20%)",
        "compiledValue": "#0ef0f2"
    },
    {
        "name": "$particle-dark-chart-color-18",
        "value": "lighten($particle-dark-chart-color-8, 20%)",
        "compiledValue": "#efa0b7"
    },
    {
        "name": "$particle-dark-chart-color-19",
        "value": "lighten($particle-dark-chart-color-9, 20%)",
        "compiledValue": "white"
    },
    {
        "name": "$particle-dark-chart-color-20",
        "value": "lighten($particle-dark-chart-color-10, 20%)",
        "compiledValue": "#e2b9ae"
    },
    {
        "name": "$particle-dark-chart-color-21",
        "value": "darken($particle-dark-chart-color-1, 20%)",
        "compiledValue": "#9155ff"
    },
    {
        "name": "$particle-dark-chart-color-22",
        "value": "darken($particle-dark-chart-color-2, 20%)",
        "compiledValue": "#2e00f6"
    },
    {
        "name": "$particle-dark-chart-color-23",
        "value": "darken($particle-dark-chart-color-3, 20%)",
        "compiledValue": "#329f9e"
    },
    {
        "name": "$particle-dark-chart-color-24",
        "value": "darken($particle-dark-chart-color-4, 20%)",
        "compiledValue": "#e41871"
    },
    {
        "name": "$particle-dark-chart-color-25",
        "value": "darken($particle-dark-chart-color-5, 20%)",
        "compiledValue": "#0450ff"
    },
    {
        "name": "$particle-dark-chart-color-26",
        "value": "darken($particle-dark-chart-color-6, 20%)",
        "compiledValue": "#f4a403"
    },
    {
        "name": "$particle-dark-chart-color-27",
        "value": "darken($particle-dark-chart-color-7, 20%)",
        "compiledValue": "#033131"
    },
    {
        "name": "$particle-dark-chart-color-28",
        "value": "darken($particle-dark-chart-color-8, 20%)",
        "compiledValue": "#a81b44"
    },
    {
        "name": "$particle-dark-chart-color-29",
        "value": "darken($particle-dark-chart-color-9, 20%)",
        "compiledValue": "#ff8484"
    },
    {
        "name": "$particle-dark-chart-color-30",
        "value": "darken($particle-dark-chart-color-10, 20%)",
        "compiledValue": "#904834"
    },
    {
        "name": "$particle-dark-transparent",
        "value": "change-color(white,$alpha:0.0)",
        "mapValue": [
            {
                "name": "alpha",
                "value": "0.0",
                "compiledValue": "0"
            }
        ],
        "compiledValue": "rgba(255, 255, 255, 0)"
    },
    {
        "name": "$particle-dark-global-font-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-link-color",
        "value": "#{$particle-dark-primary-low}",
        "compiledValue": "rgba(138, 95, 255, 0.28)"
    },
    {
        "name": "$particle-dark-focus-box-color",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-invalid-background-color",
        "value": "#{$particle-dark-status-critical-low}",
        "compiledValue": "rgba(249, 86, 91, 0.28)"
    },
    {
        "name": "$particle-dark-shadow-color",
        "value": "rgba(0,0,0,0.1)",
        "compiledValue": "rgba(0, 0, 0, 0.1)"
    },
    {
        "name": "$particle-dark-html-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-body-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-h1-color",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-h1-error-color",
        "value": "#{$particle-dark-validation-error-high}",
        "compiledValue": "#f95670"
    },
    {
        "name": "$particle-dark-h2-color",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-h3-color",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-h4-color",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-a-color",
        "value": "#{$particle-dark-secondary-high}",
        "compiledValue": "#cbadff"
    },
    {
        "name": "$particle-dark-a-hover-color",
        "value": "#{$particle-dark-secondary-high}",
        "compiledValue": "#cbadff"
    },
    {
        "name": "$particle-dark-subtitle-color",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-wizard-step-label-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-wizard-step-label-hover-color",
        "value": "#{$particle-dark-secondary-high}",
        "compiledValue": "#cbadff"
    },
    {
        "name": "$particle-dark-button-label-color",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-button-label-disabled-color",
        "value": "#{$particle-dark-highlight-low}",
        "compiledValue": "rgba(255, 255, 255, 0.38)"
    },
    {
        "name": "$particle-dark-navigation-button-default-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-navigation-button-selected-color",
        "value": "#{$particle-dark-secondary-high}",
        "compiledValue": "#cbadff"
    },
    {
        "name": "$particle-dark-section-header-color",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-panel-header-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-text-label-color",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-text-selected-color",
        "value": "#{$particle-dark-secondary-high}",
        "compiledValue": "#cbadff"
    },
    {
        "name": "$particle-dark-text-hover-color",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-text-disabled-color",
        "value": "#{$particle-dark-highlight-low}",
        "compiledValue": "rgba(255, 255, 255, 0.38)"
    },
    {
        "name": "$particle-dark-text-placeholder-color",
        "value": "#{$particle-dark-highlight-low}",
        "compiledValue": "rgba(255, 255, 255, 0.38)"
    },
    {
        "name": "$particle-dark-text-hint-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-text-validation-error-color",
        "value": "#{$particle-dark-validation-error-high}",
        "compiledValue": "#f95670"
    },
    {
        "name": "$particle-dark-text-validation-warning-color",
        "value": "#{$particle-dark-validation-warning-high}",
        "compiledValue": "#ff9e59"
    },
    {
        "name": "$particle-dark-text-validation-success-color",
        "value": "#{$particle-dark-validation-success-high}",
        "compiledValue": "#48db81"
    },
    {
        "name": "$particle-dark-body-error-color",
        "value": "#{$particle-dark-validation-error-high}",
        "compiledValue": "#f95670"
    },
    {
        "name": "$particle-dark-body-warning-color",
        "value": "#{$particle-dark-validation-warning-high}",
        "compiledValue": "#ff9e59"
    },
    {
        "name": "$particle-dark-body-success-color",
        "value": "#{$particle-dark-validation-success-high}",
        "compiledValue": "#48db81"
    },
    {
        "name": "$particle-dark-grid-header-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-body-small-color",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-body-small-label-color",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-body-fixed-width-color",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-body-fixed-width-white-color",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-card-title-edit-in-place-color",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-card-subtitle-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-card-drilldown-title-text-color",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-navigation-main-background-color",
        "value": "#{$particle-dark-surface-4}",
        "compiledValue": "#262939"
    },
    {
        "name": "$particle-dark-navigation-main-item-focused-border-color",
        "value": "#{$particle-dark-focus-box-color}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-navigation-main-item-hover-background-color",
        "value": "rgba(216,216,216,.18)",
        "compiledValue": "rgba(216, 216, 216, 0.18)"
    },
    {
        "name": "$particle-dark-navigation-main-item-icon-default-color",
        "value": "rgba(255,255,255,.46)",
        "compiledValue": "rgba(255, 255, 255, 0.46)"
    },
    {
        "name": "$particle-dark-navigation-main-item-icon-focused-color",
        "value": "rgba(255,255,255,.6)",
        "compiledValue": "rgba(255, 255, 255, 0.6)"
    },
    {
        "name": "$particle-dark-navigation-main-item-icon-hover-color",
        "value": "rgba(255,255,255,.7)",
        "compiledValue": "rgba(255, 255, 255, 0.7)"
    },
    {
        "name": "$particle-dark-navigation-main-item-icon-selected-color",
        "value": "rgba(255,255,255,1)",
        "compiledValue": "white"
    },
    {
        "name": "$particle-dark-banner-error-background-color",
        "value": "#{$particle-dark-status-critical-low}",
        "compiledValue": "rgba(249, 86, 91, 0.28)"
    },
    {
        "name": "$particle-dark-banner-error-border-color",
        "value": "#{$particle-dark-status-critical-200}",
        "compiledValue": "#fa7d81"
    },
    {
        "name": "$particle-dark-banner-info-background-color",
        "value": "#{$particle-dark-status-info-low}",
        "compiledValue": "rgba(100, 161, 255, 0.28)"
    },
    {
        "name": "$particle-dark-banner-info-border-color",
        "value": "#{$particle-dark-status-info-200}",
        "compiledValue": "#8dbaff"
    },
    {
        "name": "$particle-dark-banner-message-text-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-banner-success-background-color",
        "value": "#{$particle-dark-status-normal-low}",
        "compiledValue": "rgba(73, 220, 128, 0.28)"
    },
    {
        "name": "$particle-dark-banner-success-border-color",
        "value": "#{$particle-dark-status-normal-200}",
        "compiledValue": "#6be398"
    },
    {
        "name": "$particle-dark-banner-title-text-color",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-banner-warning-background-color",
        "value": "#{$particle-dark-status-warning-low}",
        "compiledValue": "rgba(255, 215, 105, 0.28)"
    },
    {
        "name": "$particle-dark-banner-warning-border-color",
        "value": "#{$particle-dark-status-warning-200}",
        "compiledValue": "#ffe292"
    },
    {
        "name": "$particle-dark-button-background-color",
        "value": "#{$particle-dark-state-default}",
        "compiledValue": "rgba(255, 255, 255, 0.1)"
    },
    {
        "name": "$particle-dark-button-hover-background-color",
        "value": "#{$particle-dark-state-hover-or-disabled}",
        "compiledValue": "rgba(255, 255, 255, 0.34)"
    },
    {
        "name": "$particle-dark-button-label-color",
        "value": "#{$particle-dark-button-label-color}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-button-cdk-keyboard-focused-box-shadow",
        "value": "#{$particle-dark-focus-box-color}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-button-material-color",
        "value": "#{$particle-dark-button-label-disabled-color}",
        "compiledValue": "rgba(255, 255, 255, 0.38)"
    },
    {
        "name": "$particle-dark-button-material-role-background-color",
        "value": "#{$particle-dark-state-low}",
        "compiledValue": "rgba(255, 255, 255, 0.06)"
    },
    {
        "name": "$particle-dark-button-role-primary-background-color",
        "value": "#{$particle-dark-primary-high}",
        "compiledValue": "#8a5fff"
    },
    {
        "name": "$particle-dark-button-role-primary-cdk-keyboard-focused-box-shadow",
        "value": "#{$particle-dark-focus-box-color}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-button-role-primary-color",
        "value": "#{$particle-dark-button-label-color}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-button-role-primary-hover-background-color",
        "value": "#{$particle-dark-primary-300}",
        "compiledValue": "#9e7eff"
    },
    {
        "name": "$particle-dark-button-text-color-disabled",
        "value": "#{$particle-dark-button-label-disabled-color}",
        "compiledValue": "rgba(255, 255, 255, 0.38)"
    },
    {
        "name": "$particle-dark-button-text-color-inverse",
        "value": "#{$particle-dark-button-label-color}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-button-text-color-primary",
        "value": "#{$particle-dark-button-label-color}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-button-toggled-background-color",
        "value": "#{$particle-dark-primary-high}",
        "compiledValue": "#8a5fff"
    },
    {
        "name": "$particle-dark-button-toggled-color",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-button-icon-background-color",
        "value": "#{$particle-dark-surface-3}",
        "compiledValue": "#323433"
    },
    {
        "name": "$particle-dark-button-icon-hover-color",
        "value": "#{$particle-dark-state-hover-or-disabled}",
        "compiledValue": "rgba(255, 255, 255, 0.34)"
    },
    {
        "name": "$particle-dark-breadcrumb-text-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-breadcrumb-text-selected-color",
        "value": "#{$particle-dark-secondary-high}",
        "compiledValue": "#cbadff"
    },
    {
        "name": "$particle-dark-breadcrumb-popover-text-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-card-background-color",
        "value": "#{$particle-dark-surface-5}",
        "compiledValue": "#16192a"
    },
    {
        "name": "$particle-dark-card-hover-toolbar-background-color",
        "value": "#{$particle-dark-surface-5}",
        "compiledValue": "#16192a"
    },
    {
        "name": "$particle-dark-card-selected-border-color",
        "value": "#{$particle-dark-primary-300}",
        "compiledValue": "#9e7eff"
    },
    {
        "name": "$particle-dark-chart-axis-text-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-chart-legend-text-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-chart-text-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-chart-tooltip-background",
        "value": "#{$particle-dark-surface-2}",
        "compiledValue": "#3c4050"
    },
    {
        "name": "$particle-dark-chart-tooltip-background-color",
        "value": "#{$particle-dark-surface-2}",
        "compiledValue": "#3c4050"
    },
    {
        "name": "$particle-dark-chart-tooltip-text-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-icon-disabled-color",
        "value": "#{$particle-dark-state-low}",
        "compiledValue": "rgba(255, 255, 255, 0.06)"
    },
    {
        "name": "$particle-dark-icon-inverse-color",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-icon-nav-active-color",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-icon-normal-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-icon-selected-color",
        "value": "#{$particle-dark-secondary-high}",
        "compiledValue": "#cbadff"
    },
    {
        "name": "$particle-dark-legend-item-hover-not-selected-background-color",
        "value": "#{$particle-dark-surface-3}",
        "compiledValue": "#323433"
    },
    {
        "name": "$particle-dark-legend-item-hover-selected-background-color",
        "value": "#{$particle-dark-primary-300}",
        "compiledValue": "#9e7eff"
    },
    {
        "name": "$particle-dark-legend-item-selected-background-color",
        "value": "#{$particle-dark-primary-200}",
        "compiledValue": "#bca5ff"
    },
    {
        "name": "$particle-dark-legend-item-text-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-cartesian-axis-label-text-color",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-cartesian-axis-title-text-color",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-cartesian-legend-hover-background-color",
        "value": "#{$particle-dark-state-hover-or-disabled}",
        "compiledValue": "rgba(255, 255, 255, 0.34)"
    },
    {
        "name": "$particle-dark-cartesian-grid-border-color",
        "value": "#{$particle-dark-highlight-low}",
        "compiledValue": "rgba(255, 255, 255, 0.38)"
    },
    {
        "name": "$particle-dark-cartesian-plot-band-neutral-color",
        "value": "#{$particle-dark-grey-500}",
        "compiledValue": "#B1B5CA"
    },
    {
        "name": "$particle-dark-cartesian-plot-band-critical-color",
        "value": "#{$particle-dark-status-critical-300}",
        "compiledValue": "#f9565b"
    },
    {
        "name": "$particle-dark-cartesian-plot-band-warning-color",
        "value": "#{$particle-dark-status-warning-300}",
        "compiledValue": "#ffd769"
    },
    {
        "name": "$particle-dark-cartesian-time-scrubber-selected-background-color",
        "value": "#{$particle-dark-primary-300}",
        "compiledValue": "#9e7eff"
    },
    {
        "name": "$particle-dark-cartesian-time-scrubber-tick-mark-line-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-cartesian-time-scrubber-border-color",
        "value": "#{$particle-dark-state-hover-or-disabled}",
        "compiledValue": "rgba(255, 255, 255, 0.34)"
    },
    {
        "name": "$particle-dark-cartesian-time-scrubber-drag-line-color",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-spark-line-bar-fill-color",
        "value": "#{$particle-dark-chart-color-1}",
        "compiledValue": "#d3bbff"
    },
    {
        "name": "$particle-dark-spark-line-stroke-color",
        "value": "#{$particle-dark-chart-color-1}",
        "compiledValue": "#d3bbff"
    },
    {
        "name": "$particle-dark-charts-label-text-color",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-charts-legend-item-hover-background-color",
        "value": "#{$particle-dark-surface-3}",
        "compiledValue": "#323433"
    },
    {
        "name": "$particle-dark-charts-legend-text-color",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-charts-pie-center-label-text-color",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-charts-pie-zero-border-color",
        "value": "#{$particle-dark-highlight-low}",
        "compiledValue": "rgba(255, 255, 255, 0.38)"
    },
    {
        "name": "$particle-dark-charts-pie-null-fill",
        "value": "#{$particle-dark-state-default}",
        "compiledValue": "rgba(255, 255, 255, 0.1)"
    },
    {
        "name": "$particle-dark-charts-tooltip-background-color",
        "value": "#{$particle-dark-surface-3}",
        "compiledValue": "#323433"
    },
    {
        "name": "$particle-dark-charts-tooltip-text-color",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-description-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-carousel-description-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-carousel-background-color",
        "value": "#{$particle-dark-surface-1}",
        "compiledValue": "#4f5361"
    },
    {
        "name": "$particle-dark-carousel-paginate-circle-background-color",
        "value": "#{$particle-dark-highlight-low}",
        "compiledValue": "rgba(255, 255, 255, 0.38)"
    },
    {
        "name": "$particle-dark-carousel-paginate-circle-hover-background-color",
        "value": "#{$particle-dark-highlight-low}",
        "compiledValue": "rgba(255, 255, 255, 0.38)"
    },
    {
        "name": "$particle-dark-carousel-paginate-circle-selected-background-color",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-carousel-paginate-icon-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-context-menu-item-hover-background-color",
        "value": "#{$particle-dark-surface-2}",
        "compiledValue": "#3c4050"
    },
    {
        "name": "$particle-dark-checkbox-border-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-checkbox-check-color",
        "value": "#{$particle-dark-highlight-high-icon}",
        "compiledValue": "white"
    },
    {
        "name": "$particle-dark-checkbox-checked-background-color",
        "value": "#{$particle-dark-primary-300}",
        "compiledValue": "#9e7eff"
    },
    {
        "name": "$particle-dark-checkbox-disabled-background-color",
        "value": "#{$particle-dark-state-hover-or-disabled}",
        "compiledValue": "rgba(255, 255, 255, 0.34)"
    },
    {
        "name": "$particle-dark-checkbox-disabled-check-color",
        "value": "#{$particle-dark-surface-3}",
        "compiledValue": "#323433"
    },
    {
        "name": "$particle-dark-checkbox-disabled-border-color",
        "value": "#{$particle-dark-state-hover-or-disabled}",
        "compiledValue": "rgba(255, 255, 255, 0.34)"
    },
    {
        "name": "$particle-dark-checkbox-indeterminate-check-color",
        "value": "#{$particle-dark-highlight-high-icon}",
        "compiledValue": "white"
    },
    {
        "name": "$particle-dark-checkbox-mixed-color",
        "value": "#{$particle-dark-highlight-high-icon}",
        "compiledValue": "white"
    },
    {
        "name": "$particle-dark-date-picker-background-color",
        "value": "#{$particle-dark-surface-2}",
        "compiledValue": "#3c4050"
    },
    {
        "name": "$particle-dark-date-picker-border-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-date-picker-calendar-hover-color",
        "value": "#{$particle-dark-primary-300}",
        "compiledValue": "#9e7eff"
    },
    {
        "name": "$particle-dark-date-picker-calendar-text-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-date-picker-disabled-text-color",
        "value": "#{$particle-dark-highlight-low}",
        "compiledValue": "rgba(255, 255, 255, 0.38)"
    },
    {
        "name": "$particle-dark-date-picker-error-background-color",
        "value": "#{$particle-dark-validation-error-low}",
        "compiledValue": "rgba(249, 86, 112, 0.28)"
    },
    {
        "name": "$particle-dark-date-picker-error-border-color",
        "value": "#{$particle-dark-validation-error-low}",
        "compiledValue": "rgba(249, 86, 112, 0.28)"
    },
    {
        "name": "$particle-dark-date-picker-focus-background-color",
        "value": "#{$particle-dark-state-default}",
        "compiledValue": "rgba(255, 255, 255, 0.1)"
    },
    {
        "name": "$particle-dark-date-picker-focus-border-color",
        "value": "#{$particle-dark-primary-300}",
        "compiledValue": "#9e7eff"
    },
    {
        "name": "$particle-dark-date-picker-focus-hover-color",
        "value": "#{$particle-dark-state-default}",
        "compiledValue": "rgba(255, 255, 255, 0.1)"
    },
    {
        "name": "$particle-dark-date-picker-focus-underline-color",
        "value": "#{$particle-dark-primary-300}",
        "compiledValue": "#9e7eff"
    },
    {
        "name": "$particle-dark-date-picker-hover-underline-color",
        "value": "#{$particle-dark-primary-300}",
        "compiledValue": "#9e7eff"
    },
    {
        "name": "$particle-dark-date-picker-input-text-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-date-picker-invalid-underline-color",
        "value": "#{$particle-dark-validation-error-low}",
        "compiledValue": "rgba(249, 86, 112, 0.28)"
    },
    {
        "name": "$particle-dark-date-picker-selected-color",
        "value": "#{$particle-dark-primary-high}",
        "compiledValue": "#8a5fff"
    },
    {
        "name": "$particle-dark-dialog-confirmation-footer-background-color",
        "value": "#{$particle-dark-surface-1}",
        "compiledValue": "#4f5361"
    },
    {
        "name": "$particle-dark-dialog-confirmation-message-background-color",
        "value": "#{$particle-dark-surface-1}",
        "compiledValue": "#4f5361"
    },
    {
        "name": "$particle-dark-dialog-content-background-color",
        "value": "#{$particle-dark-surface-1}",
        "compiledValue": "#4f5361"
    },
    {
        "name": "$particle-dark-date-picker-input-text-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-dialog-header-background-color",
        "value": "#{$particle-dark-state-low}",
        "compiledValue": "rgba(255, 255, 255, 0.06)"
    },
    {
        "name": "$particle-dark-dialog-header-border-bottom-color",
        "value": "#{$particle-dark-divider-line}",
        "compiledValue": "rgba(255, 255, 255, 0.15)"
    },
    {
        "name": "$particle-dark-editable-label-textarea-cdk-keyboard-focused-color",
        "value": "#{$particle-dark-focus-box-color}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-editable-label-textarea-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-expander-header-cdk-keyboard-focused-border",
        "value": "#{$particle-dark-focus-box-color}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-expander-header-hover-background-color",
        "value": "#{$particle-dark-surface-3}",
        "compiledValue": "#323433"
    },
    {
        "name": "$particle-dark-expander-label-color",
        "value": "#{$particle-dark-text-hover-color}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-filter-panel-overlay-background-color",
        "value": "#{$particle-dark-surface-4}",
        "compiledValue": "#262939"
    },
    {
        "name": "$particle-dark-filter-panel-overlay-footer-border-top-color",
        "value": "#{$particle-dark-highlight-low}",
        "compiledValue": "rgba(255, 255, 255, 0.38)"
    },
    {
        "name": "$particle-dark-filter-panel-overlay-resize-hover-background-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-filter-panel-trigger-count-background-color",
        "value": "#{$particle-dark-surface-2}",
        "compiledValue": "#3c4050"
    },
    {
        "name": "$particle-dark-filter-panel-trigger-count-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-form-checkbox-description-color",
        "value": "#{$particle-dark-text-hint-color}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-form-checkbox-label-color",
        "value": "#{$particle-dark-body-color}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-form-checkbox-right-label-color",
        "value": "#{$particle-dark-body-color}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-form-checkbox-not-selected-stroke-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-form-checkbox-not-selected-disabled-stroke-color",
        "value": "#{$particle-dark-state-hover-or-disabled}",
        "compiledValue": "rgba(255, 255, 255, 0.34)"
    },
    {
        "name": "$particle-dark-form-checkbox-not-selected-hover-stroke-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-form-checkbox-not-selected-focused-stroke-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-form-checkbox-not-selected-hover-background-color",
        "value": "#{$particle-dark-state-hover-or-disabled}",
        "compiledValue": "rgba(255, 255, 255, 0.34)"
    },
    {
        "name": "$particle-dark-form-checkbox-selected-stroke-color",
        "value": "#{$particle-dark-primary-300}",
        "compiledValue": "#9e7eff"
    },
    {
        "name": "$particle-dark-form-checkbox-selected-check-stroke-color",
        "value": "#{$particle-dark-highlight-high-icon}",
        "compiledValue": "white"
    },
    {
        "name": "$particle-dark-form-checkbox-selected-fill-color",
        "value": "#{$particle-dark-primary-300}",
        "compiledValue": "#9e7eff"
    },
    {
        "name": "$particle-dark-form-checkbox-selected-focused-stroke-color",
        "value": "#{$particle-dark-primary-300}",
        "compiledValue": "#9e7eff"
    },
    {
        "name": "$particle-dark-form-checkbox-selected-focused-check-stroke-color",
        "value": "#{$particle-dark-highlight-high-icon}",
        "compiledValue": "white"
    },
    {
        "name": "$particle-dark-form-checkbox-selected-focused-fill-color",
        "value": "#{$particle-dark-primary-300}",
        "compiledValue": "#9e7eff"
    },
    {
        "name": "$particle-dark-form-checkbox-selected-disabled-stroke-color",
        "value": "#{$particle-dark-state-hover-or-disabled}",
        "compiledValue": "rgba(255, 255, 255, 0.34)"
    },
    {
        "name": "$particle-dark-form-checkbox-selected-disabled-check-stroke-color",
        "value": "#{$particle-dark-highlight-low}",
        "compiledValue": "rgba(255, 255, 255, 0.38)"
    },
    {
        "name": "$particle-dark-form-checkbox-selected-disabled-fill-color",
        "value": "#{$particle-dark-state-hover-or-disabled}",
        "compiledValue": "rgba(255, 255, 255, 0.34)"
    },
    {
        "name": "$particle-dark-form-radiobutton-not-selected-stroke-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-form-radiobutton-not-selected-fill-color",
        "value": "#{$particle-dark-surface-3}",
        "compiledValue": "#323433"
    },
    {
        "name": "$particle-dark-form-radiobutton-not-selected-disabled-stroke-color",
        "value": "#{$particle-dark-state-hover-or-disabled}",
        "compiledValue": "rgba(255, 255, 255, 0.34)"
    },
    {
        "name": "$particle-dark-form-radiobutton-not-selected-hover-stroke-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-form-radiobutton-not-selected-hover-background-color",
        "value": "#{$particle-dark-state-default}",
        "compiledValue": "rgba(255, 255, 255, 0.1)"
    },
    {
        "name": "$particle-dark-form-radiobutton-not-selected-focused-stroke-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-form-radiobutton-selected-stroke-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-form-radiobutton-selected-fill-color",
        "value": "#{$particle-dark-primary-300}",
        "compiledValue": "#9e7eff"
    },
    {
        "name": "$particle-dark-form-radiobutton-selected-disabled-stroke-color",
        "value": "#{$particle-dark-state-hover-or-disabled}",
        "compiledValue": "rgba(255, 255, 255, 0.34)"
    },
    {
        "name": "$particle-dark-form-radiobutton-selected-disabled-fill-color",
        "value": "#{$particle-dark-state-hover-or-disabled}",
        "compiledValue": "rgba(255, 255, 255, 0.34)"
    },
    {
        "name": "$particle-dark-form-radiobutton-selected-hover-stroke-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-form-radiobutton-selected-hover-fill-color",
        "value": "#{$particle-dark-primary-300}",
        "compiledValue": "#9e7eff"
    },
    {
        "name": "$particle-dark-form-radiobutton-selected-hover-background-color",
        "value": "#{$particle-dark-state-default}",
        "compiledValue": "rgba(255, 255, 255, 0.1)"
    },
    {
        "name": "$particle-dark-form-radiobutton-selected-focused-stroke-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-form-radiobutton-selected-focused-fill-color",
        "value": "#{$particle-dark-primary-300}",
        "compiledValue": "#9e7eff"
    },
    {
        "name": "$particle-dark-form-container-background-color",
        "value": "#{$particle-dark-surface-2}",
        "compiledValue": "#3c4050"
    },
    {
        "name": "$particle-dark-form-field-background-color",
        "value": "#{$particle-dark-state-low}",
        "compiledValue": "rgba(255, 255, 255, 0.06)"
    },
    {
        "name": "$particle-dark-form-field-border-bottom",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-form-field-border-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-form-field-clear-background-color",
        "value": "#{$particle-dark-surface-3}",
        "compiledValue": "#323433"
    },
    {
        "name": "$particle-dark-form-field-disabled-background-color",
        "value": "#{$particle-dark-state-hover-or-disabled}",
        "compiledValue": "rgba(255, 255, 255, 0.34)"
    },
    {
        "name": "$particle-dark-form-field-error-background-color",
        "value": "#{$particle-dark-validation-error-low}",
        "compiledValue": "rgba(249, 86, 112, 0.28)"
    },
    {
        "name": "$particle-dark-form-field-invalid-border-color",
        "value": "#{$particle-dark-validation-error-high}",
        "compiledValue": "#f95670"
    },
    {
        "name": "$particle-dark-form-input-background-color",
        "value": "#{$particle-dark-state-low}",
        "compiledValue": "rgba(255, 255, 255, 0.06)"
    },
    {
        "name": "$particle-dark-form-input-focused-background-color",
        "value": "#{$particle-dark-state-default}",
        "compiledValue": "rgba(255, 255, 255, 0.1)"
    },
    {
        "name": "$particle-dark-form-input-focused-border-color",
        "value": "#{$particle-dark-primary-300}",
        "compiledValue": "#9e7eff"
    },
    {
        "name": "$particle-dark-form-input-disabled-background-color",
        "value": "#{$particle-dark-surface-3}",
        "compiledValue": "#323433"
    },
    {
        "name": "$particle-dark-form-input-disabled-color",
        "value": "#{$particle-dark-text-placeholder-color}",
        "compiledValue": "rgba(255, 255, 255, 0.38)"
    },
    {
        "name": "$particle-dark-form-input-error-background-color",
        "value": "#{$particle-dark-validation-error-low}",
        "compiledValue": "rgba(249, 86, 112, 0.28)"
    },
    {
        "name": "$particle-dark-form-input-error-border-color",
        "value": "#{$particle-dark-validation-error-high}",
        "compiledValue": "#f95670"
    },
    {
        "name": "$particle-dark-form-input-icon-fill",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-form-input-number-icon-fill",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-gauge-baseline-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-gauge-label-text-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-gauge-needle-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-gauge-target-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-gauge-background-color",
        "value": "#{$particle-dark-state-low}",
        "compiledValue": "rgba(255, 255, 255, 0.06)"
    },
    {
        "name": "$particle-dark-gauge-zero-border-color",
        "value": "#{$particle-dark-state-default}",
        "compiledValue": "rgba(255, 255, 255, 0.1)"
    },
    {
        "name": "$particle-dark-gauge-tooltip-background-color",
        "value": "#{$particle-dark-surface-3}",
        "compiledValue": "#323433"
    },
    {
        "name": "$particle-dark-grid-loading-row-gradient-end",
        "value": "transparent",
        "compiledValue": "transparent"
    },
    {
        "name": "$particle-dark-grid-loading-row-gradient-start",
        "value": "#{$particle-dark-grey-700}",
        "compiledValue": "#6F7182"
    },
    {
        "name": "$particle-dark-grid-background-color",
        "value": "transparent",
        "compiledValue": "transparent"
    },
    {
        "name": "$particle-dark-grid-footer-background-color",
        "value": "transparent",
        "compiledValue": "transparent"
    },
    {
        "name": "$particle-dark-grid-footer-text-color",
        "value": "#{$particle-dark-body-color}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-grid-header-text-color",
        "value": "#{$particle-dark-grid-header-color}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-grid-header-background-color",
        "value": "transparent",
        "compiledValue": "transparent"
    },
    {
        "name": "$particle-dark-grid-row-background-color",
        "value": "transparent",
        "compiledValue": "transparent"
    },
    {
        "name": "$particle-dark-grid-row-text-color",
        "value": "#{$particle-dark-body-color}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-grid-icon-checkbox-background-color",
        "value": "transparent",
        "compiledValue": "transparent"
    },
    {
        "name": "$particle-dark-grid-row-hover-background-color",
        "value": "#{$particle-dark-primary-low}",
        "compiledValue": "rgba(138, 95, 255, 0.28)"
    },
    {
        "name": "$particle-dark-grid-row-hover-text-color",
        "value": "#{$particle-dark-body-color}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-grid-row-border-color",
        "value": "#{$particle-dark-divider-line}",
        "compiledValue": "rgba(255, 255, 255, 0.15)"
    },
    {
        "name": "$particle-dark-grid-row-selected-background-color",
        "value": "#{$particle-dark-primary-medium}",
        "compiledValue": "rgba(138, 95, 255, 0.6)"
    },
    {
        "name": "$particle-dark-grid-row-selected-text-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-health-bar-critical-status-background-color",
        "value": "#{$particle-dark-status-critical-300}",
        "compiledValue": "#f9565b"
    },
    {
        "name": "$particle-dark-health-bar-no-data-status-background-color",
        "value": "#{$particle-dark-state-low}",
        "compiledValue": "rgba(255, 255, 255, 0.06)"
    },
    {
        "name": "$particle-dark-health-bar-normal-status-background-color",
        "value": "#{$particle-dark-status-normal-300}",
        "compiledValue": "#49dc80"
    },
    {
        "name": "$particle-dark-health-bar-unknown-status-background-color",
        "value": "#{$particle-dark-grey-500}",
        "compiledValue": "#B1B5CA"
    },
    {
        "name": "$particle-dark-health-bar-warning-status-background-color",
        "value": "#{$particle-dark-status-warning-300}",
        "compiledValue": "#ffd769"
    },
    {
        "name": "$particle-dark-health-bar-zero-border-color",
        "value": "#{$particle-dark-divider-line}",
        "compiledValue": "rgba(255, 255, 255, 0.15)"
    },
    {
        "name": "$particle-dark-hover-toolbar-card-background-color",
        "value": "#{$particle-dark-surface-3}",
        "compiledValue": "#323433"
    },
    {
        "name": "$particle-dark-hover-toolbar-card-hover-toolbar-background-color",
        "value": "#{$particle-dark-state-hover-or-disabled}",
        "compiledValue": "rgba(255, 255, 255, 0.34)"
    },
    {
        "name": "$particle-dark-list-footer-border-color",
        "value": "#{$particle-dark-divider-line}",
        "compiledValue": "rgba(255, 255, 255, 0.15)"
    },
    {
        "name": "$particle-dark-list-background-color",
        "value": "#{$particle-dark-surface-4}",
        "compiledValue": "#262939"
    },
    {
        "name": "$particle-dark-list-row-border-color",
        "value": "#{$particle-dark-divider-line}",
        "compiledValue": "rgba(255, 255, 255, 0.15)"
    },
    {
        "name": "$particle-dark-list-row-hover-background-color",
        "value": "#{$particle-dark-primary-low}",
        "compiledValue": "rgba(138, 95, 255, 0.28)"
    },
    {
        "name": "$particle-dark-list-row-selected-background-color",
        "value": "#{$particle-dark-primary-medium}",
        "compiledValue": "rgba(138, 95, 255, 0.6)"
    },
    {
        "name": "$particle-dark-list-footer-text-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-list-row-focused-background-color",
        "value": "#{$particle-dark-primary-low}",
        "compiledValue": "rgba(138, 95, 255, 0.28)"
    },
    {
        "name": "$particle-dark-list-row-focused-border-left-color",
        "value": "#{$particle-dark-primary-high}",
        "compiledValue": "#8a5fff"
    },
    {
        "name": "$particle-dark-list-row-selected-background-color",
        "value": "#{$particle-dark-primary-medium}",
        "compiledValue": "rgba(138, 95, 255, 0.6)"
    },
    {
        "name": "$particle-dark-list-row-selected-border-left-color",
        "value": "#{$particle-dark-primary-high}",
        "compiledValue": "#8a5fff"
    },
    {
        "name": "$particle-dark-list-text-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-lookup-dialog-description-border-bottom-color",
        "value": "#{$particle-dark-divider-line}",
        "compiledValue": "rgba(255, 255, 255, 0.15)"
    },
    {
        "name": "$particle-dark-lookup-dropdown-action-focused",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-lookup-dropdown-active",
        "value": "#{$particle-dark-surface-2}",
        "compiledValue": "#3c4050"
    },
    {
        "name": "$particle-dark-lookup-dropdown-border-bottom",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-lookup-dropdown-focus-border-bottom",
        "value": "#{$particle-dark-primary-300}",
        "compiledValue": "#9e7eff"
    },
    {
        "name": "$particle-dark-lookup-dropdown-host-background-color",
        "value": "#{$particle-dark-state-low}",
        "compiledValue": "rgba(255, 255, 255, 0.06)"
    },
    {
        "name": "$particle-dark-lookup-dropdown-hover-background-color",
        "value": "#{$particle-dark-state-low}",
        "compiledValue": "rgba(255, 255, 255, 0.06)"
    },
    {
        "name": "$particle-dark-lookup-dropdown-option-focused",
        "value": "#{$particle-dark-focus-box-color}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-lookup-search-background-color",
        "value": "#{$particle-dark-state-low}",
        "compiledValue": "rgba(255, 255, 255, 0.06)"
    },
    {
        "name": "$particle-dark-lookup-search-focus-background-color",
        "value": "#{$particle-dark-state-default}",
        "compiledValue": "rgba(255, 255, 255, 0.1)"
    },
    {
        "name": "$particle-dark-lookup-search-container-disabled-background-color",
        "value": "#{$particle-dark-surface-4}",
        "compiledValue": "#262939"
    },
    {
        "name": "$particle-dark-lookup-search-container-disabled-color",
        "value": "#{$particle-dark-text-disabled-color}",
        "compiledValue": "rgba(255, 255, 255, 0.38)"
    },
    {
        "name": "$particle-dark-lookup-search-container-invalid-background-color",
        "value": "#{$particle-dark-validation-error-low}",
        "compiledValue": "rgba(249, 86, 112, 0.28)"
    },
    {
        "name": "$particle-dark-master-details-card-background-color",
        "value": "#{$particle-dark-surface-3}",
        "compiledValue": "#323433"
    },
    {
        "name": "$particle-dark-menu-group-active-state-background-color",
        "value": "#{$particle-dark-primary-high}",
        "compiledValue": "#8a5fff"
    },
    {
        "name": "$particle-dark-menu-group-background-color",
        "value": "#{$particle-dark-surface-2}",
        "compiledValue": "#3c4050"
    },
    {
        "name": "$particle-dark-menu-group-label-text-color",
        "value": "#{$particle-dark-text-hover-color}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-menu-group-label-text-color-inverse",
        "value": "#{$particle-dark-primary-300}",
        "compiledValue": "#9e7eff"
    },
    {
        "name": "$particle-dark-menu-group-mat-button-disabled-color",
        "value": "#{$particle-dark-state-low}",
        "compiledValue": "rgba(255, 255, 255, 0.06)"
    },
    {
        "name": "$particle-dark-menu-item-button-focus-background-color",
        "value": "#{$particle-dark-highlight-low}",
        "compiledValue": "rgba(255, 255, 255, 0.38)"
    },
    {
        "name": "$particle-dark-menu-item-button-hover-background-color",
        "value": "#{$particle-dark-primary-medium}",
        "compiledValue": "rgba(138, 95, 255, 0.6)"
    },
    {
        "name": "$particle-dark-menu-item-button-secondary-color",
        "value": "#{$particle-dark-secondary-medium}",
        "compiledValue": "rgba(203, 173, 255, 0.6)"
    },
    {
        "name": "$particle-dark-menu-item-divider-border-color",
        "value": "#{$particle-dark-divider-line}",
        "compiledValue": "rgba(255, 255, 255, 0.15)"
    },
    {
        "name": "$particle-dark-menu-item-selected-color",
        "value": "#{$particle-dark-primary-high}",
        "compiledValue": "#8a5fff"
    },
    {
        "name": "$particle-dark-menu-item-focus-background-color",
        "value": "#{$particle-dark-highlight-low}",
        "compiledValue": "rgba(255, 255, 255, 0.38)"
    },
    {
        "name": "$particle-dark-menu-item-hover-background-color",
        "value": "#{$particle-dark-primary-medium}",
        "compiledValue": "rgba(138, 95, 255, 0.6)"
    },
    {
        "name": "$particle-dark-menu-background-color",
        "value": "#{$particle-dark-surface-2}",
        "compiledValue": "#3c4050"
    },
    {
        "name": "$particle-dark-numeric-label-delta-container-label-green",
        "value": "#{$particle-dark-status-normal-300}",
        "compiledValue": "#49dc80"
    },
    {
        "name": "$particle-dark-numeric-label-delta-container-label-red",
        "value": "#{$particle-dark-status-critical-300}",
        "compiledValue": "#f9565b"
    },
    {
        "name": "$particle-dark-panel-background-color",
        "value": "#{$particle-dark-surface-4}",
        "compiledValue": "#262939"
    },
    {
        "name": "$particle-dark-panel-border-color",
        "value": "#{$particle-dark-validation-error-high}",
        "compiledValue": "#f95670"
    },
    {
        "name": "$particle-dark-panel-text-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-pill-background-color",
        "value": "#{$particle-dark-state-hover-or-disabled}",
        "compiledValue": "rgba(255, 255, 255, 0.34)"
    },
    {
        "name": "$particle-dark-pill-icon-color",
        "value": "#{$particle-dark-highlight-low}",
        "compiledValue": "rgba(255, 255, 255, 0.38)"
    },
    {
        "name": "$particle-dark-pill-hover-icon-color",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-pill-disabled-background-color",
        "value": "#{$particle-dark-state-default}",
        "compiledValue": "rgba(255, 255, 255, 0.1)"
    },
    {
        "name": "$particle-dark-pill-disabled-icon-color",
        "value": "#{$particle-dark-divider-line}",
        "compiledValue": "rgba(255, 255, 255, 0.15)"
    },
    {
        "name": "$particle-dark-pill-focused-background-color",
        "value": "#{$particle-dark-highlight-low}",
        "compiledValue": "rgba(255, 255, 255, 0.38)"
    },
    {
        "name": "$particle-dark-pill-focused-border-color",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-pill-focused-icon-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-pill-border-color",
        "value": "#{$particle-dark-state-hover-or-disabled}",
        "compiledValue": "rgba(255, 255, 255, 0.34)"
    },
    {
        "name": "$particle-dark-progress-bar-container-background-color",
        "value": "#{$particle-dark-grey-500}",
        "compiledValue": "#B1B5CA"
    },
    {
        "name": "$particle-dark-progress-bar-gradient-end",
        "value": "#{$particle-dark-grey-700}",
        "compiledValue": "#6F7182"
    },
    {
        "name": "$particle-dark-progress-bar-gradient-start",
        "value": "#{$particle-dark-primary-300}",
        "compiledValue": "#9e7eff"
    },
    {
        "name": "$particle-dark-progress-bar-loaded-background-color",
        "value": "#{$particle-dark-grey-500}",
        "compiledValue": "#B1B5CA"
    },
    {
        "name": "$particle-dark-repeater-active-border-color",
        "value": "#{$particle-dark-primary-200}",
        "compiledValue": "#bca5ff"
    },
    {
        "name": "$particle-dark-radio-dot-border-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-radio-background-hover-color",
        "value": "#{$particle-dark-state-hover-or-disabled}",
        "compiledValue": "rgba(255, 255, 255, 0.34)"
    },
    {
        "name": "$particle-dark-radio-dot-border-focused-color",
        "value": "#{$particle-dark-state-hover-or-disabled}",
        "compiledValue": "rgba(255, 255, 255, 0.34)"
    },
    {
        "name": "$particle-dark-radio-dot-color",
        "value": "#{$particle-dark-primary-300}",
        "compiledValue": "#9e7eff"
    },
    {
        "name": "$particle-dark-radio-dot-disabled-color",
        "value": "#{$particle-dark-state-hover-or-disabled}",
        "compiledValue": "rgba(255, 255, 255, 0.34)"
    },
    {
        "name": "$particle-dark-radio-text-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-radio-text-disabled-color",
        "value": "#{$particle-dark-highlight-low}",
        "compiledValue": "rgba(255, 255, 255, 0.38)"
    },
    {
        "name": "$particle-dark-repeater-add-button-active-border-color",
        "value": "#{$particle-dark-state-hover-or-disabled}",
        "compiledValue": "rgba(255, 255, 255, 0.34)"
    },
    {
        "name": "$particle-dark-repeater-border-color",
        "value": "#{$particle-dark-state-hover-or-disabled}",
        "compiledValue": "rgba(255, 255, 255, 0.34)"
    },
    {
        "name": "$particle-dark-repeater-hover-border-color",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-score-bar-remaining-status-background-color",
        "value": "#{$particle-dark-state-low}",
        "compiledValue": "rgba(255, 255, 255, 0.06)"
    },
    {
        "name": "$particle-dark-score-bar-zero-border-color",
        "value": "#{$particle-dark-divider-line}",
        "compiledValue": "rgba(255, 255, 255, 0.15)"
    },
    {
        "name": "$particle-dark-scroll-box-scrollbar-color",
        "value": "#{$particle-dark-highlight-low}",
        "compiledValue": "rgba(255, 255, 255, 0.38)"
    },
    {
        "name": "$particle-dark-scroll-box-scrollbar-focus-color",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-search-box-container-border-color",
        "value": "#{$particle-dark-surface-3}",
        "compiledValue": "#323433"
    },
    {
        "name": "$particle-dark-search-box-container-focus-within-border",
        "value": "#{$particle-dark-primary-300}",
        "compiledValue": "#9e7eff"
    },
    {
        "name": "$particle-dark-search-box-hover-border-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-search-box-search-icons-separator-color",
        "value": "#{$particle-dark-highlight-low}",
        "compiledValue": "rgba(255, 255, 255, 0.38)"
    },
    {
        "name": "$particle-dark-search-box-background-color",
        "value": "#{$particle-dark-state-low}",
        "compiledValue": "rgba(255, 255, 255, 0.06)"
    },
    {
        "name": "$particle-dark-search-box-hover-background-color",
        "value": "#{$particle-dark-state-default}",
        "compiledValue": "rgba(255, 255, 255, 0.1)"
    },
    {
        "name": "$particle-dark-select-dropdown-border-bottom",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-select-dropdown-active-background-color",
        "value": "#{$particle-dark-state-default}",
        "compiledValue": "rgba(255, 255, 255, 0.1)"
    },
    {
        "name": "$particle-dark-select-dropdown-active-border-color",
        "value": "#{$particle-dark-primary-300}",
        "compiledValue": "#9e7eff"
    },
    {
        "name": "$particle-dark-select-dropdown-host-background-color",
        "value": "#{$particle-dark-state-low}",
        "compiledValue": "rgba(255, 255, 255, 0.06)"
    },
    {
        "name": "$particle-dark-select-dropdown-hover-background-color",
        "value": "#{$particle-dark-state-default}",
        "compiledValue": "rgba(255, 255, 255, 0.1)"
    },
    {
        "name": "$particle-dark-select-dropdown-option-active",
        "value": "#{$particle-dark-primary-medium}",
        "compiledValue": "rgba(138, 95, 255, 0.6)"
    },
    {
        "name": "$particle-dark-select-dropdown-option-focused",
        "value": "#{$particle-dark-focus-box-color}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-select-list-option-active-background-color",
        "value": "#{$particle-dark-primary-medium}",
        "compiledValue": "rgba(138, 95, 255, 0.6)"
    },
    {
        "name": "$particle-dark-select-list-option-hover-background-color",
        "value": "#{$particle-dark-primary-medium}",
        "compiledValue": "rgba(138, 95, 255, 0.6)"
    },
    {
        "name": "$particle-dark-select-list-option-selected-background-color",
        "value": "#{$particle-dark-primary-high}",
        "compiledValue": "#8a5fff"
    },
    {
        "name": "$particle-dark-select-placeholder-background-color",
        "value": "#{$particle-dark-primary-medium}",
        "compiledValue": "rgba(138, 95, 255, 0.6)"
    },
    {
        "name": "$particle-dark-select-placeholder-color",
        "value": "#{$particle-dark-text-placeholder-color}",
        "compiledValue": "rgba(255, 255, 255, 0.38)"
    },
    {
        "name": "$particle-dark-select-placeholder-error-background-color",
        "value": "#{$particle-dark-validation-error-low}",
        "compiledValue": "rgba(249, 86, 112, 0.28)"
    },
    {
        "name": "$particle-dark-select-selected-values-background-color",
        "value": "#{$particle-dark-primary-high}",
        "compiledValue": "#8a5fff"
    },
    {
        "name": "$particle-dark-select-selected-values-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-selection-tile-background-color",
        "value": "#{$particle-dark-state-default}",
        "compiledValue": "rgba(255, 255, 255, 0.1)"
    },
    {
        "name": "$particle-dark-selection-tile-content-color",
        "value": "#{$particle-dark-html-color}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-selection-tile-title-color",
        "value": "#{$particle-dark-button-label-color}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-selection-tile-disabled-background-color",
        "value": "#{$particle-dark-state-low}",
        "compiledValue": "rgba(255, 255, 255, 0.06)"
    },
    {
        "name": "$particle-dark-selection-tile-disabled-color",
        "value": "#{$particle-dark-primary-low}",
        "compiledValue": "rgba(138, 95, 255, 0.28)"
    },
    {
        "name": "$particle-dark-selection-tile-hover-background-color",
        "value": "#{$particle-dark-primary-low}",
        "compiledValue": "rgba(138, 95, 255, 0.28)"
    },
    {
        "name": "$particle-dark-selection-tile-hover-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-selection-tile-selected-background-color",
        "value": "#{$particle-dark-primary-medium}",
        "compiledValue": "rgba(138, 95, 255, 0.6)"
    },
    {
        "name": "$particle-dark-selection-tile-selected-line-color",
        "value": "#{$particle-dark-primary-medium}",
        "compiledValue": "rgba(138, 95, 255, 0.6)"
    },
    {
        "name": "$particle-dark-selection-tile-focus-border-color",
        "value": "white",
        "compiledValue": "white"
    },
    {
        "name": "$particle-dark-shimmer-bar-gradient-end",
        "value": "#{$particle-dark-grey-700}",
        "compiledValue": "#6F7182"
    },
    {
        "name": "$particle-dark-shimmer-bar-gradient-start",
        "value": "#{$particle-dark-grey-500}",
        "compiledValue": "#B1B5CA"
    },
    {
        "name": "$particle-dark-shimmer-checkbox-gradient-end",
        "value": "#{$particle-dark-grey-700}",
        "compiledValue": "#6F7182"
    },
    {
        "name": "$particle-dark-shimmer-checkbox-gradient-start",
        "value": "#{$particle-dark-grey-500}",
        "compiledValue": "#B1B5CA"
    },
    {
        "name": "$particle-dark-spark-bar-empty-background-color",
        "value": "#{$particle-dark-state-low}",
        "compiledValue": "rgba(255, 255, 255, 0.06)"
    },
    {
        "name": "$particle-dark-tab-header-active-bar-background-color",
        "value": "#{$particle-dark-primary-high}",
        "compiledValue": "#8a5fff"
    },
    {
        "name": "$particle-dark-tab-header-horizontal-bar-background-color",
        "value": "#{$particle-dark-divider-line}",
        "compiledValue": "rgba(255, 255, 255, 0.15)"
    },
    {
        "name": "$particle-dark-tab-header-host-vertical-border-right",
        "value": "#{$particle-dark-divider-line}",
        "compiledValue": "rgba(255, 255, 255, 0.15)"
    },
    {
        "name": "$particle-dark-tab-header-label-wrapper-active-color",
        "value": "#{$particle-dark-primary-high}",
        "compiledValue": "#8a5fff"
    },
    {
        "name": "$particle-dark-tab-header-label-wrapper-cdk-focused-border-color",
        "value": "#{$particle-dark-primary-medium}",
        "compiledValue": "rgba(138, 95, 255, 0.6)"
    },
    {
        "name": "$particle-dark-tab-header-label-wrapper-disabled-color",
        "value": "#{$particle-dark-text-disabled-color}",
        "compiledValue": "rgba(255, 255, 255, 0.38)"
    },
    {
        "name": "$particle-dark-tab-header-label-wrapper-hover-color",
        "value": "#{$particle-dark-text-hover-color}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-textarea-form-field-background-color",
        "value": "#{$particle-dark-state-low}",
        "compiledValue": "rgba(255, 255, 255, 0.06)"
    },
    {
        "name": "$particle-dark-textarea-form-field-border-bottom",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-textarea-form-field-caret-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-textarea-form-field-disabled-background-color",
        "value": "#{$particle-dark-surface-3}",
        "compiledValue": "#323433"
    },
    {
        "name": "$particle-dark-textarea-form-field-disabled-color",
        "value": "#{$particle-dark-text-disabled-color}",
        "compiledValue": "rgba(255, 255, 255, 0.38)"
    },
    {
        "name": "$particle-dark-textarea-form-field-error-background-color",
        "value": "#{$particle-dark-validation-error-low}",
        "compiledValue": "rgba(249, 86, 112, 0.28)"
    },
    {
        "name": "$particle-dark-textarea-form-field-error-color",
        "value": "#{$particle-dark-validation-error-low}",
        "compiledValue": "rgba(249, 86, 112, 0.28)"
    },
    {
        "name": "$particle-dark-textarea-form-field-focus-background-color",
        "value": "#{$particle-dark-state-default}",
        "compiledValue": "rgba(255, 255, 255, 0.1)"
    },
    {
        "name": "$particle-dark-textarea-form-field-focus-border-color",
        "value": "#{$particle-dark-primary-300}",
        "compiledValue": "#9e7eff"
    },
    {
        "name": "$particle-dark-textarea-form-field-hover-border-color",
        "value": "#{$particle-dark-primary-300}",
        "compiledValue": "#9e7eff"
    },
    {
        "name": "$particle-dark-time-picker-disabled-icon-color",
        "value": "#{$particle-dark-state-low}",
        "compiledValue": "rgba(255, 255, 255, 0.06)"
    },
    {
        "name": "$particle-dark-time-picker-disabled-input-background-color",
        "value": "#{$particle-dark-surface-3}",
        "compiledValue": "#323433"
    },
    {
        "name": "$particle-dark-time-picker-disabled-input-color",
        "value": "#{$particle-dark-text-disabled-color}",
        "compiledValue": "rgba(255, 255, 255, 0.38)"
    },
    {
        "name": "$particle-dark-time-picker-error-background-color",
        "value": "#{$particle-dark-validation-error-low}",
        "compiledValue": "rgba(249, 86, 112, 0.28)"
    },
    {
        "name": "$particle-dark-time-picker-icon-fill",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-time-picker-input-background-color",
        "value": "#{$particle-dark-state-low}",
        "compiledValue": "rgba(255, 255, 255, 0.06)"
    },
    {
        "name": "$particle-dark-time-picker-input-focus-background-color",
        "value": "#{$particle-dark-state-default}",
        "compiledValue": "rgba(255, 255, 255, 0.1)"
    },
    {
        "name": "$particle-dark-time-picker-input-focus-border-color",
        "value": "#{$particle-dark-primary-300}",
        "compiledValue": "#9e7eff"
    },
    {
        "name": "$particle-dark-time-picker-input-border-color",
        "value": "#{$particle-dark-primary-300}",
        "compiledValue": "#9e7eff"
    },
    {
        "name": "$particle-dark-time-range-selector-custom-divider-color",
        "value": "#{$particle-dark-divider-line}",
        "compiledValue": "rgba(255, 255, 255, 0.15)"
    },
    {
        "name": "$particle-dark-time-range-selector-custom-manage-grid",
        "value": "#{$particle-dark-highlight-high-icon}",
        "compiledValue": "white"
    },
    {
        "name": "$particle-dark-time-range-selector-overlay-background-color",
        "value": "#{$particle-dark-surface-2}",
        "compiledValue": "#3c4050"
    },
    {
        "name": "$particle-dark-time-range-selector-standard-divider-color",
        "value": "#{$particle-dark-divider-line}",
        "compiledValue": "rgba(255, 255, 255, 0.15)"
    },
    {
        "name": "$particle-dark-timeline-bar-background-color",
        "value": "#{$particle-dark-state-default}",
        "compiledValue": "rgba(255, 255, 255, 0.1)"
    },
    {
        "name": "$particle-dark-timeline-bar-default-critical-color",
        "value": "#{$particle-dark-status-critical-300}",
        "compiledValue": "#f9565b"
    },
    {
        "name": "$particle-dark-timeline-bar-default-stall-color",
        "value": "#{$particle-dark-chart-color-1}",
        "compiledValue": "#d3bbff"
    },
    {
        "name": "$particle-dark-timeline-bar-default-success-color",
        "value": "#{$particle-dark-status-normal-300}",
        "compiledValue": "#49dc80"
    },
    {
        "name": "$particle-dark-timeline-bar-default-warning-color",
        "value": "#{$particle-dark-status-warning-300}",
        "compiledValue": "#ffd769"
    },
    {
        "name": "$particle-dark-timeline-bar-default-very-slow-color",
        "value": "#{$particle-dark-status-warning-200}",
        "compiledValue": "#ffe292"
    },
    {
        "name": "$particle-dark-timeline-bar-grid-line-color",
        "value": "#{$particle-dark-divider-line}",
        "compiledValue": "rgba(255, 255, 255, 0.15)"
    },
    {
        "name": "$particle-dark-timeline-bar-label-text-color",
        "value": "#{$particle-dark-text-hint-color}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-timeline-bar-label-text-outline-color",
        "value": "#{$particle-dark-surface-3}",
        "compiledValue": "#323433"
    },
    {
        "name": "$particle-dark-timeline-bar-selected-border-color",
        "value": "#{$particle-dark-secondary-high}",
        "compiledValue": "#cbadff"
    },
    {
        "name": "$particle-dark-timeline-bar-title-text-color",
        "value": "#{$particle-dark-section-header-color}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-timeline-bar-title-text-outline-color",
        "value": "#{$particle-dark-surface-3}",
        "compiledValue": "#323433"
    },
    {
        "name": "$particle-dark-toast-background-color",
        "value": "#{$particle-dark-surface-2}",
        "compiledValue": "#3c4050"
    },
    {
        "name": "$particle-dark-toast-hover-background-color",
        "value": "#{$particle-dark-surface-3}",
        "compiledValue": "#323433"
    },
    {
        "name": "$particle-dark-toast-text-label-color",
        "value": "#{$particle-dark-text-label-color}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-toast-text-message-color",
        "value": "#{$particle-dark-body-color}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-toggle-group-toggle-option-background-color",
        "value": "#{$particle-dark-surface-3}",
        "compiledValue": "#323433"
    },
    {
        "name": "$particle-dark-toggle-group-toggle-option-checked-background-color",
        "value": "#{$particle-dark-primary-high}",
        "compiledValue": "#8a5fff"
    },
    {
        "name": "$particle-dark-toggle-group-toggle-option-checked-color",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-toggle-group-toggle-option-checked",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-toggle-group-toggle-option-disabled-background-color",
        "value": "#{$particle-dark-surface-3}",
        "compiledValue": "#323433"
    },
    {
        "name": "$particle-dark-toggle-group-toggle-option-disabled-color",
        "value": "#{$particle-dark-primary-low}",
        "compiledValue": "rgba(138, 95, 255, 0.28)"
    },
    {
        "name": "$particle-dark-toggle-group-toggle-option-focus-background-color",
        "value": "#{$particle-dark-surface-3}",
        "compiledValue": "#323433"
    },
    {
        "name": "$particle-dark-toggle-group-toggle-option-hover-background-color",
        "value": "#{$particle-dark-state-hover-or-disabled}",
        "compiledValue": "rgba(255, 255, 255, 0.34)"
    },
    {
        "name": "$particle-dark-toggle-group-toggle-option-hover-color",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-toggle-group-text-color",
        "value": "#{$particle-dark-body-color}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-toggle-group-text-color-disabled",
        "value": "#{$particle-dark-highlight-low}",
        "compiledValue": "rgba(255, 255, 255, 0.38)"
    },
    {
        "name": "$particle-dark-toggle-group-text-color-selected",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-toggle-switch-off-bar-color",
        "value": "#{$particle-dark-state-default}",
        "compiledValue": "rgba(255, 255, 255, 0.1)"
    },
    {
        "name": "$particle-dark-toggle-switch-off-thumb-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-toggle-switch-on-bar-color",
        "value": "#{$particle-dark-state-default}",
        "compiledValue": "rgba(255, 255, 255, 0.1)"
    },
    {
        "name": "$particle-dark-toggle-switch-on-thumb-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-toggle-switch-off-background-color",
        "value": "#{$particle-dark-state-default}",
        "compiledValue": "rgba(255, 255, 255, 0.1)"
    },
    {
        "name": "$particle-dark-toggle-switch-off-circle-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-toggle-switch-off-focus-border-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-toggle-switch-off-disabled-background-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-toggle-switch-off-disabled-circle-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-toggle-switch-on-background-color",
        "value": "#{$particle-dark-state-default}",
        "compiledValue": "rgba(255, 255, 255, 0.1)"
    },
    {
        "name": "$particle-dark-toggle-switch-on-circle-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-toggle-switch-on-focus-border-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-toggle-switch-on-disabled-background-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-toggle-switch-on-disabled-circle-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-toolbar-border-color",
        "value": "#{$particle-dark-divider-line}",
        "compiledValue": "rgba(255, 255, 255, 0.15)"
    },
    {
        "name": "$particle-dark-toolbar-divider-color",
        "value": "#{$particle-dark-divider-line}",
        "compiledValue": "rgba(255, 255, 255, 0.15)"
    },
    {
        "name": "$particle-dark-toolbar-standalone-background-color",
        "value": "#{$particle-dark-surface-3}",
        "compiledValue": "#323433"
    },
    {
        "name": "$particle-dark-tooltip-exit-button-background-color",
        "value": "#{$particle-dark-surface-3}",
        "compiledValue": "#323433"
    },
    {
        "name": "$particle-dark-wizard-banner-background-color",
        "value": "#{$particle-dark-surface-3}",
        "compiledValue": "#323433"
    },
    {
        "name": "$particle-dark-wizard-banner-border-color",
        "value": "#{$particle-dark-divider-line}",
        "compiledValue": "rgba(255, 255, 255, 0.15)"
    },
    {
        "name": "$particle-dark-wizard-navigation-active-icon-background-color",
        "value": "#{$particle-dark-primary-high}",
        "compiledValue": "#8a5fff"
    },
    {
        "name": "$particle-dark-wizard-navigation-active-icon-color",
        "value": "#{$particle-dark-highlight-high}",
        "compiledValue": "rgba(255, 255, 255, 0.94)"
    },
    {
        "name": "$particle-dark-wizard-navigation-divider-color",
        "value": "#{$particle-dark-divider-line}",
        "compiledValue": "rgba(255, 255, 255, 0.15)"
    },
    {
        "name": "$particle-dark-wizard-navigation-error-icon-border-color",
        "value": "#{$particle-dark-validation-error-high}",
        "compiledValue": "#f95670"
    },
    {
        "name": "$particle-dark-wizard-navigation-fade-container-gradient-color",
        "value": "#{$particle-dark-highlight-medium}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    },
    {
        "name": "$particle-dark-wizard-navigation-host-background-color",
        "value": "#{$particle-dark-surface-3}",
        "compiledValue": "#323433"
    },
    {
        "name": "$particle-dark-wizard-navigation-unvisitable-border-color",
        "value": "#{$particle-dark-state-hover-or-disabled}",
        "compiledValue": "rgba(255, 255, 255, 0.34)"
    },
    {
        "name": "$particle-dark-wizard-navigation-unvisitable-color",
        "value": "#{$particle-dark-state-hover-or-disabled}",
        "compiledValue": "rgba(255, 255, 255, 0.34)"
    },
    {
        "name": "$particle-dark-wizard-navigation-valid-border-color",
        "value": "#{$particle-dark-primary-300}",
        "compiledValue": "#9e7eff"
    },
    {
        "name": "$particle-dark-wizard-navigation-valid-divider-color",
        "value": "#{$particle-dark-primary-300}",
        "compiledValue": "#9e7eff"
    },
    {
        "name": "$particle-dark-wizard-navigation-visitable-border-color",
        "value": "#{$particle-dark-primary-300}",
        "compiledValue": "#9e7eff"
    },
    {
        "name": "$particle-dark-wizard-navigation-visitable-color",
        "value": "#{$particle-dark-wizard-step-label-color}",
        "compiledValue": "rgba(255, 255, 255, 0.64)"
    }
];

/**
 * Generated bundle index. Do not edit.
 */


//# sourceMappingURL=appd-ui-assets.js.map


/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/asyncToGenerator.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/asyncToGenerator.js ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(Promise) {function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) {
  try {
    var info = gen[key](arg);
    var value = info.value;
  } catch (error) {
    reject(error);
    return;
  }

  if (info.done) {
    resolve(value);
  } else {
    Promise.resolve(value).then(_next, _throw);
  }
}

function _asyncToGenerator(fn) {
  return function () {
    var self = this,
        args = arguments;
    return new Promise(function (resolve, reject) {
      var gen = fn.apply(self, args);

      function _next(value) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value);
      }

      function _throw(err) {
        asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err);
      }

      _next(undefined);
    });
  };
}

module.exports = _asyncToGenerator;
module.exports["default"] = module.exports, module.exports.__esModule = true;
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@skpm/promise/index.js */ "./node_modules/@skpm/promise/index.js")))

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/defineProperty.js":
/*!***************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/defineProperty.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

module.exports = _defineProperty;
module.exports["default"] = module.exports, module.exports.__esModule = true;

/***/ }),

/***/ "./node_modules/@babel/runtime/regenerator/index.js":
/*!**********************************************************!*\
  !*** ./node_modules/@babel/runtime/regenerator/index.js ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! regenerator-runtime */ "./node_modules/regenerator-runtime/runtime.js");


/***/ }),

/***/ "./node_modules/@skpm/promise/index.js":
/*!*********************************************!*\
  !*** ./node_modules/@skpm/promise/index.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/* from https://github.com/taylorhakes/promise-polyfill */

function promiseFinally(callback) {
  var constructor = this.constructor;
  return this.then(
    function(value) {
      return constructor.resolve(callback()).then(function() {
        return value;
      });
    },
    function(reason) {
      return constructor.resolve(callback()).then(function() {
        return constructor.reject(reason);
      });
    }
  );
}

function noop() {}

/**
 * @constructor
 * @param {Function} fn
 */
function Promise(fn) {
  if (!(this instanceof Promise))
    throw new TypeError("Promises must be constructed via new");
  if (typeof fn !== "function") throw new TypeError("not a function");
  /** @type {!number} */
  this._state = 0;
  /** @type {!boolean} */
  this._handled = false;
  /** @type {Promise|undefined} */
  this._value = undefined;
  /** @type {!Array<!Function>} */
  this._deferreds = [];

  doResolve(fn, this);
}

function handle(self, deferred) {
  while (self._state === 3) {
    self = self._value;
  }
  if (self._state === 0) {
    self._deferreds.push(deferred);
    return;
  }
  self._handled = true;
  Promise._immediateFn(function() {
    var cb = self._state === 1 ? deferred.onFulfilled : deferred.onRejected;
    if (cb === null) {
      (self._state === 1 ? resolve : reject)(deferred.promise, self._value);
      return;
    }
    var ret;
    try {
      ret = cb(self._value);
    } catch (e) {
      reject(deferred.promise, e);
      return;
    }
    resolve(deferred.promise, ret);
  });
}

function resolve(self, newValue) {
  try {
    // Promise Resolution Procedure: https://github.com/promises-aplus/promises-spec#the-promise-resolution-procedure
    if (newValue === self)
      throw new TypeError("A promise cannot be resolved with itself.");
    if (
      newValue &&
      (typeof newValue === "object" || typeof newValue === "function")
    ) {
      var then = newValue.then;
      if (newValue instanceof Promise) {
        self._state = 3;
        self._value = newValue;
        finale(self);
        return;
      } else if (typeof then === "function") {
        doResolve(then.bind(newValue), self);
        return;
      }
    }
    self._state = 1;
    self._value = newValue;
    finale(self);
  } catch (e) {
    reject(self, e);
  }
}

function reject(self, newValue) {
  self._state = 2;
  self._value = newValue;
  finale(self);
}

function finale(self) {
  if (self._state === 2 && self._deferreds.length === 0) {
    Promise._immediateFn(function() {
      if (!self._handled) {
        Promise._unhandledRejectionFn(self._value, self);
      }
    });
  }

  for (var i = 0, len = self._deferreds.length; i < len; i++) {
    handle(self, self._deferreds[i]);
  }
  self._deferreds = null;
}

/**
 * @constructor
 */
function Handler(onFulfilled, onRejected, promise) {
  this.onFulfilled = typeof onFulfilled === "function" ? onFulfilled : null;
  this.onRejected = typeof onRejected === "function" ? onRejected : null;
  this.promise = promise;
}

/**
 * Take a potentially misbehaving resolver function and make sure
 * onFulfilled and onRejected are only called once.
 *
 * Makes no guarantees about asynchrony.
 */
function doResolve(fn, self) {
  var done = false;
  try {
    fn(
      function(value) {
        if (done) {
          Promise._multipleResolvesFn("resolve", self, value);
          return;
        }
        done = true;
        resolve(self, value);
      },
      function(reason) {
        if (done) {
          Promise._multipleResolvesFn("reject", self, reason);
          return;
        }
        done = true;
        reject(self, reason);
      }
    );
  } catch (ex) {
    if (done) {
      Promise._multipleResolvesFn("reject", self, ex);
      return;
    }
    done = true;
    reject(self, ex);
  }
}

Promise.prototype["catch"] = function(onRejected) {
  return this.then(null, onRejected);
};

Promise.prototype.then = function(onFulfilled, onRejected) {
  // @ts-ignore
  var prom = new this.constructor(noop);

  handle(this, new Handler(onFulfilled, onRejected, prom));
  return prom;
};

Promise.prototype["finally"] = promiseFinally;

Promise.all = function(arr) {
  return new Promise(function(resolve, reject) {
    if (!Array.isArray(arr)) {
      return reject(new TypeError("Promise.all accepts an array"));
    }

    var args = Array.prototype.slice.call(arr);
    if (args.length === 0) return resolve([]);
    var remaining = args.length;

    function res(i, val) {
      try {
        if (val && (typeof val === "object" || typeof val === "function")) {
          var then = val.then;
          if (typeof then === "function") {
            then.call(
              val,
              function(val) {
                res(i, val);
              },
              reject
            );
            return;
          }
        }
        args[i] = val;
        if (--remaining === 0) {
          resolve(args);
        }
      } catch (ex) {
        reject(ex);
      }
    }

    for (var i = 0; i < args.length; i++) {
      res(i, args[i]);
    }
  });
};

Promise.resolve = function(value) {
  if (value && typeof value === "object" && value.constructor === Promise) {
    return value;
  }

  return new Promise(function(resolve) {
    resolve(value);
  });
};

Promise.reject = function(value) {
  return new Promise(function(resolve, reject) {
    reject(value);
  });
};

Promise.race = function(arr) {
  return new Promise(function(resolve, reject) {
    if (!Array.isArray(arr)) {
      return reject(new TypeError("Promise.race accepts an array"));
    }

    for (var i = 0, len = arr.length; i < len; i++) {
      Promise.resolve(arr[i]).then(resolve, reject);
    }
  });
};

// Use polyfill for setImmediate for performance gains
Promise._immediateFn = setImmediate;

Promise._unhandledRejectionFn = function _unhandledRejectionFn(err, promise) {
  if (
    typeof process !== "undefined" &&
    process.listenerCount &&
    (process.listenerCount("unhandledRejection") ||
      process.listenerCount("uncaughtException"))
  ) {
    process.emit("unhandledRejection", err, promise);
    process.emit("uncaughtException", err, "unhandledRejection");
  } else if (typeof console !== "undefined" && console) {
    console.warn("Possible Unhandled Promise Rejection:", err);
  }
};

Promise._multipleResolvesFn = function _multipleResolvesFn(
  type,
  promise,
  value
) {
  if (typeof process !== "undefined" && process.emit) {
    process.emit("multipleResolves", type, promise, value);
  }
};

module.exports = Promise;


/***/ }),

/***/ "./node_modules/mocha-js-delegate/index.js":
/*!*************************************************!*\
  !*** ./node_modules/mocha-js-delegate/index.js ***!
  \*************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/* globals MOClassDescription, NSObject, NSSelectorFromString, NSClassFromString, MOPropertyDescription */

module.exports = function MochaDelegate(definition, superclass) {
  var uniqueClassName =
    'MochaJSDelegate_DynamicClass_' + NSUUID.UUID().UUIDString()

  var delegateClassDesc = MOClassDescription.allocateDescriptionForClassWithName_superclass_(
    uniqueClassName,
    superclass || NSObject
  )

  // Storage
  var handlers = {}
  var ivars = {}

  // Define an instance method
  function setHandlerForSelector(selectorString, func) {
    var handlerHasBeenSet = selectorString in handlers
    var selector = NSSelectorFromString(selectorString)

    handlers[selectorString] = func

    /*
      For some reason, Mocha acts weird about arguments: https://github.com/logancollins/Mocha/issues/28
      We have to basically create a dynamic handler with a likewise dynamic number of predefined arguments.
    */
    if (!handlerHasBeenSet) {
      var args = []
      var regex = /:/g
      while (regex.exec(selectorString)) {
        args.push('arg' + args.length)
      }

      // eslint-disable-next-line no-eval
      var dynamicFunction = eval(
        '(function (' +
          args.join(', ') +
          ') { return handlers[selectorString].apply(this, arguments); })'
      )

      delegateClassDesc.addInstanceMethodWithSelector_function(
        selector,
        dynamicFunction
      )
    }
  }

  // define a property
  function setIvar(key, value) {
    var ivarHasBeenSet = key in handlers

    ivars[key] = value

    if (!ivarHasBeenSet) {
      delegateClassDesc.addInstanceVariableWithName_typeEncoding(key, '@')
      var description = MOPropertyDescription.new()
      description.name = key
      description.typeEncoding = '@'
      description.weak = true
      description.ivarName = key
      delegateClassDesc.addProperty(description)
    }
  }

  this.getClass = function() {
    return NSClassFromString(uniqueClassName)
  }

  this.getClassInstance = function(instanceVariables) {
    var instance = NSClassFromString(uniqueClassName).new()
    Object.keys(ivars).forEach(function(key) {
      instance[key] = ivars[key]
    })
    Object.keys(instanceVariables || {}).forEach(function(key) {
      instance[key] = instanceVariables[key]
    })
    return instance
  }
  // alias
  this.new = this.getClassInstance

  // Convenience
  if (typeof definition === 'object') {
    Object.keys(definition).forEach(
      function(key) {
        if (typeof definition[key] === 'function') {
          setHandlerForSelector(key, definition[key])
        } else {
          setIvar(key, definition[key])
        }
      }
    )
  }

  delegateClassDesc.registerClass()
}


/***/ }),

/***/ "./node_modules/regenerator-runtime/runtime.js":
/*!*****************************************************!*\
  !*** ./node_modules/regenerator-runtime/runtime.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(Promise) {/**
 * Copyright (c) 2014-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

var runtime = (function (exports) {
  "use strict";

  var Op = Object.prototype;
  var hasOwn = Op.hasOwnProperty;
  var undefined; // More compressible than void 0.
  var $Symbol = typeof Symbol === "function" ? Symbol : {};
  var iteratorSymbol = $Symbol.iterator || "@@iterator";
  var asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator";
  var toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";

  function define(obj, key, value) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
    return obj[key];
  }
  try {
    // IE 8 has a broken Object.defineProperty that only works on DOM objects.
    define({}, "");
  } catch (err) {
    define = function(obj, key, value) {
      return obj[key] = value;
    };
  }

  function wrap(innerFn, outerFn, self, tryLocsList) {
    // If outerFn provided and outerFn.prototype is a Generator, then outerFn.prototype instanceof Generator.
    var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator;
    var generator = Object.create(protoGenerator.prototype);
    var context = new Context(tryLocsList || []);

    // The ._invoke method unifies the implementations of the .next,
    // .throw, and .return methods.
    generator._invoke = makeInvokeMethod(innerFn, self, context);

    return generator;
  }
  exports.wrap = wrap;

  // Try/catch helper to minimize deoptimizations. Returns a completion
  // record like context.tryEntries[i].completion. This interface could
  // have been (and was previously) designed to take a closure to be
  // invoked without arguments, but in all the cases we care about we
  // already have an existing method we want to call, so there's no need
  // to create a new function object. We can even get away with assuming
  // the method takes exactly one argument, since that happens to be true
  // in every case, so we don't have to touch the arguments object. The
  // only additional allocation required is the completion record, which
  // has a stable shape and so hopefully should be cheap to allocate.
  function tryCatch(fn, obj, arg) {
    try {
      return { type: "normal", arg: fn.call(obj, arg) };
    } catch (err) {
      return { type: "throw", arg: err };
    }
  }

  var GenStateSuspendedStart = "suspendedStart";
  var GenStateSuspendedYield = "suspendedYield";
  var GenStateExecuting = "executing";
  var GenStateCompleted = "completed";

  // Returning this object from the innerFn has the same effect as
  // breaking out of the dispatch switch statement.
  var ContinueSentinel = {};

  // Dummy constructor functions that we use as the .constructor and
  // .constructor.prototype properties for functions that return Generator
  // objects. For full spec compliance, you may wish to configure your
  // minifier not to mangle the names of these two functions.
  function Generator() {}
  function GeneratorFunction() {}
  function GeneratorFunctionPrototype() {}

  // This is a polyfill for %IteratorPrototype% for environments that
  // don't natively support it.
  var IteratorPrototype = {};
  define(IteratorPrototype, iteratorSymbol, function () {
    return this;
  });

  var getProto = Object.getPrototypeOf;
  var NativeIteratorPrototype = getProto && getProto(getProto(values([])));
  if (NativeIteratorPrototype &&
      NativeIteratorPrototype !== Op &&
      hasOwn.call(NativeIteratorPrototype, iteratorSymbol)) {
    // This environment has a native %IteratorPrototype%; use it instead
    // of the polyfill.
    IteratorPrototype = NativeIteratorPrototype;
  }

  var Gp = GeneratorFunctionPrototype.prototype =
    Generator.prototype = Object.create(IteratorPrototype);
  GeneratorFunction.prototype = GeneratorFunctionPrototype;
  define(Gp, "constructor", GeneratorFunctionPrototype);
  define(GeneratorFunctionPrototype, "constructor", GeneratorFunction);
  GeneratorFunction.displayName = define(
    GeneratorFunctionPrototype,
    toStringTagSymbol,
    "GeneratorFunction"
  );

  // Helper for defining the .next, .throw, and .return methods of the
  // Iterator interface in terms of a single ._invoke method.
  function defineIteratorMethods(prototype) {
    ["next", "throw", "return"].forEach(function(method) {
      define(prototype, method, function(arg) {
        return this._invoke(method, arg);
      });
    });
  }

  exports.isGeneratorFunction = function(genFun) {
    var ctor = typeof genFun === "function" && genFun.constructor;
    return ctor
      ? ctor === GeneratorFunction ||
        // For the native GeneratorFunction constructor, the best we can
        // do is to check its .name property.
        (ctor.displayName || ctor.name) === "GeneratorFunction"
      : false;
  };

  exports.mark = function(genFun) {
    if (Object.setPrototypeOf) {
      Object.setPrototypeOf(genFun, GeneratorFunctionPrototype);
    } else {
      genFun.__proto__ = GeneratorFunctionPrototype;
      define(genFun, toStringTagSymbol, "GeneratorFunction");
    }
    genFun.prototype = Object.create(Gp);
    return genFun;
  };

  // Within the body of any async function, `await x` is transformed to
  // `yield regeneratorRuntime.awrap(x)`, so that the runtime can test
  // `hasOwn.call(value, "__await")` to determine if the yielded value is
  // meant to be awaited.
  exports.awrap = function(arg) {
    return { __await: arg };
  };

  function AsyncIterator(generator, PromiseImpl) {
    function invoke(method, arg, resolve, reject) {
      var record = tryCatch(generator[method], generator, arg);
      if (record.type === "throw") {
        reject(record.arg);
      } else {
        var result = record.arg;
        var value = result.value;
        if (value &&
            typeof value === "object" &&
            hasOwn.call(value, "__await")) {
          return PromiseImpl.resolve(value.__await).then(function(value) {
            invoke("next", value, resolve, reject);
          }, function(err) {
            invoke("throw", err, resolve, reject);
          });
        }

        return PromiseImpl.resolve(value).then(function(unwrapped) {
          // When a yielded Promise is resolved, its final value becomes
          // the .value of the Promise<{value,done}> result for the
          // current iteration.
          result.value = unwrapped;
          resolve(result);
        }, function(error) {
          // If a rejected Promise was yielded, throw the rejection back
          // into the async generator function so it can be handled there.
          return invoke("throw", error, resolve, reject);
        });
      }
    }

    var previousPromise;

    function enqueue(method, arg) {
      function callInvokeWithMethodAndArg() {
        return new PromiseImpl(function(resolve, reject) {
          invoke(method, arg, resolve, reject);
        });
      }

      return previousPromise =
        // If enqueue has been called before, then we want to wait until
        // all previous Promises have been resolved before calling invoke,
        // so that results are always delivered in the correct order. If
        // enqueue has not been called before, then it is important to
        // call invoke immediately, without waiting on a callback to fire,
        // so that the async generator function has the opportunity to do
        // any necessary setup in a predictable way. This predictability
        // is why the Promise constructor synchronously invokes its
        // executor callback, and why async functions synchronously
        // execute code before the first await. Since we implement simple
        // async functions in terms of async generators, it is especially
        // important to get this right, even though it requires care.
        previousPromise ? previousPromise.then(
          callInvokeWithMethodAndArg,
          // Avoid propagating failures to Promises returned by later
          // invocations of the iterator.
          callInvokeWithMethodAndArg
        ) : callInvokeWithMethodAndArg();
    }

    // Define the unified helper method that is used to implement .next,
    // .throw, and .return (see defineIteratorMethods).
    this._invoke = enqueue;
  }

  defineIteratorMethods(AsyncIterator.prototype);
  define(AsyncIterator.prototype, asyncIteratorSymbol, function () {
    return this;
  });
  exports.AsyncIterator = AsyncIterator;

  // Note that simple async functions are implemented on top of
  // AsyncIterator objects; they just return a Promise for the value of
  // the final result produced by the iterator.
  exports.async = function(innerFn, outerFn, self, tryLocsList, PromiseImpl) {
    if (PromiseImpl === void 0) PromiseImpl = Promise;

    var iter = new AsyncIterator(
      wrap(innerFn, outerFn, self, tryLocsList),
      PromiseImpl
    );

    return exports.isGeneratorFunction(outerFn)
      ? iter // If outerFn is a generator, return the full iterator.
      : iter.next().then(function(result) {
          return result.done ? result.value : iter.next();
        });
  };

  function makeInvokeMethod(innerFn, self, context) {
    var state = GenStateSuspendedStart;

    return function invoke(method, arg) {
      if (state === GenStateExecuting) {
        throw new Error("Generator is already running");
      }

      if (state === GenStateCompleted) {
        if (method === "throw") {
          throw arg;
        }

        // Be forgiving, per 25.3.3.3.3 of the spec:
        // https://people.mozilla.org/~jorendorff/es6-draft.html#sec-generatorresume
        return doneResult();
      }

      context.method = method;
      context.arg = arg;

      while (true) {
        var delegate = context.delegate;
        if (delegate) {
          var delegateResult = maybeInvokeDelegate(delegate, context);
          if (delegateResult) {
            if (delegateResult === ContinueSentinel) continue;
            return delegateResult;
          }
        }

        if (context.method === "next") {
          // Setting context._sent for legacy support of Babel's
          // function.sent implementation.
          context.sent = context._sent = context.arg;

        } else if (context.method === "throw") {
          if (state === GenStateSuspendedStart) {
            state = GenStateCompleted;
            throw context.arg;
          }

          context.dispatchException(context.arg);

        } else if (context.method === "return") {
          context.abrupt("return", context.arg);
        }

        state = GenStateExecuting;

        var record = tryCatch(innerFn, self, context);
        if (record.type === "normal") {
          // If an exception is thrown from innerFn, we leave state ===
          // GenStateExecuting and loop back for another invocation.
          state = context.done
            ? GenStateCompleted
            : GenStateSuspendedYield;

          if (record.arg === ContinueSentinel) {
            continue;
          }

          return {
            value: record.arg,
            done: context.done
          };

        } else if (record.type === "throw") {
          state = GenStateCompleted;
          // Dispatch the exception by looping back around to the
          // context.dispatchException(context.arg) call above.
          context.method = "throw";
          context.arg = record.arg;
        }
      }
    };
  }

  // Call delegate.iterator[context.method](context.arg) and handle the
  // result, either by returning a { value, done } result from the
  // delegate iterator, or by modifying context.method and context.arg,
  // setting context.delegate to null, and returning the ContinueSentinel.
  function maybeInvokeDelegate(delegate, context) {
    var method = delegate.iterator[context.method];
    if (method === undefined) {
      // A .throw or .return when the delegate iterator has no .throw
      // method always terminates the yield* loop.
      context.delegate = null;

      if (context.method === "throw") {
        // Note: ["return"] must be used for ES3 parsing compatibility.
        if (delegate.iterator["return"]) {
          // If the delegate iterator has a return method, give it a
          // chance to clean up.
          context.method = "return";
          context.arg = undefined;
          maybeInvokeDelegate(delegate, context);

          if (context.method === "throw") {
            // If maybeInvokeDelegate(context) changed context.method from
            // "return" to "throw", let that override the TypeError below.
            return ContinueSentinel;
          }
        }

        context.method = "throw";
        context.arg = new TypeError(
          "The iterator does not provide a 'throw' method");
      }

      return ContinueSentinel;
    }

    var record = tryCatch(method, delegate.iterator, context.arg);

    if (record.type === "throw") {
      context.method = "throw";
      context.arg = record.arg;
      context.delegate = null;
      return ContinueSentinel;
    }

    var info = record.arg;

    if (! info) {
      context.method = "throw";
      context.arg = new TypeError("iterator result is not an object");
      context.delegate = null;
      return ContinueSentinel;
    }

    if (info.done) {
      // Assign the result of the finished delegate to the temporary
      // variable specified by delegate.resultName (see delegateYield).
      context[delegate.resultName] = info.value;

      // Resume execution at the desired location (see delegateYield).
      context.next = delegate.nextLoc;

      // If context.method was "throw" but the delegate handled the
      // exception, let the outer generator proceed normally. If
      // context.method was "next", forget context.arg since it has been
      // "consumed" by the delegate iterator. If context.method was
      // "return", allow the original .return call to continue in the
      // outer generator.
      if (context.method !== "return") {
        context.method = "next";
        context.arg = undefined;
      }

    } else {
      // Re-yield the result returned by the delegate method.
      return info;
    }

    // The delegate iterator is finished, so forget it and continue with
    // the outer generator.
    context.delegate = null;
    return ContinueSentinel;
  }

  // Define Generator.prototype.{next,throw,return} in terms of the
  // unified ._invoke helper method.
  defineIteratorMethods(Gp);

  define(Gp, toStringTagSymbol, "Generator");

  // A Generator should always return itself as the iterator object when the
  // @@iterator function is called on it. Some browsers' implementations of the
  // iterator prototype chain incorrectly implement this, causing the Generator
  // object to not be returned from this call. This ensures that doesn't happen.
  // See https://github.com/facebook/regenerator/issues/274 for more details.
  define(Gp, iteratorSymbol, function() {
    return this;
  });

  define(Gp, "toString", function() {
    return "[object Generator]";
  });

  function pushTryEntry(locs) {
    var entry = { tryLoc: locs[0] };

    if (1 in locs) {
      entry.catchLoc = locs[1];
    }

    if (2 in locs) {
      entry.finallyLoc = locs[2];
      entry.afterLoc = locs[3];
    }

    this.tryEntries.push(entry);
  }

  function resetTryEntry(entry) {
    var record = entry.completion || {};
    record.type = "normal";
    delete record.arg;
    entry.completion = record;
  }

  function Context(tryLocsList) {
    // The root entry object (effectively a try statement without a catch
    // or a finally block) gives us a place to store values thrown from
    // locations where there is no enclosing try statement.
    this.tryEntries = [{ tryLoc: "root" }];
    tryLocsList.forEach(pushTryEntry, this);
    this.reset(true);
  }

  exports.keys = function(object) {
    var keys = [];
    for (var key in object) {
      keys.push(key);
    }
    keys.reverse();

    // Rather than returning an object with a next method, we keep
    // things simple and return the next function itself.
    return function next() {
      while (keys.length) {
        var key = keys.pop();
        if (key in object) {
          next.value = key;
          next.done = false;
          return next;
        }
      }

      // To avoid creating an additional object, we just hang the .value
      // and .done properties off the next function object itself. This
      // also ensures that the minifier will not anonymize the function.
      next.done = true;
      return next;
    };
  };

  function values(iterable) {
    if (iterable) {
      var iteratorMethod = iterable[iteratorSymbol];
      if (iteratorMethod) {
        return iteratorMethod.call(iterable);
      }

      if (typeof iterable.next === "function") {
        return iterable;
      }

      if (!isNaN(iterable.length)) {
        var i = -1, next = function next() {
          while (++i < iterable.length) {
            if (hasOwn.call(iterable, i)) {
              next.value = iterable[i];
              next.done = false;
              return next;
            }
          }

          next.value = undefined;
          next.done = true;

          return next;
        };

        return next.next = next;
      }
    }

    // Return an iterator with no values.
    return { next: doneResult };
  }
  exports.values = values;

  function doneResult() {
    return { value: undefined, done: true };
  }

  Context.prototype = {
    constructor: Context,

    reset: function(skipTempReset) {
      this.prev = 0;
      this.next = 0;
      // Resetting context._sent for legacy support of Babel's
      // function.sent implementation.
      this.sent = this._sent = undefined;
      this.done = false;
      this.delegate = null;

      this.method = "next";
      this.arg = undefined;

      this.tryEntries.forEach(resetTryEntry);

      if (!skipTempReset) {
        for (var name in this) {
          // Not sure about the optimal order of these conditions:
          if (name.charAt(0) === "t" &&
              hasOwn.call(this, name) &&
              !isNaN(+name.slice(1))) {
            this[name] = undefined;
          }
        }
      }
    },

    stop: function() {
      this.done = true;

      var rootEntry = this.tryEntries[0];
      var rootRecord = rootEntry.completion;
      if (rootRecord.type === "throw") {
        throw rootRecord.arg;
      }

      return this.rval;
    },

    dispatchException: function(exception) {
      if (this.done) {
        throw exception;
      }

      var context = this;
      function handle(loc, caught) {
        record.type = "throw";
        record.arg = exception;
        context.next = loc;

        if (caught) {
          // If the dispatched exception was caught by a catch block,
          // then let that catch block handle the exception normally.
          context.method = "next";
          context.arg = undefined;
        }

        return !! caught;
      }

      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        var record = entry.completion;

        if (entry.tryLoc === "root") {
          // Exception thrown outside of any try block that could handle
          // it, so set the completion value of the entire function to
          // throw the exception.
          return handle("end");
        }

        if (entry.tryLoc <= this.prev) {
          var hasCatch = hasOwn.call(entry, "catchLoc");
          var hasFinally = hasOwn.call(entry, "finallyLoc");

          if (hasCatch && hasFinally) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            } else if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }

          } else if (hasCatch) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            }

          } else if (hasFinally) {
            if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }

          } else {
            throw new Error("try statement without catch or finally");
          }
        }
      }
    },

    abrupt: function(type, arg) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc <= this.prev &&
            hasOwn.call(entry, "finallyLoc") &&
            this.prev < entry.finallyLoc) {
          var finallyEntry = entry;
          break;
        }
      }

      if (finallyEntry &&
          (type === "break" ||
           type === "continue") &&
          finallyEntry.tryLoc <= arg &&
          arg <= finallyEntry.finallyLoc) {
        // Ignore the finally entry if control is not jumping to a
        // location outside the try/catch block.
        finallyEntry = null;
      }

      var record = finallyEntry ? finallyEntry.completion : {};
      record.type = type;
      record.arg = arg;

      if (finallyEntry) {
        this.method = "next";
        this.next = finallyEntry.finallyLoc;
        return ContinueSentinel;
      }

      return this.complete(record);
    },

    complete: function(record, afterLoc) {
      if (record.type === "throw") {
        throw record.arg;
      }

      if (record.type === "break" ||
          record.type === "continue") {
        this.next = record.arg;
      } else if (record.type === "return") {
        this.rval = this.arg = record.arg;
        this.method = "return";
        this.next = "end";
      } else if (record.type === "normal" && afterLoc) {
        this.next = afterLoc;
      }

      return ContinueSentinel;
    },

    finish: function(finallyLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.finallyLoc === finallyLoc) {
          this.complete(entry.completion, entry.afterLoc);
          resetTryEntry(entry);
          return ContinueSentinel;
        }
      }
    },

    "catch": function(tryLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc === tryLoc) {
          var record = entry.completion;
          if (record.type === "throw") {
            var thrown = record.arg;
            resetTryEntry(entry);
          }
          return thrown;
        }
      }

      // The context.catch method must only be called with a location
      // argument that corresponds to a known catch block.
      throw new Error("illegal catch attempt");
    },

    delegateYield: function(iterable, resultName, nextLoc) {
      this.delegate = {
        iterator: values(iterable),
        resultName: resultName,
        nextLoc: nextLoc
      };

      if (this.method === "next") {
        // Deliberately forget the last sent value so that we don't
        // accidentally pass it on to the delegate.
        this.arg = undefined;
      }

      return ContinueSentinel;
    }
  };

  // Regardless of whether this script is executing as a CommonJS module
  // or not, return the runtime object so that we can declare the variable
  // regeneratorRuntime in the outer scope, which allows this module to be
  // injected easily by `bin/regenerator --include-runtime script.js`.
  return exports;

}(
  // If this script is executing as a CommonJS module, use module.exports
  // as the regeneratorRuntime namespace. Otherwise create a new empty
  // object. Either way, the resulting object will be used to initialize
  // the regeneratorRuntime variable at the top of this file.
   true ? module.exports : undefined
));

try {
  regeneratorRuntime = runtime;
} catch (accidentalStrictMode) {
  // This module should not be running in strict mode, so the above
  // assignment should always work unless something is misconfigured. Just
  // in case runtime.js accidentally runs in strict mode, in modern engines
  // we can explicitly access globalThis. In older engines we can escape
  // strict mode using a global Function call. This could conceivably fail
  // if a Content Security Policy forbids using Function, but in that case
  // the proper solution is to fix the accidental strict mode problem. If
  // you've misconfigured your bundler to force strict mode and applied a
  // CSP to forbid Function, and you're not willing to fix either of those
  // problems, please detail your unique predicament in a GitHub issue.
  if (typeof globalThis === "object") {
    globalThis.regeneratorRuntime = runtime;
  } else {
    Function("r", "regeneratorRuntime = r")(runtime);
  }
}

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@skpm/promise/index.js */ "./node_modules/@skpm/promise/index.js")))

/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/browser-api.js":
/*!****************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/browser-api.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function parseHexColor(color) {
  // Check the string for incorrect formatting.
  if (!color || color[0] !== '#') {
    if (
      color &&
      typeof color.isKindOfClass === 'function' &&
      color.isKindOfClass(NSColor)
    ) {
      return color
    }
    throw new Error(
      'Incorrect color formating. It should be an hex color: #RRGGBBAA'
    )
  }

  // append FF if alpha channel is not specified.
  var source = color.substr(1)
  if (source.length === 3) {
    source += 'F'
  } else if (source.length === 6) {
    source += 'FF'
  }
  // Convert the string from #FFF format to #FFFFFF format.
  var hex
  if (source.length === 4) {
    for (var i = 0; i < 4; i += 1) {
      hex += source[i]
      hex += source[i]
    }
  } else if (source.length === 8) {
    hex = source
  } else {
    return NSColor.whiteColor()
  }

  var r = parseInt(hex.slice(0, 2), 16) / 255
  var g = parseInt(hex.slice(2, 4), 16) / 255
  var b = parseInt(hex.slice(4, 6), 16) / 255
  var a = parseInt(hex.slice(6, 8), 16) / 255

  return NSColor.colorWithSRGBRed_green_blue_alpha(r, g, b, a)
}

module.exports = function (browserWindow, panel, webview) {
  // keep reference to the subviews
  browserWindow._panel = panel
  browserWindow._webview = webview
  browserWindow._destroyed = false

  browserWindow.destroy = function () {
    return panel.close()
  }

  browserWindow.close = function () {
    if (panel.delegate().utils && panel.delegate().utils.parentWindow) {
      var shouldClose = true
      browserWindow.emit('close', {
        get defaultPrevented() {
          return !shouldClose
        },
        preventDefault: function () {
          shouldClose = false
        },
      })
      if (shouldClose) {
        panel.delegate().utils.parentWindow.endSheet(panel)
      }
      return
    }

    if (!browserWindow.isClosable()) {
      return
    }

    panel.performClose(null)
  }

  function focus(focused) {
    if (!browserWindow.isVisible()) {
      return
    }
    if (focused) {
      NSApplication.sharedApplication().activateIgnoringOtherApps(true)
      panel.makeKeyAndOrderFront(null)
    } else {
      panel.orderBack(null)
      NSApp.mainWindow().makeKeyAndOrderFront(null)
    }
  }

  browserWindow.focus = focus.bind(this, true)
  browserWindow.blur = focus.bind(this, false)

  browserWindow.isFocused = function () {
    return panel.isKeyWindow()
  }

  browserWindow.isDestroyed = function () {
    return browserWindow._destroyed
  }

  browserWindow.show = function () {
    // This method is supposed to put focus on window, however if the app does not
    // have focus then "makeKeyAndOrderFront" will only show the window.
    NSApp.activateIgnoringOtherApps(true)

    if (panel.delegate().utils && panel.delegate().utils.parentWindow) {
      return panel.delegate().utils.parentWindow.beginSheet_completionHandler(
        panel,
        __mocha__.createBlock_function('v16@?0q8', function () {
          browserWindow.emit('closed')
        })
      )
    }

    return panel.makeKeyAndOrderFront(null)
  }

  browserWindow.showInactive = function () {
    return panel.orderFrontRegardless()
  }

  browserWindow.hide = function () {
    return panel.orderOut(null)
  }

  browserWindow.isVisible = function () {
    return panel.isVisible()
  }

  browserWindow.isModal = function () {
    return false
  }

  browserWindow.maximize = function () {
    if (!browserWindow.isMaximized()) {
      panel.zoom(null)
    }
  }
  browserWindow.unmaximize = function () {
    if (browserWindow.isMaximized()) {
      panel.zoom(null)
    }
  }

  browserWindow.isMaximized = function () {
    if ((panel.styleMask() & NSResizableWindowMask) !== 0) {
      return panel.isZoomed()
    }
    var rectScreen = NSScreen.mainScreen().visibleFrame()
    var rectWindow = panel.frame()
    return (
      rectScreen.origin.x == rectWindow.origin.x &&
      rectScreen.origin.y == rectWindow.origin.y &&
      rectScreen.size.width == rectWindow.size.width &&
      rectScreen.size.height == rectWindow.size.height
    )
  }

  browserWindow.minimize = function () {
    return panel.miniaturize(null)
  }

  browserWindow.restore = function () {
    return panel.deminiaturize(null)
  }

  browserWindow.isMinimized = function () {
    return panel.isMiniaturized()
  }

  browserWindow.setFullScreen = function (fullscreen) {
    if (fullscreen !== browserWindow.isFullscreen()) {
      panel.toggleFullScreen(null)
    }
  }

  browserWindow.isFullscreen = function () {
    return panel.styleMask() & NSFullScreenWindowMask
  }

  browserWindow.setAspectRatio = function (aspectRatio /* , extraSize */) {
    // Reset the behaviour to default if aspect_ratio is set to 0 or less.
    if (aspectRatio > 0.0) {
      panel.setAspectRatio(NSMakeSize(aspectRatio, 1.0))
    } else {
      panel.setResizeIncrements(NSMakeSize(1.0, 1.0))
    }
  }

  browserWindow.setBounds = function (bounds, animate) {
    if (!bounds) {
      return
    }

    // Do nothing if in fullscreen mode.
    if (browserWindow.isFullscreen()) {
      return
    }

    const newBounds = Object.assign(browserWindow.getBounds(), bounds)

    // TODO: Check size constraints since setFrame does not check it.
    // var size = bounds.size
    // size.SetToMax(GetMinimumSize());
    // gfx::Size max_size = GetMaximumSize();
    // if (!max_size.IsEmpty())
    //   size.SetToMin(max_size);

    var cocoaBounds = NSMakeRect(
      newBounds.x,
      0,
      newBounds.width,
      newBounds.height
    )
    // Flip Y coordinates based on the primary screen
    var screen = NSScreen.screens().firstObject()
    cocoaBounds.origin.y = NSHeight(screen.frame()) - newBounds.y

    panel.setFrame_display_animate(cocoaBounds, true, animate)
  }

  browserWindow.getBounds = function () {
    const cocoaBounds = panel.frame()
    var mainScreenRect = NSScreen.screens().firstObject().frame()
    return {
      x: cocoaBounds.origin.x,
      y: Math.round(NSHeight(mainScreenRect) - cocoaBounds.origin.y),
      width: cocoaBounds.size.width,
      height: cocoaBounds.size.height,
    }
  }

  browserWindow.setContentBounds = function (bounds, animate) {
    // TODO:
    browserWindow.setBounds(bounds, animate)
  }

  browserWindow.getContentBounds = function () {
    // TODO:
    return browserWindow.getBounds()
  }

  browserWindow.setSize = function (width, height, animate) {
    // TODO: handle resizing around center
    return browserWindow.setBounds({ width: width, height: height }, animate)
  }

  browserWindow.getSize = function () {
    var bounds = browserWindow.getBounds()
    return [bounds.width, bounds.height]
  }

  browserWindow.setContentSize = function (width, height, animate) {
    // TODO: handle resizing around center
    return browserWindow.setContentBounds(
      { width: width, height: height },
      animate
    )
  }

  browserWindow.getContentSize = function () {
    var bounds = browserWindow.getContentBounds()
    return [bounds.width, bounds.height]
  }

  browserWindow.setMinimumSize = function (width, height) {
    const minSize = CGSizeMake(width, height)
    panel.setContentMinSize(minSize)
  }

  browserWindow.getMinimumSize = function () {
    const size = panel.contentMinSize()
    return [size.width, size.height]
  }

  browserWindow.setMaximumSize = function (width, height) {
    const maxSize = CGSizeMake(width, height)
    panel.setContentMaxSize(maxSize)
  }

  browserWindow.getMaximumSize = function () {
    const size = panel.contentMaxSize()
    return [size.width, size.height]
  }

  browserWindow.setResizable = function (resizable) {
    return browserWindow._setStyleMask(resizable, NSResizableWindowMask)
  }

  browserWindow.isResizable = function () {
    return panel.styleMask() & NSResizableWindowMask
  }

  browserWindow.setMovable = function (movable) {
    return panel.setMovable(movable)
  }
  browserWindow.isMovable = function () {
    return panel.isMovable()
  }

  browserWindow.setMinimizable = function (minimizable) {
    return browserWindow._setStyleMask(minimizable, NSMiniaturizableWindowMask)
  }

  browserWindow.isMinimizable = function () {
    return panel.styleMask() & NSMiniaturizableWindowMask
  }

  browserWindow.setMaximizable = function (maximizable) {
    if (panel.standardWindowButton(NSWindowZoomButton)) {
      panel.standardWindowButton(NSWindowZoomButton).setEnabled(maximizable)
    }
  }

  browserWindow.isMaximizable = function () {
    return (
      panel.standardWindowButton(NSWindowZoomButton) &&
      panel.standardWindowButton(NSWindowZoomButton).isEnabled()
    )
  }

  browserWindow.setFullScreenable = function (fullscreenable) {
    browserWindow._setCollectionBehavior(
      fullscreenable,
      NSWindowCollectionBehaviorFullScreenPrimary
    )
    // On EL Capitan this flag is required to hide fullscreen button.
    browserWindow._setCollectionBehavior(
      !fullscreenable,
      NSWindowCollectionBehaviorFullScreenAuxiliary
    )
  }

  browserWindow.isFullScreenable = function () {
    var collectionBehavior = panel.collectionBehavior()
    return collectionBehavior & NSWindowCollectionBehaviorFullScreenPrimary
  }

  browserWindow.setClosable = function (closable) {
    browserWindow._setStyleMask(closable, NSClosableWindowMask)
  }

  browserWindow.isClosable = function () {
    return panel.styleMask() & NSClosableWindowMask
  }

  browserWindow.setAlwaysOnTop = function (top, level, relativeLevel) {
    var windowLevel = NSNormalWindowLevel
    var maxWindowLevel = CGWindowLevelForKey(kCGMaximumWindowLevelKey)
    var minWindowLevel = CGWindowLevelForKey(kCGMinimumWindowLevelKey)

    if (top) {
      if (level === 'normal') {
        windowLevel = NSNormalWindowLevel
      } else if (level === 'torn-off-menu') {
        windowLevel = NSTornOffMenuWindowLevel
      } else if (level === 'modal-panel') {
        windowLevel = NSModalPanelWindowLevel
      } else if (level === 'main-menu') {
        windowLevel = NSMainMenuWindowLevel
      } else if (level === 'status') {
        windowLevel = NSStatusWindowLevel
      } else if (level === 'pop-up-menu') {
        windowLevel = NSPopUpMenuWindowLevel
      } else if (level === 'screen-saver') {
        windowLevel = NSScreenSaverWindowLevel
      } else if (level === 'dock') {
        // Deprecated by macOS, but kept for backwards compatibility
        windowLevel = NSDockWindowLevel
      } else {
        windowLevel = NSFloatingWindowLevel
      }
    }

    var newLevel = windowLevel + (relativeLevel || 0)
    if (newLevel >= minWindowLevel && newLevel <= maxWindowLevel) {
      panel.setLevel(newLevel)
    } else {
      throw new Error(
        'relativeLevel must be between ' +
          minWindowLevel +
          ' and ' +
          maxWindowLevel
      )
    }
  }

  browserWindow.isAlwaysOnTop = function () {
    return panel.level() !== NSNormalWindowLevel
  }

  browserWindow.moveTop = function () {
    return panel.orderFrontRegardless()
  }

  browserWindow.center = function () {
    panel.center()
  }

  browserWindow.setPosition = function (x, y, animate) {
    return browserWindow.setBounds({ x: x, y: y }, animate)
  }

  browserWindow.getPosition = function () {
    var bounds = browserWindow.getBounds()
    return [bounds.x, bounds.y]
  }

  browserWindow.setTitle = function (title) {
    panel.setTitle(title)
  }

  browserWindow.getTitle = function () {
    return String(panel.title())
  }

  var attentionRequestId = 0
  browserWindow.flashFrame = function (flash) {
    if (flash) {
      attentionRequestId = NSApp.requestUserAttention(NSInformationalRequest)
    } else {
      NSApp.cancelUserAttentionRequest(attentionRequestId)
      attentionRequestId = 0
    }
  }

  browserWindow.getNativeWindowHandle = function () {
    return panel
  }

  browserWindow.getNativeWebViewHandle = function () {
    return webview
  }

  browserWindow.loadURL = function (url) {
    // When frameLocation is a file, prefix it with the Sketch Resources path
    if (/^(?!https?|file).*\.html?$/.test(url)) {
      if (typeof __command !== 'undefined' && __command.pluginBundle()) {
        url =
          'file://' + __command.pluginBundle().urlForResourceNamed(url).path()
      }
    }

    if (/^file:\/\/.*\.html?$/.test(url)) {
      // ensure URLs containing spaces are properly handled
      url = NSString.alloc().initWithString(url)
      url = url.stringByAddingPercentEncodingWithAllowedCharacters(
        NSCharacterSet.URLQueryAllowedCharacterSet()
      )
      webview.loadFileURL_allowingReadAccessToURL(
        NSURL.URLWithString(url),
        NSURL.URLWithString('file:///')
      )
      return
    }

    const properURL = NSURL.URLWithString(url)
    const urlRequest = NSURLRequest.requestWithURL(properURL)

    webview.loadRequest(urlRequest)
  }

  browserWindow.reload = function () {
    webview.reload()
  }

  browserWindow.setHasShadow = function (hasShadow) {
    return panel.setHasShadow(hasShadow)
  }

  browserWindow.hasShadow = function () {
    return panel.hasShadow()
  }

  browserWindow.setOpacity = function (opacity) {
    return panel.setAlphaValue(opacity)
  }

  browserWindow.getOpacity = function () {
    return panel.alphaValue()
  }

  browserWindow.setVisibleOnAllWorkspaces = function (visible) {
    return browserWindow._setCollectionBehavior(
      visible,
      NSWindowCollectionBehaviorCanJoinAllSpaces
    )
  }

  browserWindow.isVisibleOnAllWorkspaces = function () {
    var collectionBehavior = panel.collectionBehavior()
    return collectionBehavior & NSWindowCollectionBehaviorCanJoinAllSpaces
  }

  browserWindow.setIgnoreMouseEvents = function (ignore) {
    return panel.setIgnoresMouseEvents(ignore)
  }

  browserWindow.setContentProtection = function (enable) {
    panel.setSharingType(enable ? NSWindowSharingNone : NSWindowSharingReadOnly)
  }

  browserWindow.setAutoHideCursor = function (autoHide) {
    panel.setDisableAutoHideCursor(autoHide)
  }

  browserWindow.setVibrancy = function (type) {
    var effectView = browserWindow._vibrantView

    if (!type) {
      if (effectView == null) {
        return
      }

      effectView.removeFromSuperview()
      panel.setVibrantView(null)
      return
    }

    if (effectView == null) {
      var contentView = panel.contentView()
      effectView = NSVisualEffectView.alloc().initWithFrame(
        contentView.bounds()
      )
      browserWindow._vibrantView = effectView

      effectView.setAutoresizingMask(NSViewWidthSizable | NSViewHeightSizable)
      effectView.setBlendingMode(NSVisualEffectBlendingModeBehindWindow)
      effectView.setState(NSVisualEffectStateActive)
      effectView.setFrame(contentView.bounds())
      contentView.addSubview_positioned_relativeTo(
        effectView,
        NSWindowBelow,
        null
      )
    }

    var vibrancyType = NSVisualEffectMaterialLight

    if (type === 'appearance-based') {
      vibrancyType = NSVisualEffectMaterialAppearanceBased
    } else if (type === 'light') {
      vibrancyType = NSVisualEffectMaterialLight
    } else if (type === 'dark') {
      vibrancyType = NSVisualEffectMaterialDark
    } else if (type === 'titlebar') {
      vibrancyType = NSVisualEffectMaterialTitlebar
    } else if (type === 'selection') {
      vibrancyType = NSVisualEffectMaterialSelection
    } else if (type === 'menu') {
      vibrancyType = NSVisualEffectMaterialMenu
    } else if (type === 'popover') {
      vibrancyType = NSVisualEffectMaterialPopover
    } else if (type === 'sidebar') {
      vibrancyType = NSVisualEffectMaterialSidebar
    } else if (type === 'medium-light') {
      vibrancyType = NSVisualEffectMaterialMediumLight
    } else if (type === 'ultra-dark') {
      vibrancyType = NSVisualEffectMaterialUltraDark
    }

    effectView.setMaterial(vibrancyType)
  }

  browserWindow._setBackgroundColor = function (colorName) {
    var color = parseHexColor(colorName)
    webview.setValue_forKey(false, 'drawsBackground')
    panel.backgroundColor = color
  }

  browserWindow._invalidate = function () {
    panel.flushWindow()
    panel.contentView().setNeedsDisplay(true)
  }

  browserWindow._setStyleMask = function (on, flag) {
    var wasMaximizable = browserWindow.isMaximizable()
    if (on) {
      panel.setStyleMask(panel.styleMask() | flag)
    } else {
      panel.setStyleMask(panel.styleMask() & ~flag)
    }
    // Change style mask will make the zoom button revert to default, probably
    // a bug of Cocoa or macOS.
    browserWindow.setMaximizable(wasMaximizable)
  }

  browserWindow._setCollectionBehavior = function (on, flag) {
    var wasMaximizable = browserWindow.isMaximizable()
    if (on) {
      panel.setCollectionBehavior(panel.collectionBehavior() | flag)
    } else {
      panel.setCollectionBehavior(panel.collectionBehavior() & ~flag)
    }
    // Change collectionBehavior will make the zoom button revert to default,
    // probably a bug of Cocoa or macOS.
    browserWindow.setMaximizable(wasMaximizable)
  }

  browserWindow._showWindowButton = function (button) {
    var view = panel.standardWindowButton(button)
    view.superview().addSubview_positioned_relative(view, NSWindowAbove, null)
  }
}


/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/constants.js":
/*!**************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/constants.js ***!
  \**************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = {
  JS_BRIDGE: '__skpm_sketchBridge',
  JS_BRIDGE_RESULT_SUCCESS: '__skpm_sketchBridge_success',
  JS_BRIDGE_RESULT_ERROR: '__skpm_sketchBridge_error',
  START_MOVING_WINDOW: '__skpm_startMovingWindow',
  EXECUTE_JAVASCRIPT: '__skpm_executeJS',
  EXECUTE_JAVASCRIPT_SUCCESS: '__skpm_executeJS_success_',
  EXECUTE_JAVASCRIPT_ERROR: '__skpm_executeJS_error_',
}


/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/dispatch-first-click.js":
/*!*************************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/dispatch-first-click.js ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

var tagsToFocus =
  '["text", "textarea", "date", "datetime-local", "email", "number", "month", "password", "search", "tel", "time", "url", "week" ]'

module.exports = function (webView, event) {
  var point = webView.convertPoint_fromView(event.locationInWindow(), null)
  return (
    'var el = document.elementFromPoint(' + // get the DOM element that match the event
    point.x +
    ', ' +
    point.y +
    '); ' +
    'if (el && el.tagName === "SELECT") {' + // select needs special handling
    '  var event = document.createEvent("MouseEvents");' +
    '  event.initMouseEvent("mousedown", true, true, window);' +
    '  el.dispatchEvent(event);' +
    '} else if (el && ' + // some tags need to be focused instead of clicked
    tagsToFocus +
    '.indexOf(el.type) >= 0 && ' +
    'el.focus' +
    ') {' +
    'el.focus();' + // so focus them
    '} else if (el) {' +
    'el.dispatchEvent(new Event("click", {bubbles: true}))' + // click the others
    '}'
  )
}


/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/execute-javascript.js":
/*!***********************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/execute-javascript.js ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(Promise) {var CONSTANTS = __webpack_require__(/*! ./constants */ "./node_modules/sketch-module-web-view/lib/constants.js")

module.exports = function (webview, browserWindow) {
  function executeJavaScript(script, userGesture, callback) {
    if (typeof userGesture === 'function') {
      callback = userGesture
      userGesture = false
    }
    var fiber = coscript.createFiber()

    // if the webview is not ready yet, defer the execution until it is
    if (
      webview.navigationDelegate().state &&
      webview.navigationDelegate().state.wasReady == 0
    ) {
      return new Promise(function (resolve, reject) {
        browserWindow.once('ready-to-show', function () {
          executeJavaScript(script, userGesture, callback)
            .then(resolve)
            .catch(reject)
          fiber.cleanup()
        })
      })
    }

    return new Promise(function (resolve, reject) {
      var requestId = Math.random()

      browserWindow.webContents.on(
        CONSTANTS.EXECUTE_JAVASCRIPT_SUCCESS + requestId,
        function (res) {
          try {
            if (callback) {
              callback(null, res)
            }
            resolve(res)
          } catch (err) {
            reject(err)
          }
          fiber.cleanup()
        }
      )
      browserWindow.webContents.on(
        CONSTANTS.EXECUTE_JAVASCRIPT_ERROR + requestId,
        function (err) {
          try {
            if (callback) {
              callback(err)
              resolve()
            } else {
              reject(err)
            }
          } catch (err2) {
            reject(err2)
          }
          fiber.cleanup()
        }
      )

      webview.evaluateJavaScript_completionHandler(
        module.exports.wrapScript(script, requestId),
        null
      )
    })
  }

  return executeJavaScript
}

module.exports.wrapScript = function (script, requestId) {
  return (
    'window.' +
    CONSTANTS.EXECUTE_JAVASCRIPT +
    '(' +
    requestId +
    ', ' +
    JSON.stringify(script) +
    ')'
  )
}

module.exports.injectScript = function (webView) {
  var source =
    'window.' +
    CONSTANTS.EXECUTE_JAVASCRIPT +
    ' = function(id, script) {' +
    '  try {' +
    '    var res = eval(script);' +
    '    if (res && typeof res.then === "function" && typeof res.catch === "function") {' +
    '      res.then(function (res2) {' +
    '        window.postMessage("' +
    CONSTANTS.EXECUTE_JAVASCRIPT_SUCCESS +
    '" + id, res2);' +
    '      })' +
    '      .catch(function (err) {' +
    '        window.postMessage("' +
    CONSTANTS.EXECUTE_JAVASCRIPT_ERROR +
    '" + id, err);' +
    '      })' +
    '    } else {' +
    '      window.postMessage("' +
    CONSTANTS.EXECUTE_JAVASCRIPT_SUCCESS +
    '" + id, res);' +
    '    }' +
    '  } catch (err) {' +
    '    window.postMessage("' +
    CONSTANTS.EXECUTE_JAVASCRIPT_ERROR +
    '" + id, err);' +
    '  }' +
    '}'
  var script = WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
    source,
    0,
    true
  )
  webView.configuration().userContentController().addUserScript(script)
}

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@skpm/promise/index.js */ "./node_modules/@skpm/promise/index.js")))

/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/fitSubview.js":
/*!***************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/fitSubview.js ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function addEdgeConstraint(edge, subview, view, constant) {
  view.addConstraint(
    NSLayoutConstraint.constraintWithItem_attribute_relatedBy_toItem_attribute_multiplier_constant(
      subview,
      edge,
      NSLayoutRelationEqual,
      view,
      edge,
      1,
      constant
    )
  )
}
module.exports = function fitSubviewToView(subview, view, constants) {
  constants = constants || []
  subview.setTranslatesAutoresizingMaskIntoConstraints(false)

  addEdgeConstraint(NSLayoutAttributeLeft, subview, view, constants[0] || 0)
  addEdgeConstraint(NSLayoutAttributeTop, subview, view, constants[1] || 0)
  addEdgeConstraint(NSLayoutAttributeRight, subview, view, constants[2] || 0)
  addEdgeConstraint(NSLayoutAttributeBottom, subview, view, constants[3] || 0)
}


/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/index.js":
/*!**********************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/index.js ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* let's try to match the API from Electron's Browser window
(https://github.com/electron/electron/blob/master/docs/api/browser-window.md) */
var EventEmitter = __webpack_require__(/*! events */ "events")
var buildBrowserAPI = __webpack_require__(/*! ./browser-api */ "./node_modules/sketch-module-web-view/lib/browser-api.js")
var buildWebAPI = __webpack_require__(/*! ./webview-api */ "./node_modules/sketch-module-web-view/lib/webview-api.js")
var fitSubviewToView = __webpack_require__(/*! ./fitSubview */ "./node_modules/sketch-module-web-view/lib/fitSubview.js")
var dispatchFirstClick = __webpack_require__(/*! ./dispatch-first-click */ "./node_modules/sketch-module-web-view/lib/dispatch-first-click.js")
var injectClientMessaging = __webpack_require__(/*! ./inject-client-messaging */ "./node_modules/sketch-module-web-view/lib/inject-client-messaging.js")
var movableArea = __webpack_require__(/*! ./movable-area */ "./node_modules/sketch-module-web-view/lib/movable-area.js")
var executeJavaScript = __webpack_require__(/*! ./execute-javascript */ "./node_modules/sketch-module-web-view/lib/execute-javascript.js")
var setDelegates = __webpack_require__(/*! ./set-delegates */ "./node_modules/sketch-module-web-view/lib/set-delegates.js")

function BrowserWindow(options) {
  options = options || {}

  var identifier = options.identifier || String(NSUUID.UUID().UUIDString())
  var threadDictionary = NSThread.mainThread().threadDictionary()

  var existingBrowserWindow = BrowserWindow.fromId(identifier)

  // if we already have a window opened, reuse it
  if (existingBrowserWindow) {
    return existingBrowserWindow
  }

  var browserWindow = new EventEmitter()
  browserWindow.id = identifier

  if (options.modal && !options.parent) {
    throw new Error('A modal needs to have a parent.')
  }

  // Long-running script
  var fiber = coscript.createFiber()

  // Window size
  var width = options.width || 800
  var height = options.height || 600
  var mainScreenRect = NSScreen.screens().firstObject().frame()
  var cocoaBounds = NSMakeRect(
    typeof options.x !== 'undefined'
      ? options.x
      : Math.round((NSWidth(mainScreenRect) - width) / 2),
    typeof options.y !== 'undefined'
      ? NSHeight(mainScreenRect) - options.y
      : Math.round((NSHeight(mainScreenRect) - height) / 2),
    width,
    height
  )

  if (options.titleBarStyle && options.titleBarStyle !== 'default') {
    options.frame = false
  }

  var useStandardWindow = options.windowType !== 'textured'
  var styleMask = NSTitledWindowMask

  // this is commented out because the toolbar doesn't appear otherwise :thinking-face:
  // if (!useStandardWindow || options.frame === false) {
  //   styleMask = NSFullSizeContentViewWindowMask
  // }
  if (options.minimizable !== false) {
    styleMask |= NSMiniaturizableWindowMask
  }
  if (options.closable !== false) {
    styleMask |= NSClosableWindowMask
  }
  if (options.resizable !== false) {
    styleMask |= NSResizableWindowMask
  }
  if (!useStandardWindow || options.transparent || options.frame === false) {
    styleMask |= NSTexturedBackgroundWindowMask
  }

  var panel = NSPanel.alloc().initWithContentRect_styleMask_backing_defer(
    cocoaBounds,
    styleMask,
    NSBackingStoreBuffered,
    true
  )

  // this would be nice but it's crashing on macOS 11.0
  // panel.releasedWhenClosed = true

  var wkwebviewConfig = WKWebViewConfiguration.alloc().init()
  var webView = WKWebView.alloc().initWithFrame_configuration(
    CGRectMake(0, 0, options.width || 800, options.height || 600),
    wkwebviewConfig
  )
  injectClientMessaging(webView)
  webView.setAutoresizingMask(NSViewWidthSizable | NSViewHeightSizable)

  buildBrowserAPI(browserWindow, panel, webView)
  buildWebAPI(browserWindow, panel, webView)
  setDelegates(browserWindow, panel, webView, options)

  if (options.windowType === 'desktop') {
    panel.setLevel(kCGDesktopWindowLevel - 1)
    // panel.setCanBecomeKeyWindow(false)
    panel.setCollectionBehavior(
      NSWindowCollectionBehaviorCanJoinAllSpaces |
        NSWindowCollectionBehaviorStationary |
        NSWindowCollectionBehaviorIgnoresCycle
    )
  }

  if (
    typeof options.minWidth !== 'undefined' ||
    typeof options.minHeight !== 'undefined'
  ) {
    browserWindow.setMinimumSize(options.minWidth || 0, options.minHeight || 0)
  }

  if (
    typeof options.maxWidth !== 'undefined' ||
    typeof options.maxHeight !== 'undefined'
  ) {
    browserWindow.setMaximumSize(
      options.maxWidth || 10000,
      options.maxHeight || 10000
    )
  }

  // if (options.focusable === false) {
  //   panel.setCanBecomeKeyWindow(false)
  // }

  if (options.transparent || options.frame === false) {
    panel.titlebarAppearsTransparent = true
    panel.titleVisibility = NSWindowTitleHidden
    panel.setOpaque(0)
    panel.isMovableByWindowBackground = true
    var toolbar2 = NSToolbar.alloc().initWithIdentifier(
      'titlebarStylingToolbar'
    )
    toolbar2.setShowsBaselineSeparator(false)
    panel.setToolbar(toolbar2)
  }

  if (options.titleBarStyle === 'hiddenInset') {
    var toolbar = NSToolbar.alloc().initWithIdentifier('titlebarStylingToolbar')
    toolbar.setShowsBaselineSeparator(false)
    panel.setToolbar(toolbar)
  }

  if (options.frame === false || !options.useContentSize) {
    browserWindow.setSize(width, height)
  }

  if (options.center) {
    browserWindow.center()
  }

  if (options.alwaysOnTop) {
    browserWindow.setAlwaysOnTop(true)
  }

  if (options.fullscreen) {
    browserWindow.setFullScreen(true)
  }
  browserWindow.setFullScreenable(!!options.fullscreenable)

  let title = options.title
  if (options.frame === false) {
    title = undefined
  } else if (
    typeof title === 'undefined' &&
    typeof __command !== 'undefined' &&
    __command.pluginBundle()
  ) {
    title = __command.pluginBundle().name()
  }

  if (title) {
    browserWindow.setTitle(title)
  }

  var backgroundColor = options.backgroundColor
  if (options.transparent) {
    backgroundColor = NSColor.clearColor()
  }
  if (!backgroundColor && options.frame === false && options.vibrancy) {
    backgroundColor = NSColor.clearColor()
  }

  browserWindow._setBackgroundColor(
    backgroundColor || NSColor.windowBackgroundColor()
  )

  if (options.hasShadow === false) {
    browserWindow.setHasShadow(false)
  }

  if (typeof options.opacity !== 'undefined') {
    browserWindow.setOpacity(options.opacity)
  }

  options.webPreferences = options.webPreferences || {}

  webView
    .configuration()
    .preferences()
    .setValue_forKey(
      options.webPreferences.devTools !== false,
      'developerExtrasEnabled'
    )
  webView
    .configuration()
    .preferences()
    .setValue_forKey(
      options.webPreferences.javascript !== false,
      'javaScriptEnabled'
    )
  webView
    .configuration()
    .preferences()
    .setValue_forKey(!!options.webPreferences.plugins, 'plugInsEnabled')
  webView
    .configuration()
    .preferences()
    .setValue_forKey(
      options.webPreferences.minimumFontSize || 0,
      'minimumFontSize'
    )

  if (options.webPreferences.zoomFactor) {
    webView.setMagnification(options.webPreferences.zoomFactor)
  }

  var contentView = panel.contentView()

  if (options.frame !== false) {
    webView.setFrame(contentView.bounds())
    contentView.addSubview(webView)
  } else {
    // In OSX 10.10, adding subviews to the root view for the NSView hierarchy
    // produces warnings. To eliminate the warnings, we resize the contentView
    // to fill the window, and add subviews to that.
    // http://crbug.com/380412
    contentView.setAutoresizingMask(NSViewWidthSizable | NSViewHeightSizable)
    fitSubviewToView(contentView, contentView.superview())

    webView.setFrame(contentView.bounds())
    contentView.addSubview(webView)

    // The fullscreen button should always be hidden for frameless window.
    if (panel.standardWindowButton(NSWindowFullScreenButton)) {
      panel.standardWindowButton(NSWindowFullScreenButton).setHidden(true)
    }

    if (!options.titleBarStyle || options.titleBarStyle === 'default') {
      // Hide the window buttons.
      panel.standardWindowButton(NSWindowZoomButton).setHidden(true)
      panel.standardWindowButton(NSWindowMiniaturizeButton).setHidden(true)
      panel.standardWindowButton(NSWindowCloseButton).setHidden(true)

      // Some third-party macOS utilities check the zoom button's enabled state to
      // determine whether to show custom UI on hover, so we disable it here to
      // prevent them from doing so in a frameless app window.
      panel.standardWindowButton(NSWindowZoomButton).setEnabled(false)
    }
  }

  if (options.vibrancy) {
    browserWindow.setVibrancy(options.vibrancy)
  }

  // Set maximizable state last to ensure zoom button does not get reset
  // by calls to other APIs.
  browserWindow.setMaximizable(options.maximizable !== false)

  panel.setHidesOnDeactivate(options.hidesOnDeactivate !== false)

  if (options.remembersWindowFrame) {
    panel.setFrameAutosaveName(identifier)
    panel.setFrameUsingName_force(panel.frameAutosaveName(), false)
  }

  if (options.acceptsFirstMouse) {
    browserWindow.on('focus', function (event) {
      if (event.type() === NSEventTypeLeftMouseDown) {
        browserWindow.webContents
          .executeJavaScript(dispatchFirstClick(webView, event))
          .catch(() => {})
      }
    })
  }

  executeJavaScript.injectScript(webView)
  movableArea.injectScript(webView)
  movableArea.setupHandler(browserWindow)

  if (options.show !== false) {
    browserWindow.show()
  }

  browserWindow.on('closed', function () {
    browserWindow._destroyed = true
    threadDictionary.removeObjectForKey(identifier)
    var observer = threadDictionary[identifier + '.themeObserver']
    if (observer) {
      NSApplication.sharedApplication().removeObserver_forKeyPath(
        observer,
        'effectiveAppearance'
      )
      threadDictionary.removeObjectForKey(identifier + '.themeObserver')
    }
    fiber.cleanup()
  })

  threadDictionary[identifier] = panel

  fiber.onCleanup(function () {
    if (!browserWindow._destroyed) {
      browserWindow.destroy()
    }
  })

  return browserWindow
}

BrowserWindow.fromId = function (identifier) {
  var threadDictionary = NSThread.mainThread().threadDictionary()

  if (threadDictionary[identifier]) {
    return BrowserWindow.fromPanel(threadDictionary[identifier], identifier)
  }

  return undefined
}

BrowserWindow.fromPanel = function (panel, identifier) {
  var browserWindow = new EventEmitter()
  browserWindow.id = identifier

  if (!panel || !panel.contentView) {
    throw new Error('needs to pass an NSPanel')
  }

  var webView = null
  var subviews = panel.contentView().subviews()
  for (var i = 0; i < subviews.length; i += 1) {
    if (
      !webView &&
      !subviews[i].isKindOfClass(WKInspectorWKWebView) &&
      subviews[i].isKindOfClass(WKWebView)
    ) {
      webView = subviews[i]
    }
  }

  if (!webView) {
    throw new Error('The panel needs to have a webview')
  }

  buildBrowserAPI(browserWindow, panel, webView)
  buildWebAPI(browserWindow, panel, webView)

  return browserWindow
}

module.exports = BrowserWindow


/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/inject-client-messaging.js":
/*!****************************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/inject-client-messaging.js ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var CONSTANTS = __webpack_require__(/*! ./constants */ "./node_modules/sketch-module-web-view/lib/constants.js")

module.exports = function (webView) {
  var source =
    'window.originalPostMessage = window.postMessage;' +
    'window.postMessage = function(actionName) {' +
    '  if (!actionName) {' +
    "    throw new Error('missing action name')" +
    '  }' +
    '  var id = String(Math.random()).replace(".", "");' +
    '    var args = [].slice.call(arguments);' +
    '    args.unshift(id);' +
    '  return new Promise(function (resolve, reject) {' +
    '    window["' +
    CONSTANTS.JS_BRIDGE_RESULT_SUCCESS +
    '" + id] = resolve;' +
    '    window["' +
    CONSTANTS.JS_BRIDGE_RESULT_ERROR +
    '" + id] = reject;' +
    '    window.webkit.messageHandlers.' +
    CONSTANTS.JS_BRIDGE +
    '.postMessage(JSON.stringify(args));' +
    '  });' +
    '}'
  var script = WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
    source,
    0,
    true
  )
  webView.configuration().userContentController().addUserScript(script)
}


/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/movable-area.js":
/*!*****************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/movable-area.js ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var CONSTANTS = __webpack_require__(/*! ./constants */ "./node_modules/sketch-module-web-view/lib/constants.js")

module.exports.injectScript = function (webView) {
  var source =
    '(function () {' +
    "document.addEventListener('mousedown', onMouseDown);" +
    '' +
    'function shouldDrag(target) {' +
    '  if (!target || (target.dataset || {}).appRegion === "no-drag") { return false }' +
    '  if ((target.dataset || {}).appRegion === "drag") { return true }' +
    '  return shouldDrag(target.parentElement)' +
    '};' +
    '' +
    'function onMouseDown(e) {' +
    '  if (e.button !== 0 || !shouldDrag(e.target)) { return }' +
    '  window.postMessage("' +
    CONSTANTS.START_MOVING_WINDOW +
    '");' +
    '};' +
    '})()'
  var script = WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
    source,
    0,
    true
  )
  webView.configuration().userContentController().addUserScript(script)
}

module.exports.setupHandler = function (browserWindow) {
  var initialMouseLocation = null
  var initialWindowPosition = null
  var interval = null

  function moveWindow() {
    // if the user released the button, stop moving the window
    if (!initialWindowPosition || NSEvent.pressedMouseButtons() !== 1) {
      clearInterval(interval)
      initialMouseLocation = null
      initialWindowPosition = null
      return
    }

    var mouse = NSEvent.mouseLocation()
    browserWindow.setPosition(
      initialWindowPosition.x + (mouse.x - initialMouseLocation.x),
      initialWindowPosition.y + (initialMouseLocation.y - mouse.y), // y is inverted
      false
    )
  }

  browserWindow.webContents.on(CONSTANTS.START_MOVING_WINDOW, function () {
    initialMouseLocation = NSEvent.mouseLocation()
    var position = browserWindow.getPosition()
    initialWindowPosition = {
      x: position[0],
      y: position[1],
    }

    interval = setInterval(moveWindow, 1000 / 60) // 60 fps
  })
}


/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/parseWebArguments.js":
/*!**********************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/parseWebArguments.js ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = function (webArguments) {
  var args = null
  try {
    args = JSON.parse(webArguments)
  } catch (e) {
    // malformed arguments
  }

  if (
    !args ||
    !args.constructor ||
    args.constructor !== Array ||
    args.length == 0
  ) {
    return null
  }

  return args
}


/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/set-delegates.js":
/*!******************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/set-delegates.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(Promise) {var ObjCClass = __webpack_require__(/*! mocha-js-delegate */ "./node_modules/mocha-js-delegate/index.js")
var parseWebArguments = __webpack_require__(/*! ./parseWebArguments */ "./node_modules/sketch-module-web-view/lib/parseWebArguments.js")
var CONSTANTS = __webpack_require__(/*! ./constants */ "./node_modules/sketch-module-web-view/lib/constants.js")

// We create one ObjC class for ourselves here
var WindowDelegateClass
var NavigationDelegateClass
var WebScriptHandlerClass
var ThemeObserverClass

// TODO: events
// - 'page-favicon-updated'
// - 'new-window'
// - 'did-navigate-in-page'
// - 'will-prevent-unload'
// - 'crashed'
// - 'unresponsive'
// - 'responsive'
// - 'destroyed'
// - 'before-input-event'
// - 'certificate-error'
// - 'found-in-page'
// - 'media-started-playing'
// - 'media-paused'
// - 'did-change-theme-color'
// - 'update-target-url'
// - 'cursor-changed'
// - 'context-menu'
// - 'select-bluetooth-device'
// - 'paint'
// - 'console-message'

module.exports = function (browserWindow, panel, webview, options) {
  if (!ThemeObserverClass) {
    ThemeObserverClass = new ObjCClass({
      utils: null,

      'observeValueForKeyPath:ofObject:change:context:': function (
        keyPath,
        object,
        change
      ) {
        const newAppearance = change[NSKeyValueChangeNewKey]
        const isDark =
          String(
            newAppearance.bestMatchFromAppearancesWithNames([
              'NSAppearanceNameAqua',
              'NSAppearanceNameDarkAqua',
            ])
          ) === 'NSAppearanceNameDarkAqua'

        this.utils.executeJavaScript(
          "document.body.classList.remove('__skpm-" +
            (isDark ? 'light' : 'dark') +
            "'); document.body.classList.add('__skpm-" +
            (isDark ? 'dark' : 'light') +
            "')"
        )
      },
    })
  }

  if (!WindowDelegateClass) {
    WindowDelegateClass = new ObjCClass({
      utils: null,
      panel: null,

      'windowDidResize:': function () {
        this.utils.emit('resize')
      },

      'windowDidMiniaturize:': function () {
        this.utils.emit('minimize')
      },

      'windowDidDeminiaturize:': function () {
        this.utils.emit('restore')
      },

      'windowDidEnterFullScreen:': function () {
        this.utils.emit('enter-full-screen')
      },

      'windowDidExitFullScreen:': function () {
        this.utils.emit('leave-full-screen')
      },

      'windowDidMove:': function () {
        this.utils.emit('move')
        this.utils.emit('moved')
      },

      'windowShouldClose:': function () {
        var shouldClose = 1
        this.utils.emit('close', {
          get defaultPrevented() {
            return !shouldClose
          },
          preventDefault: function () {
            shouldClose = 0
          },
        })
        return shouldClose
      },

      'windowWillClose:': function () {
        this.utils.emit('closed')
      },

      'windowDidBecomeKey:': function () {
        this.utils.emit('focus', this.panel.currentEvent())
      },

      'windowDidResignKey:': function () {
        this.utils.emit('blur')
      },
    })
  }

  if (!NavigationDelegateClass) {
    NavigationDelegateClass = new ObjCClass({
      state: {
        wasReady: 0,
      },
      utils: null,

      // // Called when the web view begins to receive web content.
      'webView:didCommitNavigation:': function (webView) {
        this.utils.emit('will-navigate', {}, String(String(webView.URL())))
      },

      // // Called when web content begins to load in a web view.
      'webView:didStartProvisionalNavigation:': function () {
        this.utils.emit('did-start-navigation')
        this.utils.emit('did-start-loading')
      },

      // Called when a web view receives a server redirect.
      'webView:didReceiveServerRedirectForProvisionalNavigation:': function () {
        this.utils.emit('did-get-redirect-request')
      },

      // // Called when the web view needs to respond to an authentication challenge.
      // 'webView:didReceiveAuthenticationChallenge:completionHandler:': function(
      //   webView,
      //   challenge,
      //   completionHandler
      // ) {
      //   function callback(username, password) {
      //     completionHandler(
      //       0,
      //       NSURLCredential.credentialWithUser_password_persistence(
      //         username,
      //         password,
      //         1
      //       )
      //     )
      //   }
      //   var protectionSpace = challenge.protectionSpace()
      //   this.utils.emit(
      //     'login',
      //     {},
      //     {
      //       method: String(protectionSpace.authenticationMethod()),
      //       url: 'not implemented', // TODO:
      //       referrer: 'not implemented', // TODO:
      //     },
      //     {
      //       isProxy: !!protectionSpace.isProxy(),
      //       scheme: String(protectionSpace.protocol()),
      //       host: String(protectionSpace.host()),
      //       port: Number(protectionSpace.port()),
      //       realm: String(protectionSpace.realm()),
      //     },
      //     callback
      //   )
      // },

      // Called when an error occurs during navigation.
      // 'webView:didFailNavigation:withError:': function(
      //   webView,
      //   navigation,
      //   error
      // ) {},

      // Called when an error occurs while the web view is loading content.
      'webView:didFailProvisionalNavigation:withError:': function (
        webView,
        navigation,
        error
      ) {
        this.utils.emit('did-fail-load', error)
      },

      // Called when the navigation is complete.
      'webView:didFinishNavigation:': function () {
        if (this.state.wasReady == 0) {
          this.state.wasReady = 1
          this.utils.emitBrowserEvent('ready-to-show')
        }
        this.utils.emit('did-navigate')
        this.utils.emit('did-frame-navigate')
        this.utils.emit('did-stop-loading')
        this.utils.emit('did-finish-load')
        this.utils.emit('did-frame-finish-load')
      },

      // Called when the web view’s web content process is terminated.
      'webViewWebContentProcessDidTerminate:': function () {
        this.utils.emit('dom-ready')
      },

      // Decides whether to allow or cancel a navigation.
      // webView:decidePolicyForNavigationAction:decisionHandler:

      // Decides whether to allow or cancel a navigation after its response is known.
      // webView:decidePolicyForNavigationResponse:decisionHandler:
    })
  }

  if (!WebScriptHandlerClass) {
    WebScriptHandlerClass = new ObjCClass({
      utils: null,
      'userContentController:didReceiveScriptMessage:': function (_, message) {
        var args = this.utils.parseWebArguments(String(message.body()))
        if (!args) {
          return
        }
        if (!args[0] || typeof args[0] !== 'string') {
          return
        }
        args[0] = String(args[0])

        this.utils.emit.apply(this, args)
      },
    })
  }

  var themeObserver = ThemeObserverClass.new({
    utils: {
      executeJavaScript(script) {
        webview.evaluateJavaScript_completionHandler(script, null)
      },
    },
  })

  var script = WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
    "document.addEventListener('DOMContentLoaded', function() { document.body.classList.add('__skpm-" +
      (typeof MSTheme !== 'undefined' && MSTheme.sharedTheme().isDark()
        ? 'dark'
        : 'light') +
      "') }, false)",
    0,
    true
  )
  webview.configuration().userContentController().addUserScript(script)

  NSApplication.sharedApplication().addObserver_forKeyPath_options_context(
    themeObserver,
    'effectiveAppearance',
    NSKeyValueObservingOptionNew,
    null
  )

  var threadDictionary = NSThread.mainThread().threadDictionary()
  threadDictionary[browserWindow.id + '.themeObserver'] = themeObserver

  var navigationDelegate = NavigationDelegateClass.new({
    utils: {
      setTitle: browserWindow.setTitle.bind(browserWindow),
      emitBrowserEvent() {
        try {
          browserWindow.emit.apply(browserWindow, arguments)
        } catch (err) {
          if (
            typeof process !== 'undefined' &&
            process.listenerCount &&
            process.listenerCount('uncaughtException')
          ) {
            process.emit('uncaughtException', err, 'uncaughtException')
          } else {
            console.error(err)
            throw err
          }
        }
      },
      emit() {
        try {
          browserWindow.webContents.emit.apply(
            browserWindow.webContents,
            arguments
          )
        } catch (err) {
          if (
            typeof process !== 'undefined' &&
            process.listenerCount &&
            process.listenerCount('uncaughtException')
          ) {
            process.emit('uncaughtException', err, 'uncaughtException')
          } else {
            console.error(err)
            throw err
          }
        }
      },
    },
    state: {
      wasReady: 0,
    },
  })

  webview.setNavigationDelegate(navigationDelegate)

  var webScriptHandler = WebScriptHandlerClass.new({
    utils: {
      emit(id, type) {
        if (!type) {
          webview.evaluateJavaScript_completionHandler(
            CONSTANTS.JS_BRIDGE_RESULT_SUCCESS + id + '()',
            null
          )
          return
        }

        var args = []
        for (var i = 2; i < arguments.length; i += 1) args.push(arguments[i])

        var listeners = browserWindow.webContents.listeners(type)

        Promise.all(
          listeners.map(function (l) {
            return Promise.resolve().then(function () {
              return l.apply(l, args)
            })
          })
        )
          .then(function (res) {
            webview.evaluateJavaScript_completionHandler(
              CONSTANTS.JS_BRIDGE_RESULT_SUCCESS +
                id +
                '(' +
                JSON.stringify(res) +
                ')',
              null
            )
          })
          .catch(function (err) {
            webview.evaluateJavaScript_completionHandler(
              CONSTANTS.JS_BRIDGE_RESULT_ERROR +
                id +
                '(' +
                JSON.stringify(err) +
                ')',
              null
            )
          })
      },
      parseWebArguments: parseWebArguments,
    },
  })

  webview
    .configuration()
    .userContentController()
    .addScriptMessageHandler_name(webScriptHandler, CONSTANTS.JS_BRIDGE)

  var utils = {
    emit() {
      try {
        browserWindow.emit.apply(browserWindow, arguments)
      } catch (err) {
        if (
          typeof process !== 'undefined' &&
          process.listenerCount &&
          process.listenerCount('uncaughtException')
        ) {
          process.emit('uncaughtException', err, 'uncaughtException')
        } else {
          console.error(err)
          throw err
        }
      }
    },
  }
  if (options.modal) {
    // find the window of the document
    var msdocument
    if (options.parent.type === 'Document') {
      msdocument = options.parent.sketchObject
    } else {
      msdocument = options.parent
    }
    if (msdocument && String(msdocument.class()) === 'MSDocumentData') {
      // we only have an MSDocumentData instead of a MSDocument
      // let's try to get back to the MSDocument
      msdocument = msdocument.delegate()
    }
    utils.parentWindow = msdocument.windowForSheet()
  }

  var windowDelegate = WindowDelegateClass.new({
    utils: utils,
    panel: panel,
  })

  panel.setDelegate(windowDelegate)
}

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@skpm/promise/index.js */ "./node_modules/@skpm/promise/index.js")))

/***/ }),

/***/ "./node_modules/sketch-module-web-view/lib/webview-api.js":
/*!****************************************************************!*\
  !*** ./node_modules/sketch-module-web-view/lib/webview-api.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var EventEmitter = __webpack_require__(/*! events */ "events")
var executeJavaScript = __webpack_require__(/*! ./execute-javascript */ "./node_modules/sketch-module-web-view/lib/execute-javascript.js")

// let's try to match https://github.com/electron/electron/blob/master/docs/api/web-contents.md
module.exports = function buildAPI(browserWindow, panel, webview) {
  var webContents = new EventEmitter()

  webContents.loadURL = browserWindow.loadURL

  webContents.loadFile = function (/* filePath */) {
    // TODO:
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }

  webContents.downloadURL = function (/* filePath */) {
    // TODO:
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }

  webContents.getURL = function () {
    return String(webview.URL())
  }

  webContents.getTitle = function () {
    return String(webview.title())
  }

  webContents.isDestroyed = function () {
    // TODO:
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }

  webContents.focus = browserWindow.focus
  webContents.isFocused = browserWindow.isFocused

  webContents.isLoading = function () {
    return !!webview.loading()
  }

  webContents.isLoadingMainFrame = function () {
    // TODO:
    return !!webview.loading()
  }

  webContents.isWaitingForResponse = function () {
    return !webview.loading()
  }

  webContents.stop = function () {
    webview.stopLoading()
  }
  webContents.reload = function () {
    webview.reload()
  }
  webContents.reloadIgnoringCache = function () {
    webview.reloadFromOrigin()
  }
  webContents.canGoBack = function () {
    return !!webview.canGoBack()
  }
  webContents.canGoForward = function () {
    return !!webview.canGoForward()
  }
  webContents.canGoToOffset = function (offset) {
    return !!webview.backForwardList().itemAtIndex(offset)
  }
  webContents.clearHistory = function () {
    // TODO:
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.goBack = function () {
    webview.goBack()
  }
  webContents.goForward = function () {
    webview.goForward()
  }
  webContents.goToIndex = function (index) {
    var backForwardList = webview.backForwardList()
    var backList = backForwardList.backList()
    var backListLength = backList.count()
    if (backListLength > index) {
      webview.loadRequest(NSURLRequest.requestWithURL(backList[index]))
      return
    }
    var forwardList = backForwardList.forwardList()
    if (forwardList.count() > index - backListLength) {
      webview.loadRequest(
        NSURLRequest.requestWithURL(forwardList[index - backListLength])
      )
      return
    }
    throw new Error('Cannot go to index ' + index)
  }
  webContents.goToOffset = function (offset) {
    if (!webContents.canGoToOffset(offset)) {
      throw new Error('Cannot go to offset ' + offset)
    }
    webview.loadRequest(
      NSURLRequest.requestWithURL(webview.backForwardList().itemAtIndex(offset))
    )
  }
  webContents.isCrashed = function () {
    // TODO:
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.setUserAgent = function (/* userAgent */) {
    // TODO:
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.getUserAgent = function () {
    const userAgent = webview.customUserAgent()
    return userAgent ? String(userAgent) : undefined
  }
  webContents.insertCSS = function (css) {
    var source =
      "var style = document.createElement('style'); style.innerHTML = " +
      css.replace(/"/, '\\"') +
      '; document.head.appendChild(style);'
    var script = WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
      source,
      0,
      true
    )
    webview.configuration().userContentController().addUserScript(script)
  }
  webContents.insertJS = function (source) {
    var script = WKUserScript.alloc().initWithSource_injectionTime_forMainFrameOnly(
      source,
      0,
      true
    )
    webview.configuration().userContentController().addUserScript(script)
  }
  webContents.executeJavaScript = executeJavaScript(webview, browserWindow)
  webContents.setIgnoreMenuShortcuts = function () {
    // TODO:??
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.setAudioMuted = function (/* muted */) {
    // TODO:??
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.isAudioMuted = function () {
    // TODO:??
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.setZoomFactor = function (factor) {
    webview.setMagnification_centeredAtPoint(factor, CGPointMake(0, 0))
  }
  webContents.getZoomFactor = function (callback) {
    callback(Number(webview.magnification()))
  }
  webContents.setZoomLevel = function (level) {
    // eslint-disable-next-line no-restricted-properties
    webContents.setZoomFactor(Math.pow(1.2, level))
  }
  webContents.getZoomLevel = function (callback) {
    // eslint-disable-next-line no-restricted-properties
    callback(Math.log(Number(webview.magnification())) / Math.log(1.2))
  }
  webContents.setVisualZoomLevelLimits = function (/* minimumLevel, maximumLevel */) {
    // TODO:??
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }
  webContents.setLayoutZoomLevelLimits = function (/* minimumLevel, maximumLevel */) {
    // TODO:??
    console.warn(
      'Not implemented yet, please open a PR on https://github.com/skpm/sketch-module-web-view :)'
    )
  }

  // TODO:
  // webContents.undo = function() {
  //   webview.undoManager().undo()
  // }
  // webContents.redo = function() {
  //   webview.undoManager().redo()
  // }
  // webContents.cut = webview.cut
  // webContents.copy = webview.copy
  // webContents.paste = webview.paste
  // webContents.pasteAndMatchStyle = webview.pasteAsRichText
  // webContents.delete = webview.delete
  // webContents.replace = webview.replaceSelectionWithText

  webContents.send = function () {
    const script =
      'window.postMessage({' +
      'isSketchMessage: true,' +
      "origin: '" +
      String(__command.identifier()) +
      "'," +
      'args: ' +
      JSON.stringify([].slice.call(arguments)) +
      '}, "*")'
    webview.evaluateJavaScript_completionHandler(script, null)
  }

  webContents.getNativeWebview = function () {
    return webview
  }

  browserWindow.webContents = webContents
}


/***/ }),

/***/ "./node_modules/sketch-module-web-view/remote.js":
/*!*******************************************************!*\
  !*** ./node_modules/sketch-module-web-view/remote.js ***!
  \*******************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* globals NSThread */
var threadDictionary = NSThread.mainThread().threadDictionary()

module.exports.getWebview = function (identifier) {
  return __webpack_require__(/*! ./lib */ "./node_modules/sketch-module-web-view/lib/index.js").fromId(identifier) // eslint-disable-line
}

module.exports.isWebviewPresent = function isWebviewPresent(identifier) {
  return !!threadDictionary[identifier]
}

module.exports.sendToWebview = function sendToWebview(identifier, evalString) {
  if (!module.exports.isWebviewPresent(identifier)) {
    return
  }

  var panel = threadDictionary[identifier]
  var webview = null
  var subviews = panel.contentView().subviews()
  for (var i = 0; i < subviews.length; i += 1) {
    if (
      !webview &&
      !subviews[i].isKindOfClass(WKInspectorWKWebView) &&
      subviews[i].isKindOfClass(WKWebView)
    ) {
      webview = subviews[i]
    }
  }

  if (!webview || !webview.evaluateJavaScript_completionHandler) {
    throw new Error('Webview ' + identifier + ' not found')
  }

  webview.evaluateJavaScript_completionHandler(evalString, null)
}


/***/ }),

/***/ "./resources/webview.html":
/*!********************************!*\
  !*** ./resources/webview.html ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "file://" + String(context.scriptPath).split(".sketchplugin/Contents/Sketch")[0] + ".sketchplugin/Contents/Resources/_webpack_resources/e339a41a98300ced01b811ebc09b4390.html";

/***/ }),

/***/ "./src/index.js":
/*!**********************!*\
  !*** ./src/index.js ***!
  \**********************/
/*! exports provided: toggleDarkTheme, toggleLightTheme, syncColors */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(Promise) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "toggleDarkTheme", function() { return toggleDarkTheme; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "toggleLightTheme", function() { return toggleLightTheme; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "syncColors", function() { return syncColors; });
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/asyncToGenerator.js");
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! sketch/dom */ "sketch/dom");
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(sketch_dom__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _util_theme_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./util/theme.js */ "./src/util/theme.js");
/* harmony import */ var sketch_module_web_view__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! sketch-module-web-view */ "./node_modules/sketch-module-web-view/lib/index.js");
/* harmony import */ var sketch_module_web_view__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(sketch_module_web_view__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var sketch_module_web_view_remote__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! sketch-module-web-view/remote */ "./node_modules/sketch-module-web-view/remote.js");
/* harmony import */ var sketch_module_web_view_remote__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(sketch_module_web_view_remote__WEBPACK_IMPORTED_MODULE_6__);




function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_1___default()(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

var sketch = __webpack_require__(/*! sketch */ "sketch");

var UI = __webpack_require__(/*! sketch/ui */ "sketch/ui");

var Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings");





var currentSketchDocument = sketch_dom__WEBPACK_IMPORTED_MODULE_3__["Document"].getSelectedDocument();
var colorsLibrary = sketch_dom__WEBPACK_IMPORTED_MODULE_3__["Library"].getLibraries().find(function (l) {
  return l.name.includes('12-Tokens-Colors');
});
var typographyLibrary = sketch_dom__WEBPACK_IMPORTED_MODULE_3__["Library"].getLibraries().find(function (l) {
  return l.name.includes('Typography');
});
var importableTextStyleReferences = typographyLibrary.getImportableTextStyleReferencesForDocument(currentSketchDocument);
var importableColorSymbolReferences = colorsLibrary.getImportableSymbolReferencesForDocument(currentSketchDocument);
var importableLayerStyleReferences = colorsLibrary.getImportableLayerStyleReferencesForDocument(currentSketchDocument);
var options = {
  width: 200,
  height: 200,
  minimizable: false,
  maximizable: false,
  resizable: true,
  fullscreenable: false,
  show: false
};
var syncWin = new sketch_module_web_view__WEBPACK_IMPORTED_MODULE_5___default.a(_objectSpread({
  title: 'Particle Colors Sync'
}, options));
var webContents = syncWin.webContents;
function toggleDarkTheme() {
  var selection = currentSketchDocument.selectedLayers.layers;

  try {
    // Is something selected?
    if (selection.length > 0) {
      Object(_util_theme_js__WEBPACK_IMPORTED_MODULE_4__["importAllReferences"])(importableColorSymbolReferences).then(function () {
        Object(_util_theme_js__WEBPACK_IMPORTED_MODULE_4__["importAllReferences"])(importableTextStyleReferences);
      }).then(function () {
        Object(_util_theme_js__WEBPACK_IMPORTED_MODULE_4__["importAllReferences"])(importableLayerStyleReferences);
      }).then(function () {
        selection.forEach(function (s, index) {
          Object(_util_theme_js__WEBPACK_IMPORTED_MODULE_4__["toggleTheme"])(s, 'dark').then(function () {
            if (index === selection.length - 1) {
              UI.message("Successfully toggled to dark theme!");
            }
          }).catch(function (error) {
            return console.log(error);
          });
        });
      }).catch(function (error) {
        console.log(error);
      });
    } else {
      UI.alert("No selection", "No layer selected! Please select a layer and try again.");
    }
  } catch (error) {
    UI.message(error);
  }
}
function toggleLightTheme() {
  var document = sketch_dom__WEBPACK_IMPORTED_MODULE_3__["Document"].getSelectedDocument();
  var selection = document.selectedLayers.layers;

  try {
    if (Settings.settingForKey('colors') !== null || !Settings.settingForKey('colors')) showSyncColorsWindow('fetch'); // Is something selected?

    if (selection.length > 0) {
      setTimeout(function () {
        // Is it a symbol instance or group (detached symbol instance)
        selection.forEach(function (s) {
          Object(_util_theme_js__WEBPACK_IMPORTED_MODULE_4__["toggleTheme"])(s, 'light');
        });
        UI.message("Successfully toggled to light theme!");
      }, 1000);
    } else {
      UI.alert("No selection", "No layer selected! Please select a layer and try again.");
    }
  } catch (error) {
    UI.message(error);
  }
}
function syncColors() {
  var document = sketch_dom__WEBPACK_IMPORTED_MODULE_3__["Document"].getSelectedDocument();

  try {
    // Must be in Colors Particle Lib
    if (document.path.includes('Colors')) {
      showSyncColorsWindow('sync');
    } else {
      UI.alert("Incorrect file", "Must run this command from Particle-Colors library!");
    }
  } catch (error) {
    UI.message(error);
  }
}

function showSyncColorsWindow(_x) {
  return _showSyncColorsWindow.apply(this, arguments);
}

function _showSyncColorsWindow() {
  _showSyncColorsWindow = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default.a.mark(function _callee(action) {
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_2___default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            return _context.abrupt("return", new Promise(function (res, rej) {
              Settings.setSessionVariable('colors', null);

              switch (action) {
                case 'sync':
                  sync();

                case 'fetch':
                  fetch();

                default:
                  fetch();
              }

              webContents.on('close', function () {
                syncWin.close();
              });
              syncWin.loadURL(__webpack_require__(/*! ../resources/webview.html */ "./resources/webview.html"));

              function sync() {
                webContents.executeJavaScript("syncColors()");
                webContents.on('processColors', function (_ref) {
                  var colors = _ref.colors;
                  Object(_util_theme_js__WEBPACK_IMPORTED_MODULE_4__["processColors"])(colors).then(function () {
                    res();
                  });
                });
              }

              function fetch() {
                webContents.executeJavaScript("fetchColors()");
                webContents.on('setColors', function (_ref2) {
                  var colors = _ref2.colors;
                  Settings.setSessionVariable('colors', colors);
                  res();
                });
              }
            }));

          case 1:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));
  return _showSyncColorsWindow.apply(this, arguments);
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@skpm/promise/index.js */ "./node_modules/@skpm/promise/index.js")))

/***/ }),

/***/ "./src/util/theme.js":
/*!***************************!*\
  !*** ./src/util/theme.js ***!
  \***************************/
/*! exports provided: toggleTheme, importAllReferences, getFlattenedGroupLayers, processColors */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(Promise) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "toggleTheme", function() { return toggleTheme; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "importAllReferences", function() { return importAllReferences; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getFlattenedGroupLayers", function() { return getFlattenedGroupLayers; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "processColors", function() { return processColors; });
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/asyncToGenerator.js");
/* harmony import */ var _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! sketch/dom */ "sketch/dom");
/* harmony import */ var sketch_dom__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(sketch_dom__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _appd_ui_assets__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @appd/ui-assets */ "./node_modules/@appd/ui-assets/fesm5/appd-ui-assets.js");



var Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings");



var currentSketchDocument = sketch_dom__WEBPACK_IMPORTED_MODULE_2__["Document"].getSelectedDocument();
var fetchedGlobalColors = Settings.sessionVariable('colors');
var colorsLibrary = sketch_dom__WEBPACK_IMPORTED_MODULE_2__["Library"].getLibraries().find(function (l) {
  return l.name.includes('12-Tokens-Colors');
});
var typographyLibrary = sketch_dom__WEBPACK_IMPORTED_MODULE_2__["Library"].getLibraries().find(function (l) {
  return l.name.includes('Typography');
});
var importableTextStyleReferences = typographyLibrary.getImportableTextStyleReferencesForDocument(currentSketchDocument);
var importableColorSymbolReferences = colorsLibrary.getImportableSymbolReferencesForDocument(currentSketchDocument);
var importableLayerStyleReferences = colorsLibrary.getImportableLayerStyleReferencesForDocument(currentSketchDocument);
function toggleTheme(_x, _x2) {
  return _toggleTheme.apply(this, arguments);
}

function _toggleTheme() {
  _toggleTheme = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.mark(function _callee(selection, type) {
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            return _context.abrupt("return", new Promise(function (res, rej) {
              // const fetchedDarkColors = fetchedGlobalColors.filter(c => c.predefinedTheme === 'Dark');
              // const fetchedLightColors = fetchedGlobalColors.filter(c => c.predefinedTheme === 'Light');
              var importedColorSymbols = currentSketchDocument.getSymbols().filter(function (s) {
                return s.name.includes('product/');
              });
              getFlattenedGroupLayers(selection).forEach(function (l, index) {
                if (l.type === 'SymbolInstance') {
                  if (l.overrides.length > 0) {
                    var colorOverrides = l.overrides.filter(function (o) {
                      return o.property === 'symbolID' && o.affectedLayer.name.includes('color');
                    });
                    var textOverrides = l.overrides.filter(function (o) {
                      return o.property === 'textStyle';
                    });
                    var layerOverrides = l.overrides.filter(function (o) {
                      return o.property === 'layerStyle';
                    });
                    layerOverrides.forEach(function (o) {
                      if (isCharting(o)) {
                        var currentName = getCurrentLayerOverrideName(currentSketchDocument.sharedLayerStyles, o.value).split('/')[1];
                        var newLayerStyleReference = currentSketchDocument.sharedLayerStyles.find(function (io) {
                          return io.name.includes(type === 'dark' ? 'dark' : 'light') && io.name.split('/')[1] === currentName;
                        });
                        if (newLayerStyleReference && newLayerStyleReference !== undefined) o.value = newLayerStyleReference.id;
                      }
                    });
                    colorOverrides.forEach(function (o) {
                      var fetchedColorObject = _appd_ui_assets__WEBPACK_IMPORTED_MODULE_3__["LevitateDarkThemeMapping"].find(function (fc) {
                        return fc.name.includes(o.affectedLayer.name);
                      });
                      var currentColorName = getCurrentOverrideColorName(importedColorSymbols, o.value);
                      console.log('affectedLayer', o.affectedLayer.name);
                      console.log('fetchedColorObject', fetchedColorObject); // handle icons

                      // handle icons
                      if (o.affectedLayer.name === 'icon-fill-color') {
                        var newIconColorReference = importedColorSymbols.find(function (io) {
                          return io.name.includes('highlight-high-icon') && io.name.includes(type === 'dark' ? 'dark' : 'light');
                        });
                        if (newIconColorReference) o.value = newIconColorReference.symbolId;
                      } // handle status icons


                      // handle status icons
                      if (o.affectedLayer.name.includes('status-')) {
                        var _newIconColorReference = {};

                        switch (o.affectedLayer.name) {
                          case 'status-critical-color':
                            _newIconColorReference = importedColorSymbols.find(function (io) {
                              return io.name.includes('status-critical-300') && io.name.includes(type === 'dark' ? 'dark' : 'light');
                            });
                            break;

                          case 'status-normal-color':
                            _newIconColorReference = importedColorSymbols.find(function (io) {
                              return io.name.includes('status-normal-300') && io.name.includes(type === 'dark' ? 'dark' : 'light');
                            });
                            break;

                          case 'status-warning-color':
                            _newIconColorReference = importedColorSymbols.find(function (io) {
                              return io.name.includes('status-warning-300') && io.name.includes(type === 'dark' ? 'dark' : 'light');
                            });
                            break;

                          case 'status-unknown-color':
                            _newIconColorReference = importedColorSymbols.find(function (io) {
                              return io.name.includes('highlight-low') && io.name.includes(type === 'dark' ? 'dark' : 'light');
                            });
                            break;

                          case 'status-critical-outline-color':
                            _newIconColorReference = importedColorSymbols.find(function (io) {
                              return io.name.includes('status-critical-200') && io.name.includes(type === 'dark' ? 'dark' : 'light');
                            });
                            break;

                          case 'status-normal-outline-color':
                            _newIconColorReference = importedColorSymbols.find(function (io) {
                              return io.name.includes('status-normal-200') && io.name.includes(type === 'dark' ? 'dark' : 'light');
                            });
                            break;

                          case 'status-warning-outline-color':
                            _newIconColorReference = importedColorSymbols.find(function (io) {
                              return io.name.includes('status-warning-200') && io.name.includes(type === 'dark' ? 'dark' : 'light');
                            });
                            break;

                          case 'status-info-outline-color':
                            _newIconColorReference = importedColorSymbols.find(function (io) {
                              return io.name.includes('status-info-200') && io.name.includes(type === 'dark' ? 'dark' : 'light');
                            });
                            break;

                          default:
                            _newIconColorReference = importedColorSymbols.find(function (io) {
                              return io.name.includes('status-info-300') && io.name.includes(type === 'dark' ? 'dark' : 'light');
                            });
                        }

                        if (_newIconColorReference) {
                          o.value = _newIconColorReference.symbolId;
                        }
                      } // handle charting color symbols


                      // handle charting color symbols
                      if (currentColorName && currentColorName.includes('chart-')) {
                        var chartColorName = currentColorName.split('/')[2];
                        var newChartingColorReference = importedColorSymbols.find(function (io) {
                          return io.name.split('/')[2] === chartColorName && io.name.includes(type === 'dark' ? 'dark' : 'light');
                        });
                        if (newChartingColorReference) o.value = newChartingColorReference.symbolId;
                      }

                      if (fetchedColorObject && o.affectedLayer.name !== 'icon-fill-color') {
                        var newColorName = getParticleName(fetchedColorObject.value);
                        console.log('newColorName', newColorName);
                        var newColorReference = importedColorSymbols.find(function (io) {
                          return io.name.includes(newColorName) && io.name.includes('dark');
                        });
                        console.log('newColorReference', newColorReference);
                        if (newColorReference) o.value = newColorReference.symbolId;
                      }

                      console.log('------------');
                    });
                    textOverrides.forEach(function (o) {
                      var localReference = currentSketchDocument.sharedTextStyles.find(function (io) {
                        return io.id === o.affectedLayer.sharedStyleId;
                      });
                      var currentName = localReference.name.substr(type === 'light' ? 5 : 6, localReference.name.length);
                      var newTextStyleReference = currentSketchDocument.sharedTextStyles.find(function (io) {
                        return io.name.includes(type === 'dark' ? 'dark' : 'light') && io.name.includes(currentName);
                      });
                      if (newTextStyleReference && newTextStyleReference !== undefined) o.value = newTextStyleReference.id;
                    });
                  }
                } // Set unlinked typography


                // Set unlinked typography
                if (l.type === 'Text') {
                  var textColor = type === 'dark' ? '#FFF' : '#19212B';
                  l.style.textColor = textColor;
                }

                if (index === getFlattenedGroupLayers(selection).length - 1) res();
              });
            }));

          case 1:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));
  return _toggleTheme.apply(this, arguments);
}

function isCharting(override) {
  var charting = false;
  var allowedVisualizations = ['gradient', 'spark', 'line-chart', 'line', 'area-chart', 'bar-chart', 'column-chart', 'bubble-chart', 'historgram', 'scatter-chart', 'health-bar', 'score-bar', 'pie-chart', 'health-pie-and-donut'];
  allowedVisualizations.forEach(function (v) {
    if (override.affectedLayer.name.includes(v)) {
      charting = true;
    }
  });
  return charting;
}

function importAllReferences(_x3) {
  return _importAllReferences.apply(this, arguments);
}

function _importAllReferences() {
  _importAllReferences = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.mark(function _callee2(references) {
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.wrap(function _callee2$(_context2) {
      while (1) {
        switch (_context2.prev = _context2.next) {
          case 0:
            return _context2.abrupt("return", new Promise(function (res, rej) {
              references.forEach(function (r, index) {
                r.import();
                if (index === references.length - 1) res();
              });
            }));

          case 1:
          case "end":
            return _context2.stop();
        }
      }
    }, _callee2);
  }));
  return _importAllReferences.apply(this, arguments);
}

function findFetchedComponentColors(fetchedColors, componentName) {
  return fetchedColors.filter(function (color) {
    return color.name.includes(componentName);
  }) || null;
}

function getFlattenedGroupLayers(group) {
  var layers = [];

  if (group.type === 'SymbolInstance' || group.type === 'Text') {
    layers.push(group);
  } else {
    getLayers(group);
  }

  function getLayers(g) {
    g.layers.forEach(function (l) {
      if (l.type === 'Group') getLayers(l);else layers.push(l);
    });
  }

  return layers.flat(Infinity);
}
function processColors(_x4) {
  return _processColors.apply(this, arguments);
}

function _processColors() {
  _processColors = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.mark(function _callee3(fetchedColors) {
    var swatches, colorSymbols, fetchedDarkColors;
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.wrap(function _callee3$(_context3) {
      while (1) {
        switch (_context3.prev = _context3.next) {
          case 0:
            swatches = currentSketchDocument.swatches;
            colorSymbols = currentSketchDocument.pages.find(function (p) {
              return p.name === 'Symbols';
            }).layers;
            fetchedDarkColors = fetchedColors.filter(function (c) {
              return c.predefinedTheme === 'Dark';
            }); // process all dark

            fetchedDarkColors.forEach(function (fc) {
              var particleName = getParticleName(fc.name);
              var swatch = swatches.find(function (s) {
                return s.name.includes(particleName);
              }) || null;
              var colorSymbol = colorSymbols.find(function (cs) {
                return cs.name.includes(particleName);
              }) || null;

              if (swatch) {
                updateSwatchColor(swatch, fc.value, colorSymbol);
              } else {
                createNewSwatch("product/dark/".concat(particleName), fc.value, colorSymbols[0]);
              }
            });
            _context3.next = 6;
            return updateColorSymbolSwatchReferences();

          case 6:
          case "end":
            return _context3.stop();
        }
      }
    }, _callee3);
  }));
  return _processColors.apply(this, arguments);
}

function getCurrentOverrideColorName(importedColorSymbols, overrideValue) {
  return importedColorSymbols.find(function (s) {
    return s.symbolId === overrideValue;
  }) ? importedColorSymbols.find(function (s) {
    return s.symbolId === overrideValue;
  }).name : null;
}

function getCurrentLayerOverrideName(importedLayerStyles, overrideValue) {
  return importedLayerStyles.find(function (s) {
    return s.id === overrideValue;
  }) ? importedLayerStyles.find(function (s) {
    return s.id === overrideValue;
  }).name : null;
}

function getParticleName(colorName) {
  var split = colorName.replace('#', '').replace('$', '').replace('{', '').replace('}', '').split('-');
  var name = split.filter(function (n, index) {
    return index > 1;
  }).join('-');
  return colorName.includes('transparent') ? 'transparent' : name;
}

function createNewSwatch(colorName, newColor, baseSymbol) {
  try {
    if (newColor.includes('#')) {
      var newSwatch = sketch_dom__WEBPACK_IMPORTED_MODULE_2__["Swatch"].from({
        name: colorName,
        color: newColor
      });
      currentSketchDocument.swatches.push(newSwatch);
      createColorSymbol(baseSymbol, colorName, newSwatch.referencingColor);
    }

    if (newColor.includes('rgb')) {
      var hexObj = RGBAToHexA(newColor);

      var _newSwatch = sketch_dom__WEBPACK_IMPORTED_MODULE_2__["Swatch"].from({
        name: colorName,
        color: "".concat(hexObj.hex).concat(hexObj.a)
      });

      currentSketchDocument.swatches.push(_newSwatch);
    }
  } catch (e) {
    console.log(e);
  }
}

function createColorSymbol(baseColorSymbol, colorName, referencingColor) {
  var newColorSymbol = baseColorSymbol.duplicate();
  newColorSymbol.name = colorName;

  try {
    newColorSymbol.layers[0].style.fills[0].color = referencingColor;
  } catch (e) {
    console.log(e);
  }
}

function updateSwatchColor(swatch, newColor, colorSymbol) {
  try {
    if (newColor.includes('#')) swatch.sketchObject.updateWithColor(MSColor.colorWithHex_alpha(newColor.toString(), '1'));

    if (newColor.includes('rgb')) {
      var hexObj = RGBAToHexA(newColor);
      swatch.sketchObject.updateWithColor(MSColor.colorWithHex_alpha(hexObj.hex.toString(), hexObj.a.toString()));
    }

    if (colorSymbol === null) {
      createColorSymbol(currentSketchDocument.pages.find(function (p) {
        return p.name === 'Symbols';
      }).layers[0], swatch.name, swatch.referencingColor);
    }
  } catch (e) {
    console.log(e);
  }
}

function updateColorSymbol(colorSymbol, newColor) {
  try {
    if (newColor.includes('#')) {
      colorSymbol.layers[0].style.fills[0].color = newColor;
    }

    if (newColor.includes('rgb')) {
      var hexObj = RGBAToHexA(newColor);
      colorSymbol.layers[0].style.fills[0].color = "".concat(hexObj.hex).concat(hexObj.a);
    }
  } catch (e) {
    console.log(e);
  }
}

function updateColorSymbolSwatchReferences() {
  return _updateColorSymbolSwatchReferences.apply(this, arguments);
}

function _updateColorSymbolSwatchReferences() {
  _updateColorSymbolSwatchReferences = _babel_runtime_helpers_asyncToGenerator__WEBPACK_IMPORTED_MODULE_0___default()( /*#__PURE__*/_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.mark(function _callee4() {
    return _babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_1___default.a.wrap(function _callee4$(_context4) {
      while (1) {
        switch (_context4.prev = _context4.next) {
          case 0:
            return _context4.abrupt("return", new Promise(function (res, rej) {
              currentSketchDocument.swatches.forEach(function (s, index) {
                currentSketchDocument.sketchObject.documentData().sharedSwatches().updateReferencesToSwatch(s.sketchObject);
                if (currentSketchDocument.swatches.length - 1 === index) res();
              });
            }));

          case 1:
          case "end":
            return _context4.stop();
        }
      }
    }, _callee4);
  }));
  return _updateColorSymbolSwatchReferences.apply(this, arguments);
}

function RGBAToHexA(rgba) {
  var sep = rgba.indexOf(",") > -1 ? "," : " ";
  rgba = rgba.substr(5).split(")")[0].split(sep); // Strip the slash if using space-separated syntax

  if (rgba.indexOf("/") > -1) rgba.splice(3, 1);

  for (var R in rgba) {
    var _r = rgba[R];

    if (_r.indexOf("%") > -1) {
      var p = _r.substr(0, _r.length - 1) / 100;

      if (R < 3) {
        rgba[R] = Math.round(p * 255);
      } else {
        rgba[R] = p;
      }
    }
  }

  var r = (+rgba[0]).toString(16),
      g = (+rgba[1]).toString(16),
      b = (+rgba[2]).toString(16),
      a = rgba[3];
  if (r.length == 1) r = "0" + r;
  if (g.length == 1) g = "0" + g;
  if (b.length == 1) b = "0" + b;
  if (a.length == 1) a = "0" + a;
  return {
    hex: "#" + r + g + b,
    a: a
  };
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@skpm/promise/index.js */ "./node_modules/@skpm/promise/index.js")))

/***/ }),

/***/ "events":
/*!*************************!*\
  !*** external "events" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("events");

/***/ }),

/***/ "sketch":
/*!*************************!*\
  !*** external "sketch" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch");

/***/ }),

/***/ "sketch/dom":
/*!*****************************!*\
  !*** external "sketch/dom" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/dom");

/***/ }),

/***/ "sketch/settings":
/*!**********************************!*\
  !*** external "sketch/settings" ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/settings");

/***/ }),

/***/ "sketch/ui":
/*!****************************!*\
  !*** external "sketch/ui" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/ui");

/***/ })

/******/ });
    if (key === 'default' && typeof exports === 'function') {
      exports(context);
    } else if (typeof exports[key] !== 'function') {
      throw new Error('Missing export named "' + key + '". Your command should contain something like `export function " + key +"() {}`.');
    } else {
      exports[key](context);
    }
  } catch (err) {
    if (typeof process !== 'undefined' && process.listenerCount && process.listenerCount('uncaughtException')) {
      process.emit("uncaughtException", err, "uncaughtException");
    } else {
      throw err
    }
  }
}
globalThis['toggleDarkTheme'] = __skpm_run.bind(this, 'toggleDarkTheme');
globalThis['onRun'] = __skpm_run.bind(this, 'default');
globalThis['syncColors'] = __skpm_run.bind(this, 'syncColors')

//# sourceMappingURL=index.js.map