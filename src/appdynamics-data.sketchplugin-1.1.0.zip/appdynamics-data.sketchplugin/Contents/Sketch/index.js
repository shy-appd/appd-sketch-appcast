var that = this;
function __skpm_run (key, context) {
  that.context = context;

var exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/index.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./node_modules/@babel/runtime/helpers/arrayWithoutHoles.js":
/*!******************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/arrayWithoutHoles.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _arrayWithoutHoles(arr) {
  if (Array.isArray(arr)) {
    for (var i = 0, arr2 = new Array(arr.length); i < arr.length; i++) {
      arr2[i] = arr[i];
    }

    return arr2;
  }
}

module.exports = _arrayWithoutHoles;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/iterableToArray.js":
/*!****************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/iterableToArray.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _iterableToArray(iter) {
  if (Symbol.iterator in Object(iter) || Object.prototype.toString.call(iter) === "[object Arguments]") return Array.from(iter);
}

module.exports = _iterableToArray;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/nonIterableSpread.js":
/*!******************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/nonIterableSpread.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance");
}

module.exports = _nonIterableSpread;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/toConsumableArray.js":
/*!******************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/toConsumableArray.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var arrayWithoutHoles = __webpack_require__(/*! ./arrayWithoutHoles */ "./node_modules/@babel/runtime/helpers/arrayWithoutHoles.js");

var iterableToArray = __webpack_require__(/*! ./iterableToArray */ "./node_modules/@babel/runtime/helpers/iterableToArray.js");

var nonIterableSpread = __webpack_require__(/*! ./nonIterableSpread */ "./node_modules/@babel/runtime/helpers/nonIterableSpread.js");

function _toConsumableArray(arr) {
  return arrayWithoutHoles(arr) || iterableToArray(arr) || nonIterableSpread();
}

module.exports = _toConsumableArray;

/***/ }),

/***/ "./node_modules/@babel/runtime/regenerator/index.js":
/*!**********************************************************!*\
  !*** ./node_modules/@babel/runtime/regenerator/index.js ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! regenerator-runtime */ "./node_modules/regenerator-runtime/runtime.js");


/***/ }),

/***/ "./node_modules/@skpm/timers/immediate.js":
/*!************************************************!*\
  !*** ./node_modules/@skpm/timers/immediate.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* globals coscript, sketch */
var timeout = __webpack_require__(/*! ./timeout */ "./node_modules/@skpm/timers/timeout.js")

function setImmediate(func, param1, param2, param3, param4, param5, param6, param7, param8, param9, param10) {
  return timeout.setTimeout(func, 0, param1, param2, param3, param4, param5, param6, param7, param8, param9, param10)
}

function clearImmediate(id) {
  return timeout.clearTimeout(id)
}

module.exports = {
  setImmediate: setImmediate,
  clearImmediate: clearImmediate
}


/***/ }),

/***/ "./node_modules/@skpm/timers/test-if-fiber.js":
/*!****************************************************!*\
  !*** ./node_modules/@skpm/timers/test-if-fiber.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = function () {
  return typeof coscript !== 'undefined' && coscript.createFiber
}


/***/ }),

/***/ "./node_modules/@skpm/timers/timeout.js":
/*!**********************************************!*\
  !*** ./node_modules/@skpm/timers/timeout.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* globals coscript, sketch */
var fiberAvailable = __webpack_require__(/*! ./test-if-fiber */ "./node_modules/@skpm/timers/test-if-fiber.js")

var setTimeout
var clearTimeout

var fibers = []

if (fiberAvailable()) {
  var fibers = []

  setTimeout = function (func, delay, param1, param2, param3, param4, param5, param6, param7, param8, param9, param10) {
    // fibers takes care of keeping coscript around
    var id = fibers.length
    fibers.push(coscript.scheduleWithInterval_jsFunction(
      (delay || 0) / 1000,
      function () {
        func(param1, param2, param3, param4, param5, param6, param7, param8, param9, param10)
      }
    ))
    return id
  }

  clearTimeout = function (id) {
    var timeout = fibers[id]
    if (timeout) {
      timeout.cancel() // fibers takes care of keeping coscript around
      fibers[id] = undefined // garbage collect the fiber
    }
  }
} else {
  setTimeout = function (func, delay, param1, param2, param3, param4, param5, param6, param7, param8, param9, param10) {
    coscript.shouldKeepAround = true
    var id = fibers.length
    fibers.push(true)
    coscript.scheduleWithInterval_jsFunction(
      (delay || 0) / 1000,
      function () {
        if (fibers[id]) { // if not cleared
          func(param1, param2, param3, param4, param5, param6, param7, param8, param9, param10)
        }
        clearTimeout(id)
        if (fibers.every(function (_id) { return !_id })) { // if everything is cleared
          coscript.shouldKeepAround = false
        }
      }
    )
    return id
  }

  clearTimeout = function (id) {
    fibers[id] = false
  }
}

module.exports = {
  setTimeout: setTimeout,
  clearTimeout: clearTimeout
}


/***/ }),

/***/ "./node_modules/promise-polyfill/lib/index.js":
/*!****************************************************!*\
  !*** ./node_modules/promise-polyfill/lib/index.js ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(setTimeout, setImmediate) {

/**
 * @this {Promise}
 */
function finallyConstructor(callback) {
  var constructor = this.constructor;
  return this.then(
    function(value) {
      // @ts-ignore
      return constructor.resolve(callback()).then(function() {
        return value;
      });
    },
    function(reason) {
      // @ts-ignore
      return constructor.resolve(callback()).then(function() {
        // @ts-ignore
        return constructor.reject(reason);
      });
    }
  );
}

// Store setTimeout reference so promise-polyfill will be unaffected by
// other code modifying setTimeout (like sinon.useFakeTimers())
var setTimeoutFunc = setTimeout;

function isArray(x) {
  return Boolean(x && typeof x.length !== 'undefined');
}

function noop() {}

// Polyfill for Function.prototype.bind
function bind(fn, thisArg) {
  return function() {
    fn.apply(thisArg, arguments);
  };
}

/**
 * @constructor
 * @param {Function} fn
 */
function Promise(fn) {
  if (!(this instanceof Promise))
    throw new TypeError('Promises must be constructed via new');
  if (typeof fn !== 'function') throw new TypeError('not a function');
  /** @type {!number} */
  this._state = 0;
  /** @type {!boolean} */
  this._handled = false;
  /** @type {Promise|undefined} */
  this._value = undefined;
  /** @type {!Array<!Function>} */
  this._deferreds = [];

  doResolve(fn, this);
}

function handle(self, deferred) {
  while (self._state === 3) {
    self = self._value;
  }
  if (self._state === 0) {
    self._deferreds.push(deferred);
    return;
  }
  self._handled = true;
  Promise._immediateFn(function() {
    var cb = self._state === 1 ? deferred.onFulfilled : deferred.onRejected;
    if (cb === null) {
      (self._state === 1 ? resolve : reject)(deferred.promise, self._value);
      return;
    }
    var ret;
    try {
      ret = cb(self._value);
    } catch (e) {
      reject(deferred.promise, e);
      return;
    }
    resolve(deferred.promise, ret);
  });
}

function resolve(self, newValue) {
  try {
    // Promise Resolution Procedure: https://github.com/promises-aplus/promises-spec#the-promise-resolution-procedure
    if (newValue === self)
      throw new TypeError('A promise cannot be resolved with itself.');
    if (
      newValue &&
      (typeof newValue === 'object' || typeof newValue === 'function')
    ) {
      var then = newValue.then;
      if (newValue instanceof Promise) {
        self._state = 3;
        self._value = newValue;
        finale(self);
        return;
      } else if (typeof then === 'function') {
        doResolve(bind(then, newValue), self);
        return;
      }
    }
    self._state = 1;
    self._value = newValue;
    finale(self);
  } catch (e) {
    reject(self, e);
  }
}

function reject(self, newValue) {
  self._state = 2;
  self._value = newValue;
  finale(self);
}

function finale(self) {
  if (self._state === 2 && self._deferreds.length === 0) {
    Promise._immediateFn(function() {
      if (!self._handled) {
        Promise._unhandledRejectionFn(self._value);
      }
    });
  }

  for (var i = 0, len = self._deferreds.length; i < len; i++) {
    handle(self, self._deferreds[i]);
  }
  self._deferreds = null;
}

/**
 * @constructor
 */
function Handler(onFulfilled, onRejected, promise) {
  this.onFulfilled = typeof onFulfilled === 'function' ? onFulfilled : null;
  this.onRejected = typeof onRejected === 'function' ? onRejected : null;
  this.promise = promise;
}

/**
 * Take a potentially misbehaving resolver function and make sure
 * onFulfilled and onRejected are only called once.
 *
 * Makes no guarantees about asynchrony.
 */
function doResolve(fn, self) {
  var done = false;
  try {
    fn(
      function(value) {
        if (done) return;
        done = true;
        resolve(self, value);
      },
      function(reason) {
        if (done) return;
        done = true;
        reject(self, reason);
      }
    );
  } catch (ex) {
    if (done) return;
    done = true;
    reject(self, ex);
  }
}

Promise.prototype['catch'] = function(onRejected) {
  return this.then(null, onRejected);
};

Promise.prototype.then = function(onFulfilled, onRejected) {
  // @ts-ignore
  var prom = new this.constructor(noop);

  handle(this, new Handler(onFulfilled, onRejected, prom));
  return prom;
};

Promise.prototype['finally'] = finallyConstructor;

Promise.all = function(arr) {
  return new Promise(function(resolve, reject) {
    if (!isArray(arr)) {
      return reject(new TypeError('Promise.all accepts an array'));
    }

    var args = Array.prototype.slice.call(arr);
    if (args.length === 0) return resolve([]);
    var remaining = args.length;

    function res(i, val) {
      try {
        if (val && (typeof val === 'object' || typeof val === 'function')) {
          var then = val.then;
          if (typeof then === 'function') {
            then.call(
              val,
              function(val) {
                res(i, val);
              },
              reject
            );
            return;
          }
        }
        args[i] = val;
        if (--remaining === 0) {
          resolve(args);
        }
      } catch (ex) {
        reject(ex);
      }
    }

    for (var i = 0; i < args.length; i++) {
      res(i, args[i]);
    }
  });
};

Promise.resolve = function(value) {
  if (value && typeof value === 'object' && value.constructor === Promise) {
    return value;
  }

  return new Promise(function(resolve) {
    resolve(value);
  });
};

Promise.reject = function(value) {
  return new Promise(function(resolve, reject) {
    reject(value);
  });
};

Promise.race = function(arr) {
  return new Promise(function(resolve, reject) {
    if (!isArray(arr)) {
      return reject(new TypeError('Promise.race accepts an array'));
    }

    for (var i = 0, len = arr.length; i < len; i++) {
      Promise.resolve(arr[i]).then(resolve, reject);
    }
  });
};

// Use polyfill for setImmediate for performance gains
Promise._immediateFn =
  // @ts-ignore
  (typeof setImmediate === 'function' &&
    function(fn) {
      // @ts-ignore
      setImmediate(fn);
    }) ||
  function(fn) {
    setTimeoutFunc(fn, 0);
  };

Promise._unhandledRejectionFn = function _unhandledRejectionFn(err) {
  if (typeof console !== 'undefined' && console) {
    console.warn('Possible Unhandled Promise Rejection:', err); // eslint-disable-line no-console
  }
};

module.exports = Promise;

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/@skpm/timers/timeout.js */ "./node_modules/@skpm/timers/timeout.js")["setTimeout"], __webpack_require__(/*! ./node_modules/@skpm/timers/immediate.js */ "./node_modules/@skpm/timers/immediate.js")["setImmediate"]))

/***/ }),

/***/ "./node_modules/regenerator-runtime/runtime.js":
/*!*****************************************************!*\
  !*** ./node_modules/regenerator-runtime/runtime.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(Promise) {/**
 * Copyright (c) 2014-present, Facebook, Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */

var runtime = (function (exports) {
  "use strict";

  var Op = Object.prototype;
  var hasOwn = Op.hasOwnProperty;
  var undefined; // More compressible than void 0.
  var $Symbol = typeof Symbol === "function" ? Symbol : {};
  var iteratorSymbol = $Symbol.iterator || "@@iterator";
  var asyncIteratorSymbol = $Symbol.asyncIterator || "@@asyncIterator";
  var toStringTagSymbol = $Symbol.toStringTag || "@@toStringTag";

  function wrap(innerFn, outerFn, self, tryLocsList) {
    // If outerFn provided and outerFn.prototype is a Generator, then outerFn.prototype instanceof Generator.
    var protoGenerator = outerFn && outerFn.prototype instanceof Generator ? outerFn : Generator;
    var generator = Object.create(protoGenerator.prototype);
    var context = new Context(tryLocsList || []);

    // The ._invoke method unifies the implementations of the .next,
    // .throw, and .return methods.
    generator._invoke = makeInvokeMethod(innerFn, self, context);

    return generator;
  }
  exports.wrap = wrap;

  // Try/catch helper to minimize deoptimizations. Returns a completion
  // record like context.tryEntries[i].completion. This interface could
  // have been (and was previously) designed to take a closure to be
  // invoked without arguments, but in all the cases we care about we
  // already have an existing method we want to call, so there's no need
  // to create a new function object. We can even get away with assuming
  // the method takes exactly one argument, since that happens to be true
  // in every case, so we don't have to touch the arguments object. The
  // only additional allocation required is the completion record, which
  // has a stable shape and so hopefully should be cheap to allocate.
  function tryCatch(fn, obj, arg) {
    try {
      return { type: "normal", arg: fn.call(obj, arg) };
    } catch (err) {
      return { type: "throw", arg: err };
    }
  }

  var GenStateSuspendedStart = "suspendedStart";
  var GenStateSuspendedYield = "suspendedYield";
  var GenStateExecuting = "executing";
  var GenStateCompleted = "completed";

  // Returning this object from the innerFn has the same effect as
  // breaking out of the dispatch switch statement.
  var ContinueSentinel = {};

  // Dummy constructor functions that we use as the .constructor and
  // .constructor.prototype properties for functions that return Generator
  // objects. For full spec compliance, you may wish to configure your
  // minifier not to mangle the names of these two functions.
  function Generator() {}
  function GeneratorFunction() {}
  function GeneratorFunctionPrototype() {}

  // This is a polyfill for %IteratorPrototype% for environments that
  // don't natively support it.
  var IteratorPrototype = {};
  IteratorPrototype[iteratorSymbol] = function () {
    return this;
  };

  var getProto = Object.getPrototypeOf;
  var NativeIteratorPrototype = getProto && getProto(getProto(values([])));
  if (NativeIteratorPrototype &&
      NativeIteratorPrototype !== Op &&
      hasOwn.call(NativeIteratorPrototype, iteratorSymbol)) {
    // This environment has a native %IteratorPrototype%; use it instead
    // of the polyfill.
    IteratorPrototype = NativeIteratorPrototype;
  }

  var Gp = GeneratorFunctionPrototype.prototype =
    Generator.prototype = Object.create(IteratorPrototype);
  GeneratorFunction.prototype = Gp.constructor = GeneratorFunctionPrototype;
  GeneratorFunctionPrototype.constructor = GeneratorFunction;
  GeneratorFunctionPrototype[toStringTagSymbol] =
    GeneratorFunction.displayName = "GeneratorFunction";

  // Helper for defining the .next, .throw, and .return methods of the
  // Iterator interface in terms of a single ._invoke method.
  function defineIteratorMethods(prototype) {
    ["next", "throw", "return"].forEach(function(method) {
      prototype[method] = function(arg) {
        return this._invoke(method, arg);
      };
    });
  }

  exports.isGeneratorFunction = function(genFun) {
    var ctor = typeof genFun === "function" && genFun.constructor;
    return ctor
      ? ctor === GeneratorFunction ||
        // For the native GeneratorFunction constructor, the best we can
        // do is to check its .name property.
        (ctor.displayName || ctor.name) === "GeneratorFunction"
      : false;
  };

  exports.mark = function(genFun) {
    if (Object.setPrototypeOf) {
      Object.setPrototypeOf(genFun, GeneratorFunctionPrototype);
    } else {
      genFun.__proto__ = GeneratorFunctionPrototype;
      if (!(toStringTagSymbol in genFun)) {
        genFun[toStringTagSymbol] = "GeneratorFunction";
      }
    }
    genFun.prototype = Object.create(Gp);
    return genFun;
  };

  // Within the body of any async function, `await x` is transformed to
  // `yield regeneratorRuntime.awrap(x)`, so that the runtime can test
  // `hasOwn.call(value, "__await")` to determine if the yielded value is
  // meant to be awaited.
  exports.awrap = function(arg) {
    return { __await: arg };
  };

  function AsyncIterator(generator) {
    function invoke(method, arg, resolve, reject) {
      var record = tryCatch(generator[method], generator, arg);
      if (record.type === "throw") {
        reject(record.arg);
      } else {
        var result = record.arg;
        var value = result.value;
        if (value &&
            typeof value === "object" &&
            hasOwn.call(value, "__await")) {
          return Promise.resolve(value.__await).then(function(value) {
            invoke("next", value, resolve, reject);
          }, function(err) {
            invoke("throw", err, resolve, reject);
          });
        }

        return Promise.resolve(value).then(function(unwrapped) {
          // When a yielded Promise is resolved, its final value becomes
          // the .value of the Promise<{value,done}> result for the
          // current iteration.
          result.value = unwrapped;
          resolve(result);
        }, function(error) {
          // If a rejected Promise was yielded, throw the rejection back
          // into the async generator function so it can be handled there.
          return invoke("throw", error, resolve, reject);
        });
      }
    }

    var previousPromise;

    function enqueue(method, arg) {
      function callInvokeWithMethodAndArg() {
        return new Promise(function(resolve, reject) {
          invoke(method, arg, resolve, reject);
        });
      }

      return previousPromise =
        // If enqueue has been called before, then we want to wait until
        // all previous Promises have been resolved before calling invoke,
        // so that results are always delivered in the correct order. If
        // enqueue has not been called before, then it is important to
        // call invoke immediately, without waiting on a callback to fire,
        // so that the async generator function has the opportunity to do
        // any necessary setup in a predictable way. This predictability
        // is why the Promise constructor synchronously invokes its
        // executor callback, and why async functions synchronously
        // execute code before the first await. Since we implement simple
        // async functions in terms of async generators, it is especially
        // important to get this right, even though it requires care.
        previousPromise ? previousPromise.then(
          callInvokeWithMethodAndArg,
          // Avoid propagating failures to Promises returned by later
          // invocations of the iterator.
          callInvokeWithMethodAndArg
        ) : callInvokeWithMethodAndArg();
    }

    // Define the unified helper method that is used to implement .next,
    // .throw, and .return (see defineIteratorMethods).
    this._invoke = enqueue;
  }

  defineIteratorMethods(AsyncIterator.prototype);
  AsyncIterator.prototype[asyncIteratorSymbol] = function () {
    return this;
  };
  exports.AsyncIterator = AsyncIterator;

  // Note that simple async functions are implemented on top of
  // AsyncIterator objects; they just return a Promise for the value of
  // the final result produced by the iterator.
  exports.async = function(innerFn, outerFn, self, tryLocsList) {
    var iter = new AsyncIterator(
      wrap(innerFn, outerFn, self, tryLocsList)
    );

    return exports.isGeneratorFunction(outerFn)
      ? iter // If outerFn is a generator, return the full iterator.
      : iter.next().then(function(result) {
          return result.done ? result.value : iter.next();
        });
  };

  function makeInvokeMethod(innerFn, self, context) {
    var state = GenStateSuspendedStart;

    return function invoke(method, arg) {
      if (state === GenStateExecuting) {
        throw new Error("Generator is already running");
      }

      if (state === GenStateCompleted) {
        if (method === "throw") {
          throw arg;
        }

        // Be forgiving, per 25.3.3.3.3 of the spec:
        // https://people.mozilla.org/~jorendorff/es6-draft.html#sec-generatorresume
        return doneResult();
      }

      context.method = method;
      context.arg = arg;

      while (true) {
        var delegate = context.delegate;
        if (delegate) {
          var delegateResult = maybeInvokeDelegate(delegate, context);
          if (delegateResult) {
            if (delegateResult === ContinueSentinel) continue;
            return delegateResult;
          }
        }

        if (context.method === "next") {
          // Setting context._sent for legacy support of Babel's
          // function.sent implementation.
          context.sent = context._sent = context.arg;

        } else if (context.method === "throw") {
          if (state === GenStateSuspendedStart) {
            state = GenStateCompleted;
            throw context.arg;
          }

          context.dispatchException(context.arg);

        } else if (context.method === "return") {
          context.abrupt("return", context.arg);
        }

        state = GenStateExecuting;

        var record = tryCatch(innerFn, self, context);
        if (record.type === "normal") {
          // If an exception is thrown from innerFn, we leave state ===
          // GenStateExecuting and loop back for another invocation.
          state = context.done
            ? GenStateCompleted
            : GenStateSuspendedYield;

          if (record.arg === ContinueSentinel) {
            continue;
          }

          return {
            value: record.arg,
            done: context.done
          };

        } else if (record.type === "throw") {
          state = GenStateCompleted;
          // Dispatch the exception by looping back around to the
          // context.dispatchException(context.arg) call above.
          context.method = "throw";
          context.arg = record.arg;
        }
      }
    };
  }

  // Call delegate.iterator[context.method](context.arg) and handle the
  // result, either by returning a { value, done } result from the
  // delegate iterator, or by modifying context.method and context.arg,
  // setting context.delegate to null, and returning the ContinueSentinel.
  function maybeInvokeDelegate(delegate, context) {
    var method = delegate.iterator[context.method];
    if (method === undefined) {
      // A .throw or .return when the delegate iterator has no .throw
      // method always terminates the yield* loop.
      context.delegate = null;

      if (context.method === "throw") {
        // Note: ["return"] must be used for ES3 parsing compatibility.
        if (delegate.iterator["return"]) {
          // If the delegate iterator has a return method, give it a
          // chance to clean up.
          context.method = "return";
          context.arg = undefined;
          maybeInvokeDelegate(delegate, context);

          if (context.method === "throw") {
            // If maybeInvokeDelegate(context) changed context.method from
            // "return" to "throw", let that override the TypeError below.
            return ContinueSentinel;
          }
        }

        context.method = "throw";
        context.arg = new TypeError(
          "The iterator does not provide a 'throw' method");
      }

      return ContinueSentinel;
    }

    var record = tryCatch(method, delegate.iterator, context.arg);

    if (record.type === "throw") {
      context.method = "throw";
      context.arg = record.arg;
      context.delegate = null;
      return ContinueSentinel;
    }

    var info = record.arg;

    if (! info) {
      context.method = "throw";
      context.arg = new TypeError("iterator result is not an object");
      context.delegate = null;
      return ContinueSentinel;
    }

    if (info.done) {
      // Assign the result of the finished delegate to the temporary
      // variable specified by delegate.resultName (see delegateYield).
      context[delegate.resultName] = info.value;

      // Resume execution at the desired location (see delegateYield).
      context.next = delegate.nextLoc;

      // If context.method was "throw" but the delegate handled the
      // exception, let the outer generator proceed normally. If
      // context.method was "next", forget context.arg since it has been
      // "consumed" by the delegate iterator. If context.method was
      // "return", allow the original .return call to continue in the
      // outer generator.
      if (context.method !== "return") {
        context.method = "next";
        context.arg = undefined;
      }

    } else {
      // Re-yield the result returned by the delegate method.
      return info;
    }

    // The delegate iterator is finished, so forget it and continue with
    // the outer generator.
    context.delegate = null;
    return ContinueSentinel;
  }

  // Define Generator.prototype.{next,throw,return} in terms of the
  // unified ._invoke helper method.
  defineIteratorMethods(Gp);

  Gp[toStringTagSymbol] = "Generator";

  // A Generator should always return itself as the iterator object when the
  // @@iterator function is called on it. Some browsers' implementations of the
  // iterator prototype chain incorrectly implement this, causing the Generator
  // object to not be returned from this call. This ensures that doesn't happen.
  // See https://github.com/facebook/regenerator/issues/274 for more details.
  Gp[iteratorSymbol] = function() {
    return this;
  };

  Gp.toString = function() {
    return "[object Generator]";
  };

  function pushTryEntry(locs) {
    var entry = { tryLoc: locs[0] };

    if (1 in locs) {
      entry.catchLoc = locs[1];
    }

    if (2 in locs) {
      entry.finallyLoc = locs[2];
      entry.afterLoc = locs[3];
    }

    this.tryEntries.push(entry);
  }

  function resetTryEntry(entry) {
    var record = entry.completion || {};
    record.type = "normal";
    delete record.arg;
    entry.completion = record;
  }

  function Context(tryLocsList) {
    // The root entry object (effectively a try statement without a catch
    // or a finally block) gives us a place to store values thrown from
    // locations where there is no enclosing try statement.
    this.tryEntries = [{ tryLoc: "root" }];
    tryLocsList.forEach(pushTryEntry, this);
    this.reset(true);
  }

  exports.keys = function(object) {
    var keys = [];
    for (var key in object) {
      keys.push(key);
    }
    keys.reverse();

    // Rather than returning an object with a next method, we keep
    // things simple and return the next function itself.
    return function next() {
      while (keys.length) {
        var key = keys.pop();
        if (key in object) {
          next.value = key;
          next.done = false;
          return next;
        }
      }

      // To avoid creating an additional object, we just hang the .value
      // and .done properties off the next function object itself. This
      // also ensures that the minifier will not anonymize the function.
      next.done = true;
      return next;
    };
  };

  function values(iterable) {
    if (iterable) {
      var iteratorMethod = iterable[iteratorSymbol];
      if (iteratorMethod) {
        return iteratorMethod.call(iterable);
      }

      if (typeof iterable.next === "function") {
        return iterable;
      }

      if (!isNaN(iterable.length)) {
        var i = -1, next = function next() {
          while (++i < iterable.length) {
            if (hasOwn.call(iterable, i)) {
              next.value = iterable[i];
              next.done = false;
              return next;
            }
          }

          next.value = undefined;
          next.done = true;

          return next;
        };

        return next.next = next;
      }
    }

    // Return an iterator with no values.
    return { next: doneResult };
  }
  exports.values = values;

  function doneResult() {
    return { value: undefined, done: true };
  }

  Context.prototype = {
    constructor: Context,

    reset: function(skipTempReset) {
      this.prev = 0;
      this.next = 0;
      // Resetting context._sent for legacy support of Babel's
      // function.sent implementation.
      this.sent = this._sent = undefined;
      this.done = false;
      this.delegate = null;

      this.method = "next";
      this.arg = undefined;

      this.tryEntries.forEach(resetTryEntry);

      if (!skipTempReset) {
        for (var name in this) {
          // Not sure about the optimal order of these conditions:
          if (name.charAt(0) === "t" &&
              hasOwn.call(this, name) &&
              !isNaN(+name.slice(1))) {
            this[name] = undefined;
          }
        }
      }
    },

    stop: function() {
      this.done = true;

      var rootEntry = this.tryEntries[0];
      var rootRecord = rootEntry.completion;
      if (rootRecord.type === "throw") {
        throw rootRecord.arg;
      }

      return this.rval;
    },

    dispatchException: function(exception) {
      if (this.done) {
        throw exception;
      }

      var context = this;
      function handle(loc, caught) {
        record.type = "throw";
        record.arg = exception;
        context.next = loc;

        if (caught) {
          // If the dispatched exception was caught by a catch block,
          // then let that catch block handle the exception normally.
          context.method = "next";
          context.arg = undefined;
        }

        return !! caught;
      }

      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        var record = entry.completion;

        if (entry.tryLoc === "root") {
          // Exception thrown outside of any try block that could handle
          // it, so set the completion value of the entire function to
          // throw the exception.
          return handle("end");
        }

        if (entry.tryLoc <= this.prev) {
          var hasCatch = hasOwn.call(entry, "catchLoc");
          var hasFinally = hasOwn.call(entry, "finallyLoc");

          if (hasCatch && hasFinally) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            } else if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }

          } else if (hasCatch) {
            if (this.prev < entry.catchLoc) {
              return handle(entry.catchLoc, true);
            }

          } else if (hasFinally) {
            if (this.prev < entry.finallyLoc) {
              return handle(entry.finallyLoc);
            }

          } else {
            throw new Error("try statement without catch or finally");
          }
        }
      }
    },

    abrupt: function(type, arg) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc <= this.prev &&
            hasOwn.call(entry, "finallyLoc") &&
            this.prev < entry.finallyLoc) {
          var finallyEntry = entry;
          break;
        }
      }

      if (finallyEntry &&
          (type === "break" ||
           type === "continue") &&
          finallyEntry.tryLoc <= arg &&
          arg <= finallyEntry.finallyLoc) {
        // Ignore the finally entry if control is not jumping to a
        // location outside the try/catch block.
        finallyEntry = null;
      }

      var record = finallyEntry ? finallyEntry.completion : {};
      record.type = type;
      record.arg = arg;

      if (finallyEntry) {
        this.method = "next";
        this.next = finallyEntry.finallyLoc;
        return ContinueSentinel;
      }

      return this.complete(record);
    },

    complete: function(record, afterLoc) {
      if (record.type === "throw") {
        throw record.arg;
      }

      if (record.type === "break" ||
          record.type === "continue") {
        this.next = record.arg;
      } else if (record.type === "return") {
        this.rval = this.arg = record.arg;
        this.method = "return";
        this.next = "end";
      } else if (record.type === "normal" && afterLoc) {
        this.next = afterLoc;
      }

      return ContinueSentinel;
    },

    finish: function(finallyLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.finallyLoc === finallyLoc) {
          this.complete(entry.completion, entry.afterLoc);
          resetTryEntry(entry);
          return ContinueSentinel;
        }
      }
    },

    "catch": function(tryLoc) {
      for (var i = this.tryEntries.length - 1; i >= 0; --i) {
        var entry = this.tryEntries[i];
        if (entry.tryLoc === tryLoc) {
          var record = entry.completion;
          if (record.type === "throw") {
            var thrown = record.arg;
            resetTryEntry(entry);
          }
          return thrown;
        }
      }

      // The context.catch method must only be called with a location
      // argument that corresponds to a known catch block.
      throw new Error("illegal catch attempt");
    },

    delegateYield: function(iterable, resultName, nextLoc) {
      this.delegate = {
        iterator: values(iterable),
        resultName: resultName,
        nextLoc: nextLoc
      };

      if (this.method === "next") {
        // Deliberately forget the last sent value so that we don't
        // accidentally pass it on to the delegate.
        this.arg = undefined;
      }

      return ContinueSentinel;
    }
  };

  // Regardless of whether this script is executing as a CommonJS module
  // or not, return the runtime object so that we can declare the variable
  // regeneratorRuntime in the outer scope, which allows this module to be
  // injected easily by `bin/regenerator --include-runtime script.js`.
  return exports;

}(
  // If this script is executing as a CommonJS module, use module.exports
  // as the regeneratorRuntime namespace. Otherwise create a new empty
  // object. Either way, the resulting object will be used to initialize
  // the regeneratorRuntime variable at the top of this file.
   true ? module.exports : undefined
));

try {
  regeneratorRuntime = runtime;
} catch (accidentalStrictMode) {
  // This module should not be running in strict mode, so the above
  // assignment should always work unless something is misconfigured. Just
  // in case runtime.js accidentally runs in strict mode, we can escape
  // strict mode using a global Function call. This could conceivably fail
  // if a Content Security Policy forbids using Function, but in that case
  // the proper solution is to fix the accidental strict mode problem. If
  // you've misconfigured your bundler to force strict mode and applied a
  // CSP to forbid Function, and you're not willing to fix either of those
  // problems, please detail your unique predicament in a GitHub issue.
  Function("r", "regeneratorRuntime = r")(runtime);
}

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/promise-polyfill/lib/index.js */ "./node_modules/promise-polyfill/lib/index.js")))

/***/ }),

/***/ "./node_modules/sketch-polyfill-fetch/lib/index.js":
/*!*********************************************************!*\
  !*** ./node_modules/sketch-polyfill-fetch/lib/index.js ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

/* WEBPACK VAR INJECTION */(function(Promise) {/* globals NSJSONSerialization NSJSONWritingPrettyPrinted NSDictionary NSHTTPURLResponse NSString NSASCIIStringEncoding NSUTF8StringEncoding coscript NSURL NSMutableURLRequest NSMutableData NSURLConnection */
var Buffer;
try {
  Buffer = __webpack_require__(/*! buffer */ "buffer").Buffer;
} catch (err) {}

function response(httpResponse, data) {
  var keys = [];
  var all = [];
  var headers = {};
  var header;

  for (var i = 0; i < httpResponse.allHeaderFields().allKeys().length; i++) {
    var key = httpResponse
      .allHeaderFields()
      .allKeys()
      [i].toLowerCase();
    var value = String(httpResponse.allHeaderFields()[key]);
    keys.push(key);
    all.push([key, value]);
    header = headers[key];
    headers[key] = header ? header + "," + value : value;
  }

  return {
    ok: ((httpResponse.statusCode() / 200) | 0) == 1, // 200-399
    status: Number(httpResponse.statusCode()),
    statusText: String(
      NSHTTPURLResponse.localizedStringForStatusCode(httpResponse.statusCode())
    ),
    useFinalURL: true,
    url: String(httpResponse.URL().absoluteString()),
    clone: response.bind(this, httpResponse, data),
    text: function() {
      return new Promise(function(resolve, reject) {
        const str = String(
          NSString.alloc().initWithData_encoding(data, NSASCIIStringEncoding)
        );
        if (str) {
          resolve(str);
        } else {
          reject(new Error("Couldn't parse body"));
        }
      });
    },
    json: function() {
      return new Promise(function(resolve, reject) {
        var str = String(
          NSString.alloc().initWithData_encoding(data, NSUTF8StringEncoding)
        );
        if (str) {
          // parse errors are turned into exceptions, which cause promise to be rejected
          var obj = JSON.parse(str);
          resolve(obj);
        } else {
          reject(
            new Error(
              "Could not parse JSON because it is not valid UTF-8 data."
            )
          );
        }
      });
    },
    blob: function() {
      return Promise.resolve(data);
    },
    arrayBuffer: function() {
      return Promise.resolve(Buffer.from(data));
    },
    headers: {
      keys: function() {
        return keys;
      },
      entries: function() {
        return all;
      },
      get: function(n) {
        return headers[n.toLowerCase()];
      },
      has: function(n) {
        return n.toLowerCase() in headers;
      }
    }
  };
}

// We create one ObjC class for ourselves here
var DelegateClass;

function fetch(urlString, options) {
  if (
    typeof urlString === "object" &&
    (!urlString.isKindOfClass || !urlString.isKindOfClass(NSString))
  ) {
    options = urlString;
    urlString = options.url;
  }
  options = options || {};
  if (!urlString) {
    return Promise.reject("Missing URL");
  }
  var fiber;
  try {
    fiber = coscript.createFiber();
  } catch (err) {
    coscript.shouldKeepAround = true;
  }
  return new Promise(function(resolve, reject) {
    var url = NSURL.alloc().initWithString(urlString);
    var request = NSMutableURLRequest.requestWithURL(url);
    request.setHTTPMethod(options.method || "GET");

    Object.keys(options.headers || {}).forEach(function(i) {
      request.setValue_forHTTPHeaderField(options.headers[i], i);
    });

    if (options.body) {
      var data;
      if (typeof options.body === "string") {
        var str = NSString.alloc().initWithString(options.body);
        data = str.dataUsingEncoding(NSUTF8StringEncoding);
      } else if (Buffer && Buffer.isBuffer(options.body)) {
        data = options.body.toNSData();
      } else if (
        options.body.isKindOfClass &&
        options.body.isKindOfClass(NSData) == 1
      ) {
        data = options.body;
      } else if (options.body._isFormData) {
        var boundary = options.body._boundary;
        data = options.body._data;
        data.appendData(
          NSString.alloc()
            .initWithString("--" + boundary + "--\r\n")
            .dataUsingEncoding(NSUTF8StringEncoding)
        );
        request.setValue_forHTTPHeaderField(
          "multipart/form-data; boundary=" + boundary,
          "Content-Type"
        );
      } else {
        var error;
        data = NSJSONSerialization.dataWithJSONObject_options_error(
          options.body,
          NSJSONWritingPrettyPrinted,
          error
        );
        if (error != null) {
          return reject(error);
        }
        request.setValue_forHTTPHeaderField(
          "" + data.length(),
          "Content-Length"
        );
      }
      request.setHTTPBody(data);
    }

    if (options.cache) {
      switch (options.cache) {
        case "reload":
        case "no-cache":
        case "no-store": {
          request.setCachePolicy(1); // NSURLRequestReloadIgnoringLocalCacheData
        }
        case "force-cache": {
          request.setCachePolicy(2); // NSURLRequestReturnCacheDataElseLoad
        }
        case "only-if-cached": {
          request.setCachePolicy(3); // NSURLRequestReturnCacheDataElseLoad
        }
      }
    }

    if (!options.credentials) {
      request.setHTTPShouldHandleCookies(false);
    }

    var finished = false;

    var connection = NSURLSession.sharedSession().dataTaskWithRequest_completionHandler(
      request,
      __mocha__.createBlock_function(
        'v32@?0@"NSData"8@"NSURLResponse"16@"NSError"24',
        function(data, res, error) {
          if (fiber) {
            fiber.cleanup();
          } else {
            coscript.shouldKeepAround = false;
          }
          if (error) {
            finished = true;
            return reject(error);
          }
          return resolve(response(res, data));
        }
      )
    );

    connection.resume();

    if (fiber) {
      fiber.onCleanup(function() {
        if (!finished) {
          connection.cancel();
        }
      });
    }
  });
}

module.exports = fetch;

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/promise-polyfill/lib/index.js */ "./node_modules/promise-polyfill/lib/index.js")))

/***/ }),

/***/ "./src/api.js":
/*!********************!*\
  !*** ./src/api.js ***!
  \********************/
/*! exports provided: getApiUrl, getSIMApiUrl, getAlertApiUrl */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getApiUrl", function() { return getApiUrl; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSIMApiUrl", function() { return getSIMApiUrl; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getAlertApiUrl", function() { return getAlertApiUrl; });
var Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings");

var appdApi = Settings.settingForKey('appdApi');
function getApiUrl(endpoint, params) {
  var url = params ? "https://".concat(appdApi.url, "/controller/rest/").concat(endpoint, "?time-range-type=BEFORE_NOW&duration-in-mins=15&output=JSON&").concat(params) : "https://".concat(appdApi.url, "/controller/rest/").concat(endpoint, "?time-range-type=BEFORE_NOW&duration-in-mins=15&output=JSON");
  var login = appdApi.login;
  return {
    url: url,
    headers: {
      "Authorization": "Basic ".concat(login)
    }
  };
}
function getSIMApiUrl() {
  var url = "https://".concat(appdApi.url, "/controller/sim/v2/user/machines?appIds=&tierIds=&nodeIds=&format=LITE&output=JSON");
  var login = appdApi.login;
  return {
    url: url,
    headers: {
      "Authorization": "Basic ".concat(login)
    }
  };
}
function getAlertApiUrl(applicationId, endpoint) {
  var url = "https://".concat(appdApi.url, "/controller/alerting/rest/v1/applications/").concat(applicationId, "/").concat(endpoint);
  var login = appdApi.login;
  return {
    url: url,
    headers: {
      "Authorization": "Basic ".concat(login)
    }
  };
}

/***/ }),

/***/ "./src/handlers/getActionNames.js":
/*!****************************************!*\
  !*** ./src/handlers/getActionNames.js ***!
  \****************************************/
/*! exports provided: getActionNames, getAction */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(Promise, fetch) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getActionNames", function() { return getActionNames; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getAction", function() { return getAction; });
/* harmony import */ var _babel_runtime_helpers_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/toConsumableArray.js");
/* harmony import */ var _babel_runtime_helpers_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/regenerator/index.js */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_1__);



var _require = __webpack_require__(/*! ../api.js */ "./src/api.js"),
    getAlertApiUrl = _require.getAlertApiUrl;

function getActionNames(applications) {
  var actionNames;
  return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_1___default.a.async(function getActionNames$(_context2) {
    while (1) {
      switch (_context2.prev = _context2.next) {
        case 0:
          actionNames = [];
          return _context2.abrupt("return", Promise.all(applications.map(function _callee(a) {
            return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_1___default.a.async(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_1___default.a.awrap(getAction(a.id).then(function (ans) {
                      return ans.forEach(function (an) {
                        return actionNames.push(an.name);
                      });
                    }));

                  case 2:
                    return _context.abrupt("return", _context.sent);

                  case 3:
                  case "end":
                    return _context.stop();
                }
              }
            });
          })).then(function () {
            return _babel_runtime_helpers_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0___default()(new Set(actionNames.slice(0, 100)));
          }).catch(function (err) {
            return console.log(err);
          }));

        case 2:
        case "end":
          return _context2.stop();
      }
    }
  });
}
function getAction(applicationId) {
  var api;
  return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_1___default.a.async(function getAction$(_context3) {
    while (1) {
      switch (_context3.prev = _context3.next) {
        case 0:
          api = getAlertApiUrl(applicationId, "actions");
          _context3.next = 3;
          return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_1___default.a.awrap(fetch(api.url, {
            headers: api.headers
          }).then(function (response) {
            return response.json()._value;
          }).catch(function (error) {
            console.log(error);
          }));

        case 3:
          return _context3.abrupt("return", _context3.sent);

        case 4:
        case "end":
          return _context3.stop();
      }
    }
  });
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/promise-polyfill/lib/index.js */ "./node_modules/promise-polyfill/lib/index.js"), __webpack_require__(/*! ./node_modules/sketch-polyfill-fetch/lib/index.js */ "./node_modules/sketch-polyfill-fetch/lib/index.js")))

/***/ }),

/***/ "./src/handlers/getApplications.js":
/*!*****************************************!*\
  !*** ./src/handlers/getApplications.js ***!
  \*****************************************/
/*! exports provided: getApplications */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(fetch) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getApplications", function() { return getApplications; });
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator/index.js */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__);


var _require = __webpack_require__(/*! ../api.js */ "./src/api.js"),
    getApiUrl = _require.getApiUrl;

function getApplications() {
  var api;
  return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function getApplications$(_context) {
    while (1) {
      switch (_context.prev = _context.next) {
        case 0:
          api = getApiUrl('applications', null);
          _context.next = 3;
          return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.awrap(fetch(api.url, {
            headers: api.headers
          }).then(function (response) {
            return response.json()._value.slice(0, 500);
          }).catch(function (error) {
            console.log(error);
          }));

        case 3:
          return _context.abrupt("return", _context.sent);

        case 4:
        case "end":
          return _context.stop();
      }
    }
  });
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/sketch-polyfill-fetch/lib/index.js */ "./node_modules/sketch-polyfill-fetch/lib/index.js")))

/***/ }),

/***/ "./src/handlers/getBackends.js":
/*!*************************************!*\
  !*** ./src/handlers/getBackends.js ***!
  \*************************************/
/*! exports provided: getBackEnds, getBackend */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(Promise, fetch) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getBackEnds", function() { return getBackEnds; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getBackend", function() { return getBackend; });
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator/index.js */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__);


var _require = __webpack_require__(/*! ../api.js */ "./src/api.js"),
    getApiUrl = _require.getApiUrl;

function getBackEnds(applications) {
  var bes;
  return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function getBackEnds$(_context2) {
    while (1) {
      switch (_context2.prev = _context2.next) {
        case 0:
          bes = [];
          return _context2.abrupt("return", Promise.all(applications.map(function _callee(a) {
            return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.awrap(getBackend(a.id).then(function (be) {
                      return be.forEach(function (besub) {
                        return bes.push(besub.name);
                      });
                    }));

                  case 2:
                    return _context.abrupt("return", _context.sent);

                  case 3:
                  case "end":
                    return _context.stop();
                }
              }
            });
          })).then(function () {
            return bes.slice(0, 100);
          }).catch(function (err) {
            return console.log(err);
          }));

        case 2:
        case "end":
          return _context2.stop();
      }
    }
  });
}
function getBackend(applicationId) {
  var api;
  return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function getBackend$(_context3) {
    while (1) {
      switch (_context3.prev = _context3.next) {
        case 0:
          api = getApiUrl("applications/".concat(applicationId, "/backends"));
          _context3.next = 3;
          return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.awrap(fetch(api.url, {
            headers: api.headers
          }).then(function (response) {
            return response.json()._value.slice(0, 100);
          }).catch(function (error) {
            console.log(error);
          }));

        case 3:
          return _context3.abrupt("return", _context3.sent);

        case 4:
        case "end":
          return _context3.stop();
      }
    }
  });
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/promise-polyfill/lib/index.js */ "./node_modules/promise-polyfill/lib/index.js"), __webpack_require__(/*! ./node_modules/sketch-polyfill-fetch/lib/index.js */ "./node_modules/sketch-polyfill-fetch/lib/index.js")))

/***/ }),

/***/ "./src/handlers/getBusinessTransactions.js":
/*!*************************************************!*\
  !*** ./src/handlers/getBusinessTransactions.js ***!
  \*************************************************/
/*! exports provided: getBusinessTransactions, getBusinessTransaction */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(Promise, fetch) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getBusinessTransactions", function() { return getBusinessTransactions; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getBusinessTransaction", function() { return getBusinessTransaction; });
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator/index.js */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__);


var _require = __webpack_require__(/*! ../api.js */ "./src/api.js"),
    getApiUrl = _require.getApiUrl;

function getBusinessTransactions(applications) {
  var bts;
  return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function getBusinessTransactions$(_context2) {
    while (1) {
      switch (_context2.prev = _context2.next) {
        case 0:
          bts = [];
          return _context2.abrupt("return", Promise.all(applications.map(function _callee(a) {
            return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.awrap(getBusinessTransaction(a.id).then(function (bt) {
                      return bt.forEach(function (btsub) {
                        return bts.push(btsub.name);
                      });
                    }));

                  case 2:
                    return _context.abrupt("return", _context.sent);

                  case 3:
                  case "end":
                    return _context.stop();
                }
              }
            });
          })).then(function () {
            return bts.slice(0, 100);
          }).catch(function (err) {
            return console.log(err);
          }));

        case 2:
        case "end":
          return _context2.stop();
      }
    }
  });
}
function getBusinessTransaction(applicationId) {
  var api;
  return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function getBusinessTransaction$(_context3) {
    while (1) {
      switch (_context3.prev = _context3.next) {
        case 0:
          api = getApiUrl("applications/".concat(applicationId, "/business-transactions"));
          _context3.next = 3;
          return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.awrap(fetch(api.url, {
            headers: api.headers
          }).then(function (response) {
            return response.json()._value.slice(0, 100);
          }).catch(function (error) {
            console.log(error);
          }));

        case 3:
          return _context3.abrupt("return", _context3.sent);

        case 4:
        case "end":
          return _context3.stop();
      }
    }
  });
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/promise-polyfill/lib/index.js */ "./node_modules/promise-polyfill/lib/index.js"), __webpack_require__(/*! ./node_modules/sketch-polyfill-fetch/lib/index.js */ "./node_modules/sketch-polyfill-fetch/lib/index.js")))

/***/ }),

/***/ "./src/handlers/getCallsPerMinute.js":
/*!*******************************************!*\
  !*** ./src/handlers/getCallsPerMinute.js ***!
  \*******************************************/
/*! exports provided: getCallsPerMinute, getCallPerMinute */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(Promise, fetch) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCallsPerMinute", function() { return getCallsPerMinute; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCallPerMinute", function() { return getCallPerMinute; });
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator/index.js */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__);


var _require = __webpack_require__(/*! ../api.js */ "./src/api.js"),
    getApiUrl = _require.getApiUrl;

var _require2 = __webpack_require__(/*! ../helpers.js */ "./src/helpers.js"),
    abbreviateNumber = _require2.abbreviateNumber;

function getCallsPerMinute(applications) {
  return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function getCallsPerMinute$(_context2) {
    while (1) {
      switch (_context2.prev = _context2.next) {
        case 0:
          return _context2.abrupt("return", Promise.all(applications.map(function _callee(a) {
            return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.awrap(getCallPerMinute(a.id).then(function (er) {
                      return er.toString();
                    }));

                  case 2:
                    return _context.abrupt("return", _context.sent);

                  case 3:
                  case "end":
                    return _context.stop();
                }
              }
            });
          })).then(function (ers) {
            return ers;
          }).catch(function (err) {
            return console.log(err);
          }));

        case 1:
        case "end":
          return _context2.stop();
      }
    }
  });
}
function getCallPerMinute(applicationId) {
  var api;
  return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function getCallPerMinute$(_context3) {
    while (1) {
      switch (_context3.prev = _context3.next) {
        case 0:
          api = getApiUrl("applications/".concat(applicationId, "/metric-data"), 'metric-path=Overall%20Application%20Performance%7CCalls%20per%20Minute');
          _context3.next = 3;
          return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.awrap(fetch(api.url, {
            headers: api.headers
          }).then(function (response) {
            if (response.json()._value.length > 0 && response.json()._value[0].metricValues.length > 0) {
              return abbreviateNumber(response.json()._value[0].metricValues[0].current);
            } else {
              return '0';
            }
          }).catch(function (error) {
            console.log(error);
          }));

        case 3:
          return _context3.abrupt("return", _context3.sent);

        case 4:
        case "end":
          return _context3.stop();
      }
    }
  });
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/promise-polyfill/lib/index.js */ "./node_modules/promise-polyfill/lib/index.js"), __webpack_require__(/*! ./node_modules/sketch-polyfill-fetch/lib/index.js */ "./node_modules/sketch-polyfill-fetch/lib/index.js")))

/***/ }),

/***/ "./src/handlers/getDatabaseCallsPerMinute.js":
/*!***************************************************!*\
  !*** ./src/handlers/getDatabaseCallsPerMinute.js ***!
  \***************************************************/
/*! exports provided: getDatabaseCallsPerMinute, getCallPerMinute */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(Promise, fetch) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getDatabaseCallsPerMinute", function() { return getDatabaseCallsPerMinute; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getCallPerMinute", function() { return getCallPerMinute; });
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator/index.js */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__);


var _require = __webpack_require__(/*! ../api.js */ "./src/api.js"),
    getApiUrl = _require.getApiUrl;

var _require2 = __webpack_require__(/*! ../helpers.js */ "./src/helpers.js"),
    abbreviateNumber = _require2.abbreviateNumber;

function getDatabaseCallsPerMinute(databases) {
  return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function getDatabaseCallsPerMinute$(_context2) {
    while (1) {
      switch (_context2.prev = _context2.next) {
        case 0:
          return _context2.abrupt("return", Promise.all(databases.map(function _callee(d) {
            return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.awrap(getCallPerMinute(d.config.name).then(function (er) {
                      return er.toString();
                    }));

                  case 2:
                    return _context.abrupt("return", _context.sent);

                  case 3:
                  case "end":
                    return _context.stop();
                }
              }
            });
          })).then(function (ers) {
            return ers;
          }).catch(function (err) {
            return console.log(err);
          }));

        case 1:
        case "end":
          return _context2.stop();
      }
    }
  });
}
function getCallPerMinute(databaseName) {
  var api;
  return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function getCallPerMinute$(_context3) {
    while (1) {
      switch (_context3.prev = _context3.next) {
        case 0:
          api = getApiUrl("applications/Database%20Monitoring/metric-data", "metric-path=Databases%7C".concat(databaseName, "%7CKPI%7CCalls%20per%20Minute"));
          _context3.next = 3;
          return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.awrap(fetch(api.url, {
            headers: api.headers
          }).then(function (response) {
            if (response.json()._value.length > 0 && response.json()._value[0].metricValues.length > 0) {
              return abbreviateNumber(response.json()._value[0].metricValues[0].current);
            } else {
              return '0';
            }
          }).catch(function (error) {
            console.log(error);
          }));

        case 3:
          return _context3.abrupt("return", _context3.sent);

        case 4:
        case "end":
          return _context3.stop();
      }
    }
  });
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/promise-polyfill/lib/index.js */ "./node_modules/promise-polyfill/lib/index.js"), __webpack_require__(/*! ./node_modules/sketch-polyfill-fetch/lib/index.js */ "./node_modules/sketch-polyfill-fetch/lib/index.js")))

/***/ }),

/***/ "./src/handlers/getDatabases.js":
/*!**************************************!*\
  !*** ./src/handlers/getDatabases.js ***!
  \**************************************/
/*! exports provided: getDatabases */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getDatabases", function() { return getDatabases; });
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator/index.js */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__);


var _require = __webpack_require__(/*! ../api.js */ "./src/api.js"),
    getApiUrl = _require.getApiUrl;

function getDatabases() {
  var dbTypes, i;
  return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function getDatabases$(_context) {
    while (1) {
      switch (_context.prev = _context.next) {
        case 0:
          //const api = getApiUrl('databases/collectors', null);
          dbTypes = [];

          for (i = 0; i < 201; i++) {
            dbTypes.push(getDatabaseType());
          }

          return _context.abrupt("return", dbTypes);

        case 3:
        case "end":
          return _context.stop();
      }
    }
  });
}

function getDatabaseType() {
  var types = ['SQL Server', 'Oracle', 'Oracle RAC', 'PostgreSQL', 'Sybase IQ', 'Sybase IQ', 'MySQL', 'IBM DB2', 'Couchbase', 'MongoDB', 'Microsoft SQL Server'];
  return types[Math.floor(Math.random() * types.length)];
}

/***/ }),

/***/ "./src/handlers/getEUMApplications.js":
/*!********************************************!*\
  !*** ./src/handlers/getEUMApplications.js ***!
  \********************************************/
/*! exports provided: getEUMApplications, isEUMApplication */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(Promise, fetch) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getEUMApplications", function() { return getEUMApplications; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "isEUMApplication", function() { return isEUMApplication; });
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator/index.js */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__);


var _require = __webpack_require__(/*! ../api.js */ "./src/api.js"),
    getApiUrl = _require.getApiUrl;

function getEUMApplications(apps) {
  var EUMApps;
  return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function getEUMApplications$(_context2) {
    while (1) {
      switch (_context2.prev = _context2.next) {
        case 0:
          EUMApps = [];
          return _context2.abrupt("return", Promise.all(apps.map(function _callee(app) {
            return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.awrap(isEUMApplication(app.id).then(function (isApp) {
                      return isApp && EUMApps.push(app);
                    }));

                  case 2:
                    return _context.abrupt("return", _context.sent);

                  case 3:
                  case "end":
                    return _context.stop();
                }
              }
            });
          })).then(function () {
            return EUMApps;
          }).catch(function (err) {
            return console.log(err);
          }));

        case 2:
        case "end":
          return _context2.stop();
      }
    }
  });
}
function isEUMApplication(appId) {
  var api;
  return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function isEUMApplication$(_context3) {
    while (1) {
      switch (_context3.prev = _context3.next) {
        case 0:
          api = getApiUrl("applications/".concat(appId, "/metrics"), 'metric-path=End%20User%20Experience');
          _context3.next = 3;
          return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.awrap(fetch(api.url, {
            headers: api.headers
          }).then(function (response) {
            return response.json()._value.length > 0;
          }).catch(function (error) {
            console.log(error);
          }));

        case 3:
          return _context3.abrupt("return", _context3.sent);

        case 4:
        case "end":
          return _context3.stop();
      }
    }
  });
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/promise-polyfill/lib/index.js */ "./node_modules/promise-polyfill/lib/index.js"), __webpack_require__(/*! ./node_modules/sketch-polyfill-fetch/lib/index.js */ "./node_modules/sketch-polyfill-fetch/lib/index.js")))

/***/ }),

/***/ "./src/handlers/getEUMRequestsPerMinute.js":
/*!*************************************************!*\
  !*** ./src/handlers/getEUMRequestsPerMinute.js ***!
  \*************************************************/
/*! exports provided: getEUMRequestsPerMinute, getEUMRequestPerMinute */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(Promise, fetch) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getEUMRequestsPerMinute", function() { return getEUMRequestsPerMinute; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getEUMRequestPerMinute", function() { return getEUMRequestPerMinute; });
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator/index.js */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__);


var _require = __webpack_require__(/*! ../api.js */ "./src/api.js"),
    getApiUrl = _require.getApiUrl;

var _require2 = __webpack_require__(/*! ../helpers.js */ "./src/helpers.js"),
    abbreviateNumber = _require2.abbreviateNumber;

function getEUMRequestsPerMinute(applications) {
  return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function getEUMRequestsPerMinute$(_context2) {
    while (1) {
      switch (_context2.prev = _context2.next) {
        case 0:
          return _context2.abrupt("return", Promise.all(applications.map(function _callee(a) {
            return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.awrap(getEUMRequestPerMinute(a.id).then(function (rpm) {
                      return rpm.toString();
                    }));

                  case 2:
                    return _context.abrupt("return", _context.sent);

                  case 3:
                  case "end":
                    return _context.stop();
                }
              }
            });
          })).then(function (rpms) {
            return rpms;
          }).catch(function (err) {
            return console.log(err);
          }));

        case 1:
        case "end":
          return _context2.stop();
      }
    }
  });
}
function getEUMRequestPerMinute(applicationId) {
  var api;
  return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function getEUMRequestPerMinute$(_context3) {
    while (1) {
      switch (_context3.prev = _context3.next) {
        case 0:
          api = getApiUrl("applications/".concat(applicationId, "/metric-data"), 'metric-path=End%20User%20Experience%7CApp%7CAJAX%20Requests%20per%20Minute');
          _context3.next = 3;
          return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.awrap(fetch(api.url, {
            headers: api.headers
          }).then(function (response) {
            if (response.json()._value.length > 0 && response.json()._value[0].metricValues.length > 0) {
              return abbreviateNumber(response.json()._value[0].metricValues[0].current);
            } else {
              return '0';
            }
          }).catch(function (err) {
            return console.log(err);
          }));

        case 3:
          return _context3.abrupt("return", _context3.sent);

        case 4:
        case "end":
          return _context3.stop();
      }
    }
  });
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/promise-polyfill/lib/index.js */ "./node_modules/promise-polyfill/lib/index.js"), __webpack_require__(/*! ./node_modules/sketch-polyfill-fetch/lib/index.js */ "./node_modules/sketch-polyfill-fetch/lib/index.js")))

/***/ }),

/***/ "./src/handlers/getEUMResponseTime.js":
/*!********************************************!*\
  !*** ./src/handlers/getEUMResponseTime.js ***!
  \********************************************/
/*! exports provided: getEUMResponseTimes, getEUMResponseTime */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(Promise, fetch) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getEUMResponseTimes", function() { return getEUMResponseTimes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getEUMResponseTime", function() { return getEUMResponseTime; });
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator/index.js */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__);


var _require = __webpack_require__(/*! ../api.js */ "./src/api.js"),
    getApiUrl = _require.getApiUrl;

var _require2 = __webpack_require__(/*! ../helpers.js */ "./src/helpers.js"),
    abbreviateNumber = _require2.abbreviateNumber;

function getEUMResponseTimes(applications) {
  return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function getEUMResponseTimes$(_context2) {
    while (1) {
      switch (_context2.prev = _context2.next) {
        case 0:
          return _context2.abrupt("return", Promise.all(applications.map(function _callee(a) {
            return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.awrap(getEUMResponseTime(a.id).then(function (rs) {
                      return rs.toString();
                    }));

                  case 2:
                    return _context.abrupt("return", _context.sent);

                  case 3:
                  case "end":
                    return _context.stop();
                }
              }
            });
          })).then(function (rss) {
            return rss;
          }).catch(function (err) {
            return console.log(err);
          }));

        case 1:
        case "end":
          return _context2.stop();
      }
    }
  });
}
function getEUMResponseTime(applicationId) {
  var api;
  return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function getEUMResponseTime$(_context3) {
    while (1) {
      switch (_context3.prev = _context3.next) {
        case 0:
          api = getApiUrl("applications/".concat(applicationId, "/metric-data"), 'metric-path=End%20User%20Experience%7CApp%7CEnd%20User%20Response%20Time%20%28ms%29');
          _context3.next = 3;
          return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.awrap(fetch(api.url, {
            headers: api.headers
          }).then(function (response) {
            if (response.json()._value.length > 0 && response.json()._value[0].metricValues.length > 0) {
              return abbreviateNumber(response.json()._value[0].metricValues[0].current);
            } else {
              return '0';
            }
          }).catch(function (err) {
            return console.log(err);
          }));

        case 3:
          return _context3.abrupt("return", _context3.sent);

        case 4:
        case "end":
          return _context3.stop();
      }
    }
  });
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/promise-polyfill/lib/index.js */ "./node_modules/promise-polyfill/lib/index.js"), __webpack_require__(/*! ./node_modules/sketch-polyfill-fetch/lib/index.js */ "./node_modules/sketch-polyfill-fetch/lib/index.js")))

/***/ }),

/***/ "./src/handlers/getErrorsPerMinute.js":
/*!********************************************!*\
  !*** ./src/handlers/getErrorsPerMinute.js ***!
  \********************************************/
/*! exports provided: getErrorsPerMinute, getErrorPerMinute */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(Promise, fetch) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getErrorsPerMinute", function() { return getErrorsPerMinute; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getErrorPerMinute", function() { return getErrorPerMinute; });
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator/index.js */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__);


var _require = __webpack_require__(/*! ../api.js */ "./src/api.js"),
    getApiUrl = _require.getApiUrl;

var _require2 = __webpack_require__(/*! ../helpers.js */ "./src/helpers.js"),
    abbreviateNumber = _require2.abbreviateNumber;

function getErrorsPerMinute(applications) {
  return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function getErrorsPerMinute$(_context2) {
    while (1) {
      switch (_context2.prev = _context2.next) {
        case 0:
          return _context2.abrupt("return", Promise.all(applications.map(function _callee(a) {
            return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.awrap(getErrorPerMinute(a.id).then(function (er) {
                      return er.toString();
                    }));

                  case 2:
                    return _context.abrupt("return", _context.sent);

                  case 3:
                  case "end":
                    return _context.stop();
                }
              }
            });
          })).then(function (ers) {
            return ers;
          }).catch(function (err) {
            return console.log(err);
          }));

        case 1:
        case "end":
          return _context2.stop();
      }
    }
  });
}
function getErrorPerMinute(applicationId) {
  var api;
  return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function getErrorPerMinute$(_context3) {
    while (1) {
      switch (_context3.prev = _context3.next) {
        case 0:
          api = getApiUrl("applications/".concat(applicationId, "/metric-data"), 'metric-path=Overall%20Application%20Performance%7CErrors%20per%20Minute');
          _context3.next = 3;
          return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.awrap(fetch(api.url, {
            headers: api.headers
          }).then(function (response) {
            if (response.json()._value.length > 0 && response.json()._value[0].metricValues.length > 0) {
              return abbreviateNumber(response.json()._value[0].metricValues[0].current);
            } else {
              return '0';
            }
          }).catch(function (error) {
            console.log(error);
          }));

        case 3:
          return _context3.abrupt("return", _context3.sent);

        case 4:
        case "end":
          return _context3.stop();
      }
    }
  });
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/promise-polyfill/lib/index.js */ "./node_modules/promise-polyfill/lib/index.js"), __webpack_require__(/*! ./node_modules/sketch-polyfill-fetch/lib/index.js */ "./node_modules/sketch-polyfill-fetch/lib/index.js")))

/***/ }),

/***/ "./src/handlers/getHealthRuleNames.js":
/*!********************************************!*\
  !*** ./src/handlers/getHealthRuleNames.js ***!
  \********************************************/
/*! exports provided: getHealthRuleNames, getHealthRuleName */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(Promise, fetch) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getHealthRuleNames", function() { return getHealthRuleNames; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getHealthRuleName", function() { return getHealthRuleName; });
/* harmony import */ var _babel_runtime_helpers_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/toConsumableArray.js");
/* harmony import */ var _babel_runtime_helpers_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/regenerator/index.js */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_1__);



var _require = __webpack_require__(/*! ../api.js */ "./src/api.js"),
    getAlertApiUrl = _require.getAlertApiUrl;

function getHealthRuleNames(applications) {
  var healthRuleNames;
  return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_1___default.a.async(function getHealthRuleNames$(_context2) {
    while (1) {
      switch (_context2.prev = _context2.next) {
        case 0:
          healthRuleNames = [];
          return _context2.abrupt("return", Promise.all(applications.map(function _callee(a) {
            return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_1___default.a.async(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_1___default.a.awrap(getHealthRuleName(a.id).then(function (hrns) {
                      return hrns.forEach(function (hrn) {
                        return healthRuleNames.push(hrn.name);
                      });
                    }));

                  case 2:
                    return _context.abrupt("return", _context.sent);

                  case 3:
                  case "end":
                    return _context.stop();
                }
              }
            });
          })).then(function () {
            return _babel_runtime_helpers_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0___default()(new Set(healthRuleNames.slice(0, 100)));
          }).catch(function (err) {
            return console.log(err);
          }));

        case 2:
        case "end":
          return _context2.stop();
      }
    }
  });
}
function getHealthRuleName(applicationId) {
  var api;
  return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_1___default.a.async(function getHealthRuleName$(_context3) {
    while (1) {
      switch (_context3.prev = _context3.next) {
        case 0:
          api = getAlertApiUrl(applicationId, "health-rules");
          _context3.next = 3;
          return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_1___default.a.awrap(fetch(api.url, {
            headers: api.headers
          }).then(function (response) {
            return response.json()._value;
          }).catch(function (error) {
            console.log(error);
          }));

        case 3:
          return _context3.abrupt("return", _context3.sent);

        case 4:
        case "end":
          return _context3.stop();
      }
    }
  });
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/promise-polyfill/lib/index.js */ "./node_modules/promise-polyfill/lib/index.js"), __webpack_require__(/*! ./node_modules/sketch-polyfill-fetch/lib/index.js */ "./node_modules/sketch-polyfill-fetch/lib/index.js")))

/***/ }),

/***/ "./src/handlers/getNodes.js":
/*!**********************************!*\
  !*** ./src/handlers/getNodes.js ***!
  \**********************************/
/*! exports provided: getNodes, getNode */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(Promise, fetch) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getNodes", function() { return getNodes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getNode", function() { return getNode; });
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator/index.js */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__);


var _require = __webpack_require__(/*! ../api.js */ "./src/api.js"),
    getApiUrl = _require.getApiUrl;

function getNodes(applications) {
  var nodes;
  return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function getNodes$(_context2) {
    while (1) {
      switch (_context2.prev = _context2.next) {
        case 0:
          nodes = [];
          return _context2.abrupt("return", Promise.all(applications.map(function _callee(a) {
            return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.awrap(getNode(a.id).then(function (n) {
                      return n.forEach(function (nsub) {
                        return nodes.push(nsub.name);
                      });
                    }));

                  case 2:
                    return _context.abrupt("return", _context.sent);

                  case 3:
                  case "end":
                    return _context.stop();
                }
              }
            });
          })).then(function () {
            return nodes.slice(0, 100);
          }).catch(function (err) {
            return console.log(err);
          }));

        case 2:
        case "end":
          return _context2.stop();
      }
    }
  });
}
function getNode(applicationId) {
  var api;
  return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function getNode$(_context3) {
    while (1) {
      switch (_context3.prev = _context3.next) {
        case 0:
          api = getApiUrl("applications/".concat(applicationId, "/nodes"));
          _context3.next = 3;
          return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.awrap(fetch(api.url, {
            headers: api.headers
          }).then(function (response) {
            return response.json()._value.slice(0, 100);
          }).catch(function (error) {
            console.log(error);
          }));

        case 3:
          return _context3.abrupt("return", _context3.sent);

        case 4:
        case "end":
          return _context3.stop();
      }
    }
  });
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/promise-polyfill/lib/index.js */ "./node_modules/promise-polyfill/lib/index.js"), __webpack_require__(/*! ./node_modules/sketch-polyfill-fetch/lib/index.js */ "./node_modules/sketch-polyfill-fetch/lib/index.js")))

/***/ }),

/***/ "./src/handlers/getPolicyNames.js":
/*!****************************************!*\
  !*** ./src/handlers/getPolicyNames.js ***!
  \****************************************/
/*! exports provided: getPolicyNames, getPolicyName */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(Promise, fetch) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getPolicyNames", function() { return getPolicyNames; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getPolicyName", function() { return getPolicyName; });
/* harmony import */ var _babel_runtime_helpers_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/toConsumableArray.js */ "./node_modules/@babel/runtime/helpers/toConsumableArray.js");
/* harmony import */ var _babel_runtime_helpers_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/regenerator/index.js */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_1__);



var _require = __webpack_require__(/*! ../api.js */ "./src/api.js"),
    getAlertApiUrl = _require.getAlertApiUrl;

function getPolicyNames(applications) {
  var policyNames;
  return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_1___default.a.async(function getPolicyNames$(_context2) {
    while (1) {
      switch (_context2.prev = _context2.next) {
        case 0:
          policyNames = [];
          return _context2.abrupt("return", Promise.all(applications.map(function _callee(a) {
            return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_1___default.a.async(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_1___default.a.awrap(getPolicyName(a.id).then(function (pns) {
                      return pns.forEach(function (pn) {
                        return policyNames.push(pn.name);
                      });
                    }));

                  case 2:
                    return _context.abrupt("return", _context.sent);

                  case 3:
                  case "end":
                    return _context.stop();
                }
              }
            });
          })).then(function () {
            return _babel_runtime_helpers_toConsumableArray_js__WEBPACK_IMPORTED_MODULE_0___default()(new Set(policyNames.slice(0, 100)));
          }).catch(function (err) {
            return console.log(err);
          }));

        case 2:
        case "end":
          return _context2.stop();
      }
    }
  });
}
function getPolicyName(applicationId) {
  var api;
  return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_1___default.a.async(function getPolicyName$(_context3) {
    while (1) {
      switch (_context3.prev = _context3.next) {
        case 0:
          api = getAlertApiUrl(applicationId, "policies");
          _context3.next = 3;
          return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_1___default.a.awrap(fetch(api.url, {
            headers: api.headers
          }).then(function (response) {
            return response.json()._value;
          }).catch(function (error) {
            console.log(error);
          }));

        case 3:
          return _context3.abrupt("return", _context3.sent);

        case 4:
        case "end":
          return _context3.stop();
      }
    }
  });
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/promise-polyfill/lib/index.js */ "./node_modules/promise-polyfill/lib/index.js"), __webpack_require__(/*! ./node_modules/sketch-polyfill-fetch/lib/index.js */ "./node_modules/sketch-polyfill-fetch/lib/index.js")))

/***/ }),

/***/ "./src/handlers/getResponseTimes.js":
/*!******************************************!*\
  !*** ./src/handlers/getResponseTimes.js ***!
  \******************************************/
/*! exports provided: getResponseTimes, getResponseTime */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(Promise, fetch) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getResponseTimes", function() { return getResponseTimes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getResponseTime", function() { return getResponseTime; });
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator/index.js */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__);


var _require = __webpack_require__(/*! ../api.js */ "./src/api.js"),
    getApiUrl = _require.getApiUrl;

var _require2 = __webpack_require__(/*! ../helpers.js */ "./src/helpers.js"),
    abbreviateNumber = _require2.abbreviateNumber;

function getResponseTimes(applications) {
  return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function getResponseTimes$(_context2) {
    while (1) {
      switch (_context2.prev = _context2.next) {
        case 0:
          return _context2.abrupt("return", Promise.all(applications.map(function _callee(a) {
            return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.awrap(getResponseTime(a.id).then(function (rt) {
                      return rt.toString();
                    }));

                  case 2:
                    return _context.abrupt("return", _context.sent);

                  case 3:
                  case "end":
                    return _context.stop();
                }
              }
            });
          })).then(function (rts) {
            return rts;
          }).catch(function (err) {
            return console.log(err);
          }));

        case 1:
        case "end":
          return _context2.stop();
      }
    }
  });
}
function getResponseTime(applicationId) {
  var api;
  return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function getResponseTime$(_context3) {
    while (1) {
      switch (_context3.prev = _context3.next) {
        case 0:
          api = getApiUrl("applications/".concat(applicationId, "/metric-data"), 'metric-path=Overall%20Application%20Performance%7CAverage%20Response%20Time%20%28ms%29');
          _context3.next = 3;
          return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.awrap(fetch(api.url, {
            headers: api.headers
          }).then(function (response) {
            if (response.json()._value.length > 0 && response.json()._value[0].metricValues.length > 0) {
              return abbreviateNumber(response.json()._value[0].metricValues[0].current);
            } else {
              return '115';
            }
          }).catch(function (error) {
            console.log(error);
          }));

        case 3:
          return _context3.abrupt("return", _context3.sent);

        case 4:
        case "end":
          return _context3.stop();
      }
    }
  });
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/promise-polyfill/lib/index.js */ "./node_modules/promise-polyfill/lib/index.js"), __webpack_require__(/*! ./node_modules/sketch-polyfill-fetch/lib/index.js */ "./node_modules/sketch-polyfill-fetch/lib/index.js")))

/***/ }),

/***/ "./src/handlers/getSIMCPU.js":
/*!***********************************!*\
  !*** ./src/handlers/getSIMCPU.js ***!
  \***********************************/
/*! exports provided: getSIMCPU */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSIMCPU", function() { return getSIMCPU; });
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator/index.js */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__);


var _require = __webpack_require__(/*! ../helpers.js */ "./src/helpers.js"),
    getRandomPercent = _require.getRandomPercent;

function getSIMCPU() {
  var array, minLength, i;
  return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function getSIMCPU$(_context) {
    while (1) {
      switch (_context.prev = _context.next) {
        case 0:
          array = [];
          minLength = 100;

          for (i = 0; i <= minLength; i++) {
            array.push(getRandomPercent().toString());
          }

          _context.next = 5;
          return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.awrap(array);

        case 5:
          return _context.abrupt("return", _context.sent);

        case 6:
        case "end":
          return _context.stop();
      }
    }
  });
}

/***/ }),

/***/ "./src/handlers/getSIMDiskIO.js":
/*!**************************************!*\
  !*** ./src/handlers/getSIMDiskIO.js ***!
  \**************************************/
/*! exports provided: getSIMDiskIO */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSIMDiskIO", function() { return getSIMDiskIO; });
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator/index.js */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__);


var _require = __webpack_require__(/*! ../helpers.js */ "./src/helpers.js"),
    getRandomPercent = _require.getRandomPercent;

function getSIMDiskIO() {
  var array, minLength, i;
  return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function getSIMDiskIO$(_context) {
    while (1) {
      switch (_context.prev = _context.next) {
        case 0:
          array = [];
          minLength = 100;

          for (i = 0; i <= minLength; i++) {
            array.push(getRandomPercent().toString());
          }

          _context.next = 5;
          return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.awrap(array);

        case 5:
          return _context.abrupt("return", _context.sent);

        case 6:
        case "end":
          return _context.stop();
      }
    }
  });
}

/***/ }),

/***/ "./src/handlers/getSIMDiskUsage.js":
/*!*****************************************!*\
  !*** ./src/handlers/getSIMDiskUsage.js ***!
  \*****************************************/
/*! exports provided: getSIMDiskUsage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSIMDiskUsage", function() { return getSIMDiskUsage; });
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator/index.js */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__);


var _require = __webpack_require__(/*! ../helpers.js */ "./src/helpers.js"),
    getRandomPercent = _require.getRandomPercent;

function getSIMDiskUsage() {
  var array, minLength, i;
  return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function getSIMDiskUsage$(_context) {
    while (1) {
      switch (_context.prev = _context.next) {
        case 0:
          array = [];
          minLength = 100;

          for (i = 0; i <= minLength; i++) {
            array.push(getRandomPercent().toString());
          }

          _context.next = 5;
          return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.awrap(array);

        case 5:
          return _context.abrupt("return", _context.sent);

        case 6:
        case "end":
          return _context.stop();
      }
    }
  });
}

/***/ }),

/***/ "./src/handlers/getSIMMemory.js":
/*!**************************************!*\
  !*** ./src/handlers/getSIMMemory.js ***!
  \**************************************/
/*! exports provided: getSIMMemory */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSIMMemory", function() { return getSIMMemory; });
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator/index.js */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__);


var _require = __webpack_require__(/*! ../helpers.js */ "./src/helpers.js"),
    getRandomPercent = _require.getRandomPercent;

function getSIMMemory() {
  var array, minLength, i;
  return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function getSIMMemory$(_context) {
    while (1) {
      switch (_context.prev = _context.next) {
        case 0:
          array = [];
          minLength = 100;

          for (i = 0; i <= minLength; i++) {
            array.push(getRandomPercent().toString());
          }

          _context.next = 5;
          return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.awrap(array);

        case 5:
          return _context.abrupt("return", _context.sent);

        case 6:
        case "end":
          return _context.stop();
      }
    }
  });
}

/***/ }),

/***/ "./src/handlers/getSIMNames.js":
/*!*************************************!*\
  !*** ./src/handlers/getSIMNames.js ***!
  \*************************************/
/*! exports provided: getSIMNames */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(fetch) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSIMNames", function() { return getSIMNames; });
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator/index.js */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__);


var _require = __webpack_require__(/*! ../api.js */ "./src/api.js"),
    getSIMApiUrl = _require.getSIMApiUrl;

function getSIMNames() {
  var api;
  return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function getSIMNames$(_context) {
    while (1) {
      switch (_context.prev = _context.next) {
        case 0:
          api = getSIMApiUrl();
          _context.next = 3;
          return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.awrap(fetch(api.url, {
            headers: api.headers
          }).then(function (response) {
            return response.json()._value.slice(0, 500).map(function (s) {
              return s.name;
            });
          }).catch(function (error) {
            console.log(error);
          }));

        case 3:
          return _context.abrupt("return", _context.sent);

        case 4:
        case "end":
          return _context.stop();
      }
    }
  });
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/sketch-polyfill-fetch/lib/index.js */ "./node_modules/sketch-polyfill-fetch/lib/index.js")))

/***/ }),

/***/ "./src/handlers/getSIMNetworkIO.js":
/*!*****************************************!*\
  !*** ./src/handlers/getSIMNetworkIO.js ***!
  \*****************************************/
/*! exports provided: getSIMNetworkIO */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getSIMNetworkIO", function() { return getSIMNetworkIO; });
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator/index.js */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__);


var _require = __webpack_require__(/*! ../helpers.js */ "./src/helpers.js"),
    getRandomPercent = _require.getRandomPercent;

function getSIMNetworkIO() {
  var array, minLength, i;
  return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function getSIMNetworkIO$(_context) {
    while (1) {
      switch (_context.prev = _context.next) {
        case 0:
          array = [];
          minLength = 100;

          for (i = 0; i <= minLength; i++) {
            array.push(getRandomPercent().toString());
          }

          _context.next = 5;
          return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.awrap(array);

        case 5:
          return _context.abrupt("return", _context.sent);

        case 6:
        case "end":
          return _context.stop();
      }
    }
  });
}

/***/ }),

/***/ "./src/handlers/getTiers.js":
/*!**********************************!*\
  !*** ./src/handlers/getTiers.js ***!
  \**********************************/
/*! exports provided: getTiers, getTier */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(Promise, fetch) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getTiers", function() { return getTiers; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getTier", function() { return getTier; });
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/regenerator/index.js */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0__);


var _require = __webpack_require__(/*! ../api.js */ "./src/api.js"),
    getApiUrl = _require.getApiUrl;

function getTiers(applications) {
  var tiers;
  return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function getTiers$(_context2) {
    while (1) {
      switch (_context2.prev = _context2.next) {
        case 0:
          tiers = [];
          return _context2.abrupt("return", Promise.all(applications.map(function _callee(a) {
            return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.awrap(getTier(a.id).then(function (t) {
                      return t.forEach(function (tsub) {
                        return tiers.push(tsub.name);
                      });
                    }));

                  case 2:
                    return _context.abrupt("return", _context.sent);

                  case 3:
                  case "end":
                    return _context.stop();
                }
              }
            });
          })).then(function () {
            return tiers.slice(0, 100);
          }).catch(function (err) {
            return console.log(err);
          }));

        case 2:
        case "end":
          return _context2.stop();
      }
    }
  });
}
function getTier(applicationId) {
  var api;
  return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.async(function getTier$(_context3) {
    while (1) {
      switch (_context3.prev = _context3.next) {
        case 0:
          api = getApiUrl("applications/".concat(applicationId, "/tiers"));
          _context3.next = 3;
          return _babel_runtime_regenerator_index_js__WEBPACK_IMPORTED_MODULE_0___default.a.awrap(fetch(api.url, {
            headers: api.headers
          }).then(function (response) {
            return response.json()._value.slice(0, 100);
          }).catch(function (error) {
            console.log(error);
          }));

        case 3:
          return _context3.abrupt("return", _context3.sent);

        case 4:
        case "end":
          return _context3.stop();
      }
    }
  });
}
/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./node_modules/promise-polyfill/lib/index.js */ "./node_modules/promise-polyfill/lib/index.js"), __webpack_require__(/*! ./node_modules/sketch-polyfill-fetch/lib/index.js */ "./node_modules/sketch-polyfill-fetch/lib/index.js")))

/***/ }),

/***/ "./src/helpers.js":
/*!************************!*\
  !*** ./src/helpers.js ***!
  \************************/
/*! exports provided: getMinArray, abbreviateNumber, getTruncatedText, getRandomPercent, setValuesToLoading, sortNumbersAsc, sortNumbersDes, setLastDataAction */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getMinArray", function() { return getMinArray; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "abbreviateNumber", function() { return abbreviateNumber; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getTruncatedText", function() { return getTruncatedText; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getRandomPercent", function() { return getRandomPercent; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setValuesToLoading", function() { return setValuesToLoading; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sortNumbersAsc", function() { return sortNumbersAsc; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "sortNumbersDes", function() { return sortNumbersDes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setLastDataAction", function() { return setLastDataAction; });
var sketch = __webpack_require__(/*! sketch */ "sketch");

var _require = __webpack_require__(/*! sketch */ "sketch"),
    DataSupplier = _require.DataSupplier,
    Settings = _require.Settings;

var Text = __webpack_require__(/*! sketch/dom */ "sketch/dom").Text;

var Rectangle = __webpack_require__(/*! sketch/dom */ "sketch/dom").Rectangle;

var util = __webpack_require__(/*! util */ "util");

function getMinArray(array) {
  var minLength = 100;

  if (array.length > minLength) {
    return array;
  } else {
    while (array.length < minLength) {
      array.forEach(function (i) {
        array.push(i);
      });
    }

    return array;
  }
}
function abbreviateNumber(value) {
  var newValue = value;

  if (value >= 1000) {
    var suffixes = ["", "k", "m", "b", "t"];
    var suffixNum = Math.floor(("" + value).length / 3);
    var shortValue = '';

    for (var precision = 2; precision >= 1; precision--) {
      shortValue = parseFloat((suffixNum != 0 ? value / Math.pow(1000, suffixNum) : value).toPrecision(precision));
      var dotLessShortValue = (shortValue + '').replace(/[^a-zA-Z 0-9]+/g, '');

      if (dotLessShortValue.length <= 2) {
        break;
      }
    }

    if (shortValue % 1 != 0) shortValue = shortValue.toFixed(1);
    newValue = shortValue + suffixes[suffixNum];
  }

  return newValue;
}
function getTruncatedText(wrappedItem, string) {
  if (wrappedItem.type == 'DataOverride') {
    var respresentation = util.toArray(wrappedItem.symbolInstance.sketchObject.overrideContainer().flattenedChildren()).filter(function (x) {
      return util.inspect(x.availableOverride()).includes('MSAvailableOverride');
    }).find(function (x) {
      return x.availableOverride().internalOverrideValue().overrideName() == wrappedItem.override.id;
    });
    var repFrame = new Rectangle(CGPathGetBoundingBox(respresentation.pathInInstance()));
    var tempText = new Text({
      text: string,
      style: wrappedItem.override.affectedLayer.style
    });
    var currentWidth = tempText.adjustToFit().frame.width;
    var availableWidth = repFrame.width;

    if (currentWidth > availableWidth) {
      var singleCharacterWidth = new Text({
        text: 'A',
        style: wrappedItem.override.affectedLayer.style
      }).adjustToFit().frame.width;
      var diff = currentWidth - availableWidth;
      var newString = "".concat(string.slice(0, string.length - Math.round(diff / singleCharacterWidth) - 5), "...");
      return newString;
    } else {
      return string;
    }
  } else {
    var _tempText = new Text({
      text: string,
      style: wrappedItem.style
    });

    var _currentWidth = _tempText.adjustToFit().frame.width;

    var _availableWidth = wrappedItem.frame.width;

    if (_currentWidth > _availableWidth) {
      var _singleCharacterWidth = new Text({
        text: 'A',
        style: wrappedItem.style
      }).adjustToFit().frame.width;

      var _diff = _currentWidth - _availableWidth;

      var _newString = "".concat(string.slice(0, string.length - Math.round(_diff / _singleCharacterWidth) - 5), "...");

      return _newString;
    } else {
      return string;
    }
  }
}
function getRandomPercent() {
  return (Math.random() * 100 + 1).toFixed(1);
}
function setValuesToLoading(wrappedItems) {
  wrappedItems.forEach(function (wi) {
    if (wi.type === 'Text') {
      wi.text = "Loading...";
    } else {
      wi.override.value = "Loading...";
    }
  });
}
function sortNumbersAsc(a, b) {
  return a - b;
}
function sortNumbersDes(a, b) {
  return b - a;
}
function setLastDataAction(dataKey, handler) {
  Settings.setSettingForKey('appdLastAction', {
    dataKey: dataKey,
    handler: handler
  });
}

/***/ }),

/***/ "./src/index.js":
/*!**********************!*\
  !*** ./src/index.js ***!
  \**********************/
/*! exports provided: onStartup, onShutdown, onSupplyApplications, onSupplyApplicationsAsc, onSupplyApplicationsDes, onSupplyResponseTime, onSupplyResponseTimeAsc, onSupplyResponseTimeDes, onSupplyErrorsPerMinuteAsc, onSupplyErrorsPerMinuteDes, onSupplyCallsPerMinute, onSupplyCallsPerMinuteAsc, onSupplyCallsPerMinuteDes, onSupplyTiers, onSupplyTiersAsc, onSupplyTiersDes, onSupplyBusinessTransactions, onSupplyBusinessTransactionsAsc, onSupplyBusinessTransactionsDes, onSupplyBackends, onSupplyBackendsAsc, onSupplyBackendsDes, onSupplyNodes, onSupplyNodesAsc, onSupplyNodesDes, onSupplyEUMApplications, onSupplyEUMApplicationsAsc, onSupplyEUMApplicationsDes, onSupplyEUMRequestsPerMinute, onSupplyEUMRequestsPerMinuteAsc, onSupplyEUMRequestsPerMinuteDes, onSupplyEUMResponseTime, onSupplyEUMResponseTimeAsc, onSupplyEUMResponseTimeDes, onSupplyDatabases, onSupplyDatabasesAsc, onSupplyDatabasesDes, onSupplyDatabaseType, onSupplyDatabaseTypeAsc, onSupplyDatabaseTypeDes, onSupplyDatabaseCallsPerMinute, onSupplyDatabaseCallsPerMinuteAsc, onSupplyDatabaseCallsPerMinuteDes, onSupplySIMNames, onSupplySIMNamesAsc, onSupplySIMNamesDes, onSupplySIMDiskUsage, onSupplySIMDiskUsageAsc, onSupplySIMDiskUsageDes, onSupplySIMCPU, onSupplySIMCPUAsc, onSupplySIMCPUDes, onSupplySIMMemory, onSupplySIMMemoryAsc, onSupplySIMMemoryDes, onSupplySIMDiskIO, onSupplySIMDiskIOAsc, onSupplySIMDiskIODes, onSupplyAlertingHealthRuleNames, onSupplyAlertingHealthRuleNamesAsc, onSupplyAlertingHealthRuleNamesDes, onSupplyAlertingPolicyNames, onSupplyAlertingPolicyNamesAsc, onSupplyAlertingPolicyNamesDes, onSupplyAlertingActionNames, onSupplyAlertingActionNamesAsc, onSupplyAlertingActionNamesDes */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onStartup", function() { return onStartup; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onShutdown", function() { return onShutdown; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyApplications", function() { return onSupplyApplications; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyApplicationsAsc", function() { return onSupplyApplicationsAsc; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyApplicationsDes", function() { return onSupplyApplicationsDes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyResponseTime", function() { return onSupplyResponseTime; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyResponseTimeAsc", function() { return onSupplyResponseTimeAsc; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyResponseTimeDes", function() { return onSupplyResponseTimeDes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyErrorsPerMinuteAsc", function() { return onSupplyErrorsPerMinuteAsc; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyErrorsPerMinuteDes", function() { return onSupplyErrorsPerMinuteDes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyCallsPerMinute", function() { return onSupplyCallsPerMinute; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyCallsPerMinuteAsc", function() { return onSupplyCallsPerMinuteAsc; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyCallsPerMinuteDes", function() { return onSupplyCallsPerMinuteDes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyTiers", function() { return onSupplyTiers; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyTiersAsc", function() { return onSupplyTiersAsc; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyTiersDes", function() { return onSupplyTiersDes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyBusinessTransactions", function() { return onSupplyBusinessTransactions; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyBusinessTransactionsAsc", function() { return onSupplyBusinessTransactionsAsc; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyBusinessTransactionsDes", function() { return onSupplyBusinessTransactionsDes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyBackends", function() { return onSupplyBackends; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyBackendsAsc", function() { return onSupplyBackendsAsc; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyBackendsDes", function() { return onSupplyBackendsDes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyNodes", function() { return onSupplyNodes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyNodesAsc", function() { return onSupplyNodesAsc; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyNodesDes", function() { return onSupplyNodesDes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyEUMApplications", function() { return onSupplyEUMApplications; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyEUMApplicationsAsc", function() { return onSupplyEUMApplicationsAsc; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyEUMApplicationsDes", function() { return onSupplyEUMApplicationsDes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyEUMRequestsPerMinute", function() { return onSupplyEUMRequestsPerMinute; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyEUMRequestsPerMinuteAsc", function() { return onSupplyEUMRequestsPerMinuteAsc; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyEUMRequestsPerMinuteDes", function() { return onSupplyEUMRequestsPerMinuteDes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyEUMResponseTime", function() { return onSupplyEUMResponseTime; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyEUMResponseTimeAsc", function() { return onSupplyEUMResponseTimeAsc; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyEUMResponseTimeDes", function() { return onSupplyEUMResponseTimeDes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyDatabases", function() { return onSupplyDatabases; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyDatabasesAsc", function() { return onSupplyDatabasesAsc; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyDatabasesDes", function() { return onSupplyDatabasesDes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyDatabaseType", function() { return onSupplyDatabaseType; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyDatabaseTypeAsc", function() { return onSupplyDatabaseTypeAsc; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyDatabaseTypeDes", function() { return onSupplyDatabaseTypeDes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyDatabaseCallsPerMinute", function() { return onSupplyDatabaseCallsPerMinute; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyDatabaseCallsPerMinuteAsc", function() { return onSupplyDatabaseCallsPerMinuteAsc; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyDatabaseCallsPerMinuteDes", function() { return onSupplyDatabaseCallsPerMinuteDes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplySIMNames", function() { return onSupplySIMNames; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplySIMNamesAsc", function() { return onSupplySIMNamesAsc; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplySIMNamesDes", function() { return onSupplySIMNamesDes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplySIMDiskUsage", function() { return onSupplySIMDiskUsage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplySIMDiskUsageAsc", function() { return onSupplySIMDiskUsageAsc; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplySIMDiskUsageDes", function() { return onSupplySIMDiskUsageDes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplySIMCPU", function() { return onSupplySIMCPU; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplySIMCPUAsc", function() { return onSupplySIMCPUAsc; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplySIMCPUDes", function() { return onSupplySIMCPUDes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplySIMMemory", function() { return onSupplySIMMemory; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplySIMMemoryAsc", function() { return onSupplySIMMemoryAsc; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplySIMMemoryDes", function() { return onSupplySIMMemoryDes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplySIMDiskIO", function() { return onSupplySIMDiskIO; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplySIMDiskIOAsc", function() { return onSupplySIMDiskIOAsc; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplySIMDiskIODes", function() { return onSupplySIMDiskIODes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyAlertingHealthRuleNames", function() { return onSupplyAlertingHealthRuleNames; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyAlertingHealthRuleNamesAsc", function() { return onSupplyAlertingHealthRuleNamesAsc; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyAlertingHealthRuleNamesDes", function() { return onSupplyAlertingHealthRuleNamesDes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyAlertingPolicyNames", function() { return onSupplyAlertingPolicyNames; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyAlertingPolicyNamesAsc", function() { return onSupplyAlertingPolicyNamesAsc; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyAlertingPolicyNamesDes", function() { return onSupplyAlertingPolicyNamesDes; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyAlertingActionNames", function() { return onSupplyAlertingActionNames; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyAlertingActionNamesAsc", function() { return onSupplyAlertingActionNamesAsc; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "onSupplyAlertingActionNamesDes", function() { return onSupplyAlertingActionNamesDes; });
var sketch = __webpack_require__(/*! sketch */ "sketch");

var UI = __webpack_require__(/*! sketch/ui */ "sketch/ui");

var Settings = __webpack_require__(/*! sketch/settings */ "sketch/settings");

var DataSupplier = sketch.DataSupplier;

var util = __webpack_require__(/*! util */ "util");

var _require = __webpack_require__(/*! ./resources/dataMapping.js */ "./src/resources/dataMapping.js"),
    dataMapping = _require.dataMapping;

var _require2 = __webpack_require__(/*! ./helpers.js */ "./src/helpers.js"),
    getMinArray = _require2.getMinArray,
    getTruncatedText = _require2.getTruncatedText,
    setValuesToLoading = _require2.setValuesToLoading,
    sortNumbersAsc = _require2.sortNumbersAsc,
    sortNumbersDes = _require2.sortNumbersDes,
    setLastDataAction = _require2.setLastDataAction;

var _require3 = __webpack_require__(/*! ./api.js */ "./src/api.js"),
    getApiUrl = _require3.getApiUrl;

var _require4 = __webpack_require__(/*! ./handlers/getApplications.js */ "./src/handlers/getApplications.js"),
    getApplications = _require4.getApplications;

var _require5 = __webpack_require__(/*! ./handlers/getResponseTimes.js */ "./src/handlers/getResponseTimes.js"),
    getResponseTimes = _require5.getResponseTimes;

var _require6 = __webpack_require__(/*! ./handlers/getErrorsPerMinute.js */ "./src/handlers/getErrorsPerMinute.js"),
    getErrorsPerMinute = _require6.getErrorsPerMinute;

var _require7 = __webpack_require__(/*! ./handlers/getCallsPerMinute.js */ "./src/handlers/getCallsPerMinute.js"),
    getCallsPerMinute = _require7.getCallsPerMinute;

var _require8 = __webpack_require__(/*! ./handlers/getTiers.js */ "./src/handlers/getTiers.js"),
    getTiers = _require8.getTiers;

var _require9 = __webpack_require__(/*! ./handlers/getBusinessTransactions.js */ "./src/handlers/getBusinessTransactions.js"),
    getBusinessTransactions = _require9.getBusinessTransactions;

var _require10 = __webpack_require__(/*! ./handlers/getBackends.js */ "./src/handlers/getBackends.js"),
    getBackends = _require10.getBackends;

var _require11 = __webpack_require__(/*! ./handlers/getNodes.js */ "./src/handlers/getNodes.js"),
    getNodes = _require11.getNodes;

var _require12 = __webpack_require__(/*! ./handlers/getEUMApplications.js */ "./src/handlers/getEUMApplications.js"),
    getEUMApplications = _require12.getEUMApplications;

var _require13 = __webpack_require__(/*! ./handlers/getEUMRequestsPerMinute.js */ "./src/handlers/getEUMRequestsPerMinute.js"),
    getEUMRequestsPerMinute = _require13.getEUMRequestsPerMinute;

var _require14 = __webpack_require__(/*! ./handlers/getEUMResponseTime.js */ "./src/handlers/getEUMResponseTime.js"),
    getEUMResponseTimes = _require14.getEUMResponseTimes;

var _require15 = __webpack_require__(/*! ./handlers/getDatabases */ "./src/handlers/getDatabases.js"),
    getDatabases = _require15.getDatabases;

var _require16 = __webpack_require__(/*! ./handlers/getDatabaseCallsPerMinute */ "./src/handlers/getDatabaseCallsPerMinute.js"),
    getDatabaseCallsPerMinute = _require16.getDatabaseCallsPerMinute;

var _require17 = __webpack_require__(/*! ./handlers/getSIMNames */ "./src/handlers/getSIMNames.js"),
    getSIMNames = _require17.getSIMNames;

var _require18 = __webpack_require__(/*! ./handlers/getSIMDiskUsage */ "./src/handlers/getSIMDiskUsage.js"),
    getSIMDiskUsage = _require18.getSIMDiskUsage;

var _require19 = __webpack_require__(/*! ./handlers/getSIMCPU */ "./src/handlers/getSIMCPU.js"),
    getSIMCPU = _require19.getSIMCPU;

var _require20 = __webpack_require__(/*! ./handlers/getSIMMemory */ "./src/handlers/getSIMMemory.js"),
    getSIMMemory = _require20.getSIMMemory;

var _require21 = __webpack_require__(/*! ./handlers/getSIMDiskIO */ "./src/handlers/getSIMDiskIO.js"),
    getSIMDiskIO = _require21.getSIMDiskIO;

var _require22 = __webpack_require__(/*! ./handlers/getSIMNetworkIO */ "./src/handlers/getSIMNetworkIO.js"),
    getSIMNetworkIO = _require22.getSIMNetworkIO;

var _require23 = __webpack_require__(/*! ./handlers/getHealthRuleNames */ "./src/handlers/getHealthRuleNames.js"),
    getHealthRuleNames = _require23.getHealthRuleNames;

var _require24 = __webpack_require__(/*! ./handlers/getPolicyNames */ "./src/handlers/getPolicyNames.js"),
    getPolicyNames = _require24.getPolicyNames;

var _require25 = __webpack_require__(/*! ./handlers/getActionNames */ "./src/handlers/getActionNames.js"),
    getActionNames = _require25.getActionNames;

function onStartup() {
  Settings.setSettingForKey('appdApi', {
    url: 'oa.saas.appdynamics.com',
    login: 'c2hheWFuLmRoYW5hbmlAYXBwZHluYW1pY3M6Umh4T1lobFhtejhGVms='
  });
  dataMapping.forEach(function (d) {
    DataSupplier.registerDataSupplier('public.text', d.displayName, d.handler);
  });
}
function onShutdown() {
  // Deregister the plugin
  DataSupplier.deregisterDataSuppliers();
}
function onSupplyApplications(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching application names from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    var minApps = getMinArray(apps).map(function (app) {
      return app.name;
    });
    wrappedItems.forEach(function (wi, index) {
      DataSupplier.supplyDataAtIndex(dataKey, getTruncatedText(wi, minApps[index]), index);
    });
  }).then(function () {
    UI.message('Success!');
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyApplicationsAsc(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching application names from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    var minApps = getMinArray(apps).map(function (app) {
      return app.name;
    }).sort();
    wrappedItems.forEach(function (wi, index) {
      DataSupplier.supplyDataAtIndex(dataKey, getTruncatedText(wi, minApps[index]), index);
    });
  }).then(function () {
    UI.message('Success!');
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyApplicationsDes(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching application names from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    var minApps = getMinArray(apps).map(function (app) {
      return app.name;
    }).sort().reverse();
    wrappedItems.forEach(function (wi, index) {
      DataSupplier.supplyDataAtIndex(dataKey, getTruncatedText(wi, minApps[index]), index);
    });
  }).then(function () {
    UI.message('Success!');
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyResponseTime(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching response times from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getResponseTimes(apps).then(function (rts) {
      DataSupplier.supplyData(dataKey, getMinArray(rts));
    }).then(function () {
      UI.message('Success!');
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyResponseTimeAsc(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching response times from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getResponseTimes(apps).then(function (rts) {
      DataSupplier.supplyData(dataKey, getMinArray(rts).sort(sortNumbersAsc));
    }).then(function () {
      UI.message('Success!');
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyResponseTimeDes(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching response times from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getResponseTimes(apps).then(function (rts) {
      DataSupplier.supplyData(dataKey, getMinArray(rts.sort(sortNumbersDes)));
    }).then(function () {
      UI.message('Success!');
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyErrorsPerMinuteAsc(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching errors per minute from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getErrorsPerMinute(apps).then(function (epm) {
      DataSupplier.supplyData(dataKey, getMinArray(epm).sort(sortNumbersAsc));
    }).then(function () {
      UI.message('Success!');
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyErrorsPerMinuteDes(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching errors per minute from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getErrorsPerMinute(apps).then(function (epm) {
      DataSupplier.supplyData(dataKey, getMinArray(epm).sort(sortNumbersDes));
    }).then(function () {
      UI.message('Success!');
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyCallsPerMinute(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching calls per minute from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getCallsPerMinute(apps).then(function (cpm) {
      DataSupplier.supplyData(dataKey, getMinArray(cpm));
    }).catch(function (err) {
      UI.message(err);
    });
  }).then(function () {
    UI.message('Success!');
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyCallsPerMinuteAsc(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching calls per minute from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getCallsPerMinute(apps).then(function (cpm) {
      DataSupplier.supplyData(dataKey, getMinArray(cpm).sort(sortNumbersAsc));
    }).catch(function (err) {
      UI.message(err);
    });
  }).then(function () {
    UI.message('Success!');
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyCallsPerMinuteDes(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching calls per minute from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getCallsPerMinute(apps).then(function (cpm) {
      DataSupplier.supplyData(dataKey, getMinArray(cpm).sort(sortNumbersDes));
    }).catch(function (err) {
      UI.message(err);
    });
  }).then(function () {
    UI.message('Success!');
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyTiers(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching tiers from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getTiers(apps).then(function (t) {
      var minTiers = getMinArray(t);
      wrappedItems.forEach(function (wi, index) {
        DataSupplier.supplyDataAtIndex(dataKey, getTruncatedText(wi, minTiers[index]), index);
      });
    }).then(function () {
      UI.message('Success!');
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyTiersAsc(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching tiers from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getTiers(apps).then(function (t) {
      var minTiers = getMinArray(t).sort();
      wrappedItems.forEach(function (wi, index) {
        DataSupplier.supplyDataAtIndex(dataKey, getTruncatedText(wi, minTiers[index]), index);
      });
    }).then(function () {
      UI.message('Success!');
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyTiersDes(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching tiers from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getTiers(apps).then(function (t) {
      var minTiers = getMinArray(t).sort().reverse();
      wrappedItems.forEach(function (wi, index) {
        DataSupplier.supplyDataAtIndex(dataKey, getTruncatedText(wi, minTiers[index]), index);
      });
    }).then(function () {
      UI.message('Success!');
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyBusinessTransactions(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching BTs from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getBusinessTransactions(apps).then(function (bt) {
      var minBTs = getMinArray(bt);
      wrappedItems.forEach(function (wi, index) {
        DataSupplier.supplyDataAtIndex(dataKey, getTruncatedText(wi, minBTs[index]), index);
      });
    }).then(function () {
      UI.message('Success!');
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyBusinessTransactionsAsc(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching BTs from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getBusinessTransactions(apps).then(function (bt) {
      var minBTs = getMinArray(bt).sort();
      wrappedItems.forEach(function (wi, index) {
        DataSupplier.supplyDataAtIndex(dataKey, getTruncatedText(wi, minBTs[index]), index);
      });
    }).then(function () {
      UI.message('Success!');
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyBusinessTransactionsDes(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching BTs from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getBusinessTransactions(apps).then(function (bt) {
      var minBTs = getMinArray(bt).sort().reverse();
      wrappedItems.forEach(function (wi, index) {
        DataSupplier.supplyDataAtIndex(dataKey, getTruncatedText(wi, minBTs[index]), index);
      });
    }).then(function () {
      UI.message('Success!');
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyBackends(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching back-ends from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getBackends(apps).then(function (be) {
      var minBEs = getMinArray(be);
      wrappedItems.forEach(function (wi, index) {
        DataSupplier.supplyDataAtIndex(dataKey, getTruncatedText(wi, minBEs[index]), index);
      });
    }).then(function () {
      UI.message('Success!');
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyBackendsAsc(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching back-ends from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getBackends(apps).then(function (be) {
      var minBEs = getMinArray(be).sort();
      wrappedItems.forEach(function (wi, index) {
        DataSupplier.supplyDataAtIndex(dataKey, getTruncatedText(wi, minBEs[index]), index);
      });
    }).then(function () {
      UI.message('Success!');
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyBackendsDes(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching back-ends from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getBackends(apps).then(function (be) {
      var minBEs = getMinArray(be).sort().reverse();
      wrappedItems.forEach(function (wi, index) {
        DataSupplier.supplyDataAtIndex(dataKey, getTruncatedText(wi, minBEs[index]), index);
      });
    }).then(function () {
      UI.message('Success!');
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyNodes(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching nodes from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getNodes(apps).then(function (n) {
      var minNodes = getMinArray(n);
      wrappedItems.forEach(function (wi, index) {
        DataSupplier.supplyDataAtIndex(dataKey, getTruncatedText(wi, minNodes[index]), index);
      });
    }).then(function () {
      UI.message('Success!');
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyNodesAsc(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching nodes from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getNodes(apps).then(function (n) {
      var minNodes = getMinArray(n).sort();
      wrappedItems.forEach(function (wi, index) {
        DataSupplier.supplyDataAtIndex(dataKey, getTruncatedText(wi, minNodes[index]), index);
      });
    }).then(function () {
      UI.message('Success!');
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyNodesDes(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching nodes from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getNodes(apps).then(function (n) {
      var minNodes = getMinArray(n).sort().reverse();
      wrappedItems.forEach(function (wi, index) {
        DataSupplier.supplyDataAtIndex(dataKey, getTruncatedText(wi, minNodes[index]), index);
      });
    }).then(function () {
      UI.message('Success!');
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyEUMApplications(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching EUM Apps from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getEUMApplications(apps).then(function (eumApps) {
      var minEUMApps = getMinArray(eumApps).map(function (a) {
        return a.name;
      });
      wrappedItems.forEach(function (wi, index) {
        DataSupplier.supplyDataAtIndex(dataKey, getTruncatedText(wi, minEUMApps[index]), index);
      });
    }).then(function () {
      UI.message('Success!');
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyEUMApplicationsAsc(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching EUM Apps from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getEUMApplications(apps).then(function (eumApps) {
      var minEUMApps = getMinArray(eumApps).map(function (a) {
        return a.name;
      }).sort();
      wrappedItems.forEach(function (wi, index) {
        DataSupplier.supplyDataAtIndex(dataKey, getTruncatedText(wi, minEUMApps[index]), index);
      });
    }).then(function () {
      UI.message('Success!');
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyEUMApplicationsDes(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching EUM Apps from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getEUMApplications(apps).then(function (eumApps) {
      var minEUMApps = getMinArray(eumApps).map(function (a) {
        return a.name;
      }).sort().reverse();
      wrappedItems.forEach(function (wi, index) {
        DataSupplier.supplyDataAtIndex(dataKey, getTruncatedText(wi, minEUMApps[index]), index);
      });
    }).then(function () {
      UI.message('Success!');
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyEUMRequestsPerMinute(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching EUM RPM from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getEUMApplications(apps).then(function (eumApps) {
      getEUMRequestsPerMinute(eumApps).then(function (rps) {
        DataSupplier.supplyData(dataKey, getMinArray(rps));
      }).then(function () {
        UI.message('Success!');
      }).catch(function (err) {
        UI.message(err);
      });
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyEUMRequestsPerMinuteAsc(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching EUM RPM from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getEUMApplications(apps).then(function (eumApps) {
      getEUMRequestsPerMinute(eumApps).then(function (rps) {
        DataSupplier.supplyData(dataKey, getMinArray(rps).sort(sortNumbersAsc));
      }).then(function () {
        UI.message('Success!');
      }).catch(function (err) {
        UI.message(err);
      });
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyEUMRequestsPerMinuteDes(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching EUM RPM from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getEUMApplications(apps).then(function (eumApps) {
      getEUMRequestsPerMinute(eumApps).then(function (rps) {
        DataSupplier.supplyData(dataKey, getMinArray(rps).sort(sortNumbersDes));
      }).then(function () {
        UI.message('Success!');
      }).catch(function (err) {
        UI.message(err);
      });
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyEUMResponseTime(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching EUM Response Times from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getEUMApplications(apps).then(function (eumApps) {
      getEUMResponseTimes(eumApps).then(function (rps) {
        DataSupplier.supplyData(dataKey, getMinArray(rps));
      }).then(function () {
        UI.message('Success!');
      }).catch(function (err) {
        UI.message(err);
      });
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyEUMResponseTimeAsc(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching EUM Response Times from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getEUMApplications(apps).then(function (eumApps) {
      getEUMResponseTimes(eumApps).then(function (rps) {
        DataSupplier.supplyData(dataKey, getMinArray(rps).sort(sortNumbersAsc));
      }).then(function () {
        UI.message('Success!');
      }).catch(function (err) {
        UI.message(err);
      });
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyEUMResponseTimeDes(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching EUM Response Times from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getEUMApplications(apps).then(function (eumApps) {
      getEUMResponseTimes(eumApps).then(function (rps) {
        DataSupplier.supplyData(dataKey, getMinArray(rps).sort(sortNumbersDes));
      }).then(function () {
        UI.message('Success!');
      }).catch(function (err) {
        UI.message(err);
      });
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyDatabases(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching Databases from API');
  setValuesToLoading(wrappedItems);
  getDatabases().then(function (dbs) {
    var minDbs = getMinArray(dbs);
    wrappedItems.forEach(function (wi, index) {
      DataSupplier.supplyDataAtIndex(dataKey, getTruncatedText(wi, minDbs[index]), index);
    });
  }).then(function () {
    UI.message('Success!');
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyDatabasesAsc(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching Databases from API');
  setValuesToLoading(wrappedItems);
  getDatabases().then(function (dbs) {
    var minDbs = getMinArray(dbs).sort();
    wrappedItems.forEach(function (wi, index) {
      DataSupplier.supplyDataAtIndex(dataKey, getTruncatedText(wi, minDbs[index]), index);
    });
  }).then(function () {
    UI.message('Success!');
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyDatabasesDes(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching Databases from API');
  setValuesToLoading(wrappedItems);
  getDatabases().then(function (dbs) {
    var minDbs = getMinArray(dbs).sort().reverse();
    wrappedItems.forEach(function (wi, index) {
      DataSupplier.supplyDataAtIndex(dataKey, getTruncatedText(wi, minDbs[index]), index);
    });
  }).then(function () {
    UI.message('Success!');
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyDatabaseType(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching Database Types from API');
  getDatabases().then(function (dbTypes) {
    var minDBTypes = getMinArray(dbTypes);
    wrappedItems.forEach(function (wi, index) {
      DataSupplier.supplyDataAtIndex(dataKey, getTruncatedText(wi, minDBTypes[index]), index);
    });
  }).then(function () {
    UI.message('Success!');
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyDatabaseTypeAsc(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching Database Types from API');
  getDatabases().then(function (dbTypes) {
    var minDBTypes = getMinArray(dbTypes).sort();
    wrappedItems.forEach(function (wi, index) {
      DataSupplier.supplyDataAtIndex(dataKey, getTruncatedText(wi, minDBTypes[index]), index);
    });
  }).then(function () {
    UI.message('Success!');
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyDatabaseTypeDes(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching Database Types from API');
  getDatabases().then(function (dbTypes) {
    var minDBTypes = getMinArray(dbTypes).sort().reverse();
    wrappedItems.forEach(function (wi, index) {
      DataSupplier.supplyDataAtIndex(dataKey, getTruncatedText(wi, minDBTypes[index]), index);
    });
  }).then(function () {
    UI.message('Success!');
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyDatabaseCallsPerMinute(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching Database CPM from API');
  setValuesToLoading(wrappedItems);
  getDatabases().then(function (dbs) {
    getDatabaseCallsPerMinute(dbs).then(function (cpm) {
      DataSupplier.supplyData(dataKey, getMinArray(cpm));
    }).then(function () {
      UI.message('Success!');
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyDatabaseCallsPerMinuteAsc(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching Database CPM from API');
  setValuesToLoading(wrappedItems);
  getDatabases().then(function (dbs) {
    getDatabaseCallsPerMinute(dbs).then(function (cpm) {
      DataSupplier.supplyData(dataKey, getMinArray(cpm).sort(sortNumbersAsc));
    }).then(function () {
      UI.message('Success!');
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyDatabaseCallsPerMinuteDes(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching Database CPM from API');
  setValuesToLoading(wrappedItems);
  getDatabases().then(function (dbs) {
    getDatabaseCallsPerMinute(dbs).then(function (cpm) {
      DataSupplier.supplyData(dataKey, getMinArray(cpm).sort(sortNumbersDes));
    }).then(function () {
      UI.message('Success!');
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplySIMNames(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching SIM Names from API');
  setValuesToLoading(wrappedItems);
  getSIMNames().then(function (names) {
    var minNames = getMinArray(names);
    wrappedItems.forEach(function (wi, index) {
      DataSupplier.supplyDataAtIndex(dataKey, getTruncatedText(wi, minNames[index]), index);
    });
  }).then(function () {
    UI.message('Success!');
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplySIMNamesAsc(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching SIM Names from API');
  setValuesToLoading(wrappedItems);
  getSIMNames().then(function (names) {
    var minNames = getMinArray(names).sort();
    wrappedItems.forEach(function (wi, index) {
      DataSupplier.supplyDataAtIndex(dataKey, getTruncatedText(wi, minNames[index]), index);
    });
  }).then(function () {
    UI.message('Success!');
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplySIMNamesDes(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching SIM Names from API');
  setValuesToLoading(wrappedItems);
  getSIMNames().then(function (names) {
    var minNames = getMinArray(names).sort().reverse();
    wrappedItems.forEach(function (wi, index) {
      DataSupplier.supplyDataAtIndex(dataKey, getTruncatedText(wi, minNames[index]), index);
    });
  }).then(function () {
    UI.message('Success!');
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplySIMDiskUsage(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching SIM Disk Usage from API');
  setValuesToLoading(wrappedItems);
  getSIMDiskUsage().then(function (diskio) {
    DataSupplier.supplyData(dataKey, diskio);
  }).then(function () {
    UI.message('Success!');
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplySIMDiskUsageAsc(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching SIM Disk Usage from API');
  setValuesToLoading(wrappedItems);
  getSIMDiskUsage().then(function (diskio) {
    DataSupplier.supplyData(dataKey, diskio.sort(sortNumbersAsc));
  }).then(function () {
    UI.message('Success!');
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplySIMDiskUsageDes(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching SIM Disk Usage from API');
  setValuesToLoading(wrappedItems);
  getSIMDiskUsage().then(function (diskio) {
    DataSupplier.supplyData(dataKey, diskio.sort(sortNumbersDes));
  }).then(function () {
    UI.message('Success!');
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplySIMCPU(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching SIM CPU from API');
  setValuesToLoading(wrappedItems);
  getSIMCPU().then(function (cpu) {
    DataSupplier.supplyData(dataKey, cpu);
  }).then(function () {
    UI.message('Success!');
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplySIMCPUAsc(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching SIM CPU from API');
  setValuesToLoading(wrappedItems);
  getSIMCPU().then(function (cpu) {
    DataSupplier.supplyData(dataKey, cpu.sort(sortNumbersAsc));
  }).then(function () {
    UI.message('Success!');
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplySIMCPUDes(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching SIM CPU from API');
  setValuesToLoading(wrappedItems);
  getSIMCPU().then(function (cpu) {
    DataSupplier.supplyData(dataKey, cpu.sort(sortNumbersDes));
  }).then(function () {
    UI.message('Success!');
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplySIMMemory(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching SIM Memory from API');
  setValuesToLoading(wrappedItems);
  getSIMMemory().then(function (memory) {
    DataSupplier.supplyData(dataKey, memory);
  }).then(function () {
    UI.message('Success!');
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplySIMMemoryAsc(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching SIM Memory from API');
  setValuesToLoading(wrappedItems);
  getSIMMemory().then(function (memory) {
    DataSupplier.supplyData(dataKey, memory.sort(sortNumbersAsc));
  }).then(function () {
    UI.message('Success!');
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplySIMMemoryDes(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching SIM Memory from API');
  setValuesToLoading(wrappedItems);
  getSIMMemory().then(function (memory) {
    DataSupplier.supplyData(dataKey, memory.sort(sortNumbersDes));
  }).then(function () {
    UI.message('Success!');
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplySIMDiskIO(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching SIM Disk IO from API');
  setValuesToLoading(wrappedItems);
  getSIMDiskIO().then(function (diskio) {
    DataSupplier.supplyData(dataKey, diskio);
  }).then(function () {
    UI.message('Success!');
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplySIMDiskIOAsc(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching SIM Disk IO from API');
  setValuesToLoading(wrappedItems);
  getSIMDiskIO().then(function (diskio) {
    DataSupplier.supplyData(dataKey, diskio.sort(sortNumbersAsc));
  }).then(function () {
    UI.message('Success!');
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplySIMDiskIODes(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching SIM Disk IO from API');
  setValuesToLoading(wrappedItems);
  getSIMDiskIO().then(function (diskio) {
    DataSupplier.supplyData(dataKey, diskio.sort(sortNumbersDes));
  }).then(function () {
    UI.message('Success!');
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyAlertingHealthRuleNames(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching Alerting Health Rule names from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getHealthRuleNames(apps).then(function (hrns) {
      wrappedItems.forEach(function (wi, index) {
        DataSupplier.supplyDataAtIndex(dataKey, getTruncatedText(wi, hrns[index]), index);
      });
    }).then(function () {
      UI.message('Success!');
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyAlertingHealthRuleNamesAsc(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching Alerting Health Rule names from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getHealthRuleNames(apps).then(function (hrns) {
      var minHrns = getMinArray(hrns).sort();
      wrappedItems.forEach(function (wi, index) {
        DataSupplier.supplyDataAtIndex(dataKey, getTruncatedText(wi, minHrns[index]), index);
      });
    }).then(function () {
      UI.message('Success!');
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyAlertingHealthRuleNamesDes(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching Alerting Health Rule names from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getHealthRuleNames(apps).then(function (hrns) {
      var minHrns = getMinArray(hrns).sort().reverse();
      wrappedItems.forEach(function (wi, index) {
        DataSupplier.supplyDataAtIndex(dataKey, getTruncatedText(wi, minHrns[index]), index);
      });
    }).then(function () {
      UI.message('Success!');
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyAlertingPolicyNames(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching Alerting Policy names from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getPolicyNames(apps).then(function (pns) {
      wrappedItems.forEach(function (wi, index) {
        DataSupplier.supplyDataAtIndex(dataKey, getTruncatedText(wi, pns[index]), index);
      });
    }).then(function () {
      UI.message('Success!');
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyAlertingPolicyNamesAsc(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching Alerting Policy names from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getPolicyNames(apps).then(function (pns) {
      var minPns = getMinArray(pns).sort();
      wrappedItems.forEach(function (wi, index) {
        DataSupplier.supplyDataAtIndex(dataKey, getTruncatedText(wi, minPns[index]), index);
      });
    }).then(function () {
      UI.message('Success!');
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyAlertingPolicyNamesDes(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching Alerting Policy names from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getPolicyNames(apps).then(function (hrns) {
      var minPns = getMinArray(pns).sort().reverse();
      wrappedItems.forEach(function (wi, index) {
        DataSupplier.supplyDataAtIndex(dataKey, getTruncatedText(wi, minPns[index]), index);
      });
    }).then(function () {
      UI.message('Success!');
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyAlertingActionNames(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching Alerting Action names from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getActionNames(apps).then(function (ans) {
      wrappedItems.forEach(function (wi, index) {
        DataSupplier.supplyDataAtIndex(dataKey, getTruncatedText(wi, ans[index]), index);
      });
    }).then(function () {
      UI.message('Success!');
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyAlertingActionNamesAsc(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching Alerting Action names from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getActionNames(apps).then(function (ans) {
      var minAns = getMinArray(ans).sort();
      wrappedItems.forEach(function (wi, index) {
        DataSupplier.supplyDataAtIndex(dataKey, getTruncatedText(wi, minAns[index]), index);
      });
    }).then(function () {
      UI.message('Success!');
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}
function onSupplyAlertingActionNamesDes(context) {
  var dataKey = context.data.key;
  var wrappedItems = util.toArray(context.data.items).map(sketch.fromNative);
  UI.message('Fetching Alerting Action names from API');
  setValuesToLoading(wrappedItems);
  getApplications().then(function (apps) {
    getActionNames(apps).then(function (ans) {
      var minAns = getMinArray(ans).sort().reverse();
      wrappedItems.forEach(function (wi, index) {
        DataSupplier.supplyDataAtIndex(dataKey, getTruncatedText(wi, minAns[index]), index);
      });
    }).then(function () {
      UI.message('Success!');
    }).catch(function (err) {
      UI.message(err);
    });
  }).catch(function (err) {
    UI.message(err);
  });
}

/***/ }),

/***/ "./src/resources/dataMapping.js":
/*!**************************************!*\
  !*** ./src/resources/dataMapping.js ***!
  \**************************************/
/*! exports provided: dataMapping */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "dataMapping", function() { return dataMapping; });
var dataMapping = [// use '_' for nested data menu in sketch
{
  displayName: 'application_application-name--random',
  handler: 'SupplyApplications'
}, {
  displayName: 'application_application-name--asc',
  handler: 'SupplyApplicationsAsc'
}, {
  displayName: 'application_application-name--des',
  handler: 'SupplyApplicationsDes'
}, {
  displayName: 'application_response-time--random',
  handler: 'SupplyResponseTime'
}, {
  displayName: 'application_response-time--asc',
  handler: 'SupplyResponseTimeAsc'
}, {
  displayName: 'application_response-time--des',
  handler: 'SupplyResponseTimeDes'
}, {
  displayName: 'application_errors-per-minute--random',
  handler: 'SupplyErrorsPerMinute'
}, {
  displayName: 'application_errors-per-minute--asc',
  handler: 'SupplyErrorsPerMinuteAsc'
}, {
  displayName: 'application_errors-per-minute--des',
  handler: 'SupplyErrorsPerMinuteDes'
}, {
  displayName: 'application_calls-per-minute--random',
  handler: 'SupplyCallsPerMinute'
}, {
  displayName: 'application_calls-per-minute--asc',
  handler: 'SupplyCallsPerMinuteAsc'
}, {
  displayName: 'application_calls-per-minute--des',
  handler: 'SupplyCallsPerMinuteDes'
}, {
  displayName: 'application_tiers--random',
  handler: 'SupplyTiers'
}, {
  displayName: 'application_tiers--asc',
  handler: 'SupplyTiersAsc'
}, {
  displayName: 'application_tiers--des',
  handler: 'SupplyTiersDes'
}, {
  displayName: 'application_business-transactions--random',
  handler: 'SupplyBusinessTransactions'
}, {
  displayName: 'application_business-transactions--asc',
  handler: 'SupplyBusinessTransactionsAsc'
}, {
  displayName: 'application_business-transactions--des',
  handler: 'SupplyBusinessTransactionsDes'
}, {
  displayName: 'application_backends--random',
  handler: 'SupplyBackends'
}, {
  displayName: 'application_backends--asc',
  handler: 'SupplyBackendsAsc'
}, {
  displayName: 'application_backends--des',
  handler: 'SupplyBackendsDes'
}, {
  displayName: 'application_nodes--random',
  handler: 'SupplyNodes'
}, {
  displayName: 'application_nodes--asc',
  handler: 'SupplyNodesAsc'
}, {
  displayName: 'application_nodes--des',
  handler: 'SupplyNodesDes'
}, {
  displayName: 'eum_application-name--random',
  handler: 'SupplyEUMApplications'
}, {
  displayName: 'eum_application-name--asc',
  handler: 'SupplyEUMApplicationsAsc'
}, {
  displayName: 'eum_application-name--des',
  handler: 'SupplyEUMApplicationsDes'
}, {
  displayName: 'eum_requests-per-minute--random',
  handler: 'SupplyEUMRequestsPerMinute'
}, {
  displayName: 'eum_requests-per-minute--asc',
  handler: 'SupplyEUMRequestsPerMinuteAsc'
}, {
  displayName: 'eum_requests-per-minute--des',
  handler: 'SupplyEUMRequestsPerMinuteDes'
}, {
  displayName: 'eum_response-time--random',
  handler: 'SupplyEUMResponseTime'
}, {
  displayName: 'eum_response-time--asc',
  handler: 'SupplyEUMResponseTimeAsc'
}, {
  displayName: 'eum_response-time--des',
  handler: 'SupplyEUMResponseTimeDes'
}, {
  displayName: 'database_name--random',
  handler: 'SupplyDatabases'
}, {
  displayName: 'database_name--asc',
  handler: 'SupplyDatabasesAsc'
}, {
  displayName: 'database_name--des',
  handler: 'SupplyDatabasesDes'
}, {
  displayName: 'database_type--random',
  handler: 'SupplyDatabaseType'
}, {
  displayName: 'database_type--asc',
  handler: 'SupplyDatabaseType'
}, {
  displayName: 'database_type--des',
  handler: 'SupplyDatabaseType'
}, {
  displayName: 'database_calls-per-minute--asc',
  handler: 'SupplyDatabaseCallsPerMinuteAsc'
}, {
  displayName: 'database_calls-per-minute--des',
  handler: 'SupplyDatabaseCallsPerMinuteDes'
}, {
  displayName: 'database_calls-per-minute--random',
  handler: 'SupplyDatabaseCallsPerMinute'
}, {
  displayName: 'database_calls-per-minute--asc',
  handler: 'SupplyDatabaseCallsPerMinuteAsc'
}, {
  displayName: 'database_calls-per-minute--des',
  handler: 'SupplyDatabaseCallsPerMinuteDes'
}, {
  displayName: 'sim_name--random',
  handler: 'SupplySIMNames'
}, {
  displayName: 'sim_name--asc',
  handler: 'SupplySIMNamesAsc'
}, {
  displayName: 'sim_name--des',
  handler: 'SupplySIMNamesDes'
}, {
  displayName: 'sim_disk-usage--random',
  handler: 'SupplySIMDiskUsage'
}, {
  displayName: 'sim_disk-usage--asc',
  handler: 'SupplySIMDiskUsageAsc'
}, {
  displayName: 'sim_disk-usage--des',
  handler: 'SupplySIMDiskUsageDes'
}, {
  displayName: 'sim_cpu--random',
  handler: 'SupplySIMCPU'
}, {
  displayName: 'sim_cpu--asc',
  handler: 'SupplySIMCPUAsc'
}, {
  displayName: 'sim_cpu--des',
  handler: 'SupplySIMCPUDes'
}, {
  displayName: 'sim_memory--random',
  handler: 'SupplySIMMemory'
}, {
  displayName: 'sim_memory--asc',
  handler: 'SupplySIMMemoryAsc'
}, {
  displayName: 'sim_memory--des',
  handler: 'SupplySIMMemoryDes'
}, {
  displayName: 'sim_disk-io--random',
  handler: 'SupplySIMDiskIO'
}, {
  displayName: 'sim_disk-io--asc',
  handler: 'SupplySIMDiskIOAsc'
}, {
  displayName: 'sim_disk-io--des',
  handler: 'SupplySIMDiskIODes'
}, {
  displayName: 'sim_network-io--random',
  handler: 'SupplySIMNetworkIO'
}, {
  displayName: 'sim_network-io--asc',
  handler: 'SupplySIMNetworkIOAsc'
}, {
  displayName: 'sim_network-io--des',
  handler: 'SupplySIMNetworkIODes'
}, {
  displayName: 'alert-and-respond_health-rule-name--random',
  handler: 'SupplyAlertingHealthRuleNames'
}, {
  displayName: 'alert-and-respond_health-rule-name--asc',
  handler: 'SupplyAlertingHealthRuleNamesAsc'
}, {
  displayName: 'alert-and-respond_health-rule-name--des',
  handler: 'SupplyAlertingHealthRuleNamesDes'
}, {
  displayName: 'alert-and-respond_policy-name--random',
  handler: 'SupplyAlertingPolicyNames'
}, {
  displayName: 'alert-and-respond_policy-name--asc',
  handler: 'SupplyAlertingPolicyNamesAsc'
}, {
  displayName: 'alert-and-respond_policy-name--des',
  handler: 'SupplyAlertingPolicyNamesDes'
}, {
  displayName: 'alert-and-respond_action-name--random',
  handler: 'SupplyAlertingActionNames'
}, {
  displayName: 'alert-and-respond_action-name--asc',
  handler: 'SupplyAlertingActionNamesAsc'
}, {
  displayName: 'alert-and-respond_action-name--des',
  handler: 'SupplyAlertingActionNamesDes'
}];

/***/ }),

/***/ "buffer":
/*!*************************!*\
  !*** external "buffer" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("buffer");

/***/ }),

/***/ "sketch":
/*!*************************!*\
  !*** external "sketch" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch");

/***/ }),

/***/ "sketch/dom":
/*!*****************************!*\
  !*** external "sketch/dom" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/dom");

/***/ }),

/***/ "sketch/settings":
/*!**********************************!*\
  !*** external "sketch/settings" ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/settings");

/***/ }),

/***/ "sketch/ui":
/*!****************************!*\
  !*** external "sketch/ui" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("sketch/ui");

/***/ }),

/***/ "util":
/*!***********************!*\
  !*** external "util" ***!
  \***********************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("util");

/***/ })

/******/ });
  if (key === 'default' && typeof exports === 'function') {
    exports(context);
  } else {
    exports[key](context);
  }
}
that['onStartup'] = __skpm_run.bind(this, 'onStartup');
that['onShutdown'] = __skpm_run.bind(this, 'onShutdown');
that['onSupplyApplications'] = __skpm_run.bind(this, 'onSupplyApplications');
that['onSupplyApplicationsAsc'] = __skpm_run.bind(this, 'onSupplyApplicationsAsc');
that['onSupplyApplicationsDes'] = __skpm_run.bind(this, 'onSupplyApplicationsDes');
that['onSupplyResponseTime'] = __skpm_run.bind(this, 'onSupplyResponseTime');
that['onSupplyResponseTimeAsc'] = __skpm_run.bind(this, 'onSupplyResponseTimeAsc');
that['onSupplyResponseTimeDes'] = __skpm_run.bind(this, 'onSupplyResponseTimeDes');
that['onSupplyErrorsPerMinute'] = __skpm_run.bind(this, 'onSupplyErrorsPerMinute');
that['onSupplyErrorsPerMinuteAsc'] = __skpm_run.bind(this, 'onSupplyErrorsPerMinuteAsc');
that['onSupplyErrorsPerMinuteDes'] = __skpm_run.bind(this, 'onSupplyErrorsPerMinuteDes');
that['onSupplyCallsPerMinute'] = __skpm_run.bind(this, 'onSupplyCallsPerMinute');
that['onSupplyCallsPerMinuteAsc'] = __skpm_run.bind(this, 'onSupplyCallsPerMinuteAsc');
that['onSupplyCallsPerMinuteDes'] = __skpm_run.bind(this, 'onSupplyCallsPerMinuteDes');
that['onSupplyTiers'] = __skpm_run.bind(this, 'onSupplyTiers');
that['onSupplyTiersAsc'] = __skpm_run.bind(this, 'onSupplyTiersAsc');
that['onSupplyTiersDes'] = __skpm_run.bind(this, 'onSupplyTiersDes');
that['onSupplyBusinessTransactions'] = __skpm_run.bind(this, 'onSupplyBusinessTransactions');
that['onSupplyBusinessTransactionsAsc'] = __skpm_run.bind(this, 'onSupplyBusinessTransactionsAsc');
that['onSupplyBusinessTransactionsDes'] = __skpm_run.bind(this, 'onSupplyBusinessTransactionsDes');
that['onSupplyBackends'] = __skpm_run.bind(this, 'onSupplyBackends');
that['onSupplyBackendsAsc'] = __skpm_run.bind(this, 'onSupplyBackendsAsc');
that['onSupplyBackendsDes'] = __skpm_run.bind(this, 'onSupplyBackendsDes');
that['onSupplyNodes'] = __skpm_run.bind(this, 'onSupplyNodes');
that['onSupplyNodesAsc'] = __skpm_run.bind(this, 'onSupplyNodesAsc');
that['onSupplyNodesDes'] = __skpm_run.bind(this, 'onSupplyNodesDes');
that['onSupplyEUMApplications'] = __skpm_run.bind(this, 'onSupplyEUMApplications');
that['onSupplyEUMApplicationsAsc'] = __skpm_run.bind(this, 'onSupplyEUMApplicationsAsc');
that['onSupplyEUMApplicationsDes'] = __skpm_run.bind(this, 'onSupplyEUMApplicationsDes');
that['onSupplyEUMRequestsPerMinute'] = __skpm_run.bind(this, 'onSupplyEUMRequestsPerMinute');
that['onSupplyEUMRequestsPerMinuteAsc'] = __skpm_run.bind(this, 'onSupplyEUMRequestsPerMinuteAsc');
that['onSupplyEUMRequestsPerMinuteDes'] = __skpm_run.bind(this, 'onSupplyEUMRequestsPerMinuteDes');
that['onSupplyEUMResponseTime'] = __skpm_run.bind(this, 'onSupplyEUMResponseTime');
that['onSupplyEUMResponseTimeAsc'] = __skpm_run.bind(this, 'onSupplyEUMResponseTimeAsc');
that['onSupplyEUMResponseTimeDes'] = __skpm_run.bind(this, 'onSupplyEUMResponseTimeDes');
that['onSupplyDatabases'] = __skpm_run.bind(this, 'onSupplyDatabases');
that['onSupplyDatabasesAsc'] = __skpm_run.bind(this, 'onSupplyDatabasesAsc');
that['onSupplyDatabasesDes'] = __skpm_run.bind(this, 'onSupplyDatabasesDes');
that['onSupplyDatabaseType'] = __skpm_run.bind(this, 'onSupplyDatabaseType');
that['onSupplyDatabaseTypeAsc'] = __skpm_run.bind(this, 'onSupplyDatabaseTypeAsc');
that['onSupplyDatabaseTypeDes'] = __skpm_run.bind(this, 'onSupplyDatabaseTypeDes');
that['onSupplyDatabaseCallsPerMinute'] = __skpm_run.bind(this, 'onSupplyDatabaseCallsPerMinute');
that['onSupplyDatabaseCallsPerMinuteAsc'] = __skpm_run.bind(this, 'onSupplyDatabaseCallsPerMinuteAsc');
that['onSupplyDatabaseCallsPerMinuteDes'] = __skpm_run.bind(this, 'onSupplyDatabaseCallsPerMinuteDes');
that['onSupplySIMNames'] = __skpm_run.bind(this, 'onSupplySIMNames');
that['onSupplySIMNamesDes'] = __skpm_run.bind(this, 'onSupplySIMNamesDes');
that['onSupplySIMNamesAsc'] = __skpm_run.bind(this, 'onSupplySIMNamesAsc');
that['onSupplySIMDiskUsage'] = __skpm_run.bind(this, 'onSupplySIMDiskUsage');
that['onSupplySIMDiskUsageAsc'] = __skpm_run.bind(this, 'onSupplySIMDiskUsageAsc');
that['onSupplySIMDiskUsageDes'] = __skpm_run.bind(this, 'onSupplySIMDiskUsageDes');
that['onSupplySIMCPU'] = __skpm_run.bind(this, 'onSupplySIMCPU');
that['onSupplySIMCPUAsc'] = __skpm_run.bind(this, 'onSupplySIMCPUAsc');
that['onSupplySIMCPUDes'] = __skpm_run.bind(this, 'onSupplySIMCPUDes');
that['onSupplySIMMemory'] = __skpm_run.bind(this, 'onSupplySIMMemory');
that['onSupplySIMMemoryAsc'] = __skpm_run.bind(this, 'onSupplySIMMemoryAsc');
that['onSupplySIMMemoryDes'] = __skpm_run.bind(this, 'onSupplySIMMemoryDes');
that['onSupplySIMDiskIO'] = __skpm_run.bind(this, 'onSupplySIMDiskIO');
that['onSupplySIMDiskIOAsc'] = __skpm_run.bind(this, 'onSupplySIMDiskIOAsc');
that['onSupplySIMDiskIODes'] = __skpm_run.bind(this, 'onSupplySIMDiskIODes');
that['onSupplySIMNetworkIO'] = __skpm_run.bind(this, 'onSupplySIMNetworkIO');
that['onSupplySIMNetworkIOAsc'] = __skpm_run.bind(this, 'onSupplySIMNetworkIOAsc');
that['onSupplySIMNetworkIODes'] = __skpm_run.bind(this, 'onSupplySIMNetworkIODes');
that['onSupplyAlertingHealthRuleNames'] = __skpm_run.bind(this, 'onSupplyAlertingHealthRuleNames');
that['onSupplyAlertingHealthRuleNamesAsc'] = __skpm_run.bind(this, 'onSupplyAlertingHealthRuleNamesAsc');
that['onSupplyAlertingHealthRuleNamesDes'] = __skpm_run.bind(this, 'onSupplyAlertingHealthRuleNamesDes');
that['onSupplyAlertingPolicyNames'] = __skpm_run.bind(this, 'onSupplyAlertingPolicyNames');
that['onSupplyAlertingPolicyNamesAsc'] = __skpm_run.bind(this, 'onSupplyAlertingPolicyNamesAsc');
that['onSupplyAlertingPolicyNamesDes'] = __skpm_run.bind(this, 'onSupplyAlertingPolicyNamesDes');
that['onSupplyAlertingActionNames'] = __skpm_run.bind(this, 'onSupplyAlertingActionNames');
that['onSupplyAlertingActionNamesAsc'] = __skpm_run.bind(this, 'onSupplyAlertingActionNamesAsc');
that['onSupplyAlertingActionNamesDes'] = __skpm_run.bind(this, 'onSupplyAlertingActionNamesDes');
that['onRun'] = __skpm_run.bind(this, 'default')

//# sourceMappingURL=index.js.map