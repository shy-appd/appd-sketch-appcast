/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./resources/webview.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./node_modules/@babel/runtime/helpers/arrayLikeToArray.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/arrayLikeToArray.js ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _arrayLikeToArray(arr, len) {
  if (len == null || len > arr.length) len = arr.length;

  for (var i = 0, arr2 = new Array(len); i < len; i++) {
    arr2[i] = arr[i];
  }

  return arr2;
}

module.exports = _arrayLikeToArray;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/arrayWithoutHoles.js":
/*!******************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/arrayWithoutHoles.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var arrayLikeToArray = __webpack_require__(/*! ./arrayLikeToArray */ "./node_modules/@babel/runtime/helpers/arrayLikeToArray.js");

function _arrayWithoutHoles(arr) {
  if (Array.isArray(arr)) return arrayLikeToArray(arr);
}

module.exports = _arrayWithoutHoles;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/iterableToArray.js":
/*!****************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/iterableToArray.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _iterableToArray(iter) {
  if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter);
}

module.exports = _iterableToArray;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/nonIterableSpread.js":
/*!******************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/nonIterableSpread.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _nonIterableSpread() {
  throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
}

module.exports = _nonIterableSpread;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/toConsumableArray.js":
/*!******************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/toConsumableArray.js ***!
  \******************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var arrayWithoutHoles = __webpack_require__(/*! ./arrayWithoutHoles */ "./node_modules/@babel/runtime/helpers/arrayWithoutHoles.js");

var iterableToArray = __webpack_require__(/*! ./iterableToArray */ "./node_modules/@babel/runtime/helpers/iterableToArray.js");

var unsupportedIterableToArray = __webpack_require__(/*! ./unsupportedIterableToArray */ "./node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js");

var nonIterableSpread = __webpack_require__(/*! ./nonIterableSpread */ "./node_modules/@babel/runtime/helpers/nonIterableSpread.js");

function _toConsumableArray(arr) {
  return arrayWithoutHoles(arr) || iterableToArray(arr) || unsupportedIterableToArray(arr) || nonIterableSpread();
}

module.exports = _toConsumableArray;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js":
/*!***************************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/unsupportedIterableToArray.js ***!
  \***************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var arrayLikeToArray = __webpack_require__(/*! ./arrayLikeToArray */ "./node_modules/@babel/runtime/helpers/arrayLikeToArray.js");

function _unsupportedIterableToArray(o, minLen) {
  if (!o) return;
  if (typeof o === "string") return arrayLikeToArray(o, minLen);
  var n = Object.prototype.toString.call(o).slice(8, -1);
  if (n === "Object" && o.constructor) n = o.constructor.name;
  if (n === "Map" || n === "Set") return Array.from(n);
  if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return arrayLikeToArray(o, minLen);
}

module.exports = _unsupportedIterableToArray;

/***/ }),

/***/ "./resources/webview.js":
/*!******************************!*\
  !*** ./resources/webview.js ***!
  \******************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/toConsumableArray */ "./node_modules/@babel/runtime/helpers/toConsumableArray.js");
/* harmony import */ var _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0__);

// disable the context menu (eg. the right click menu) to have a more native feel
// document.addEventListener('contextmenu', (e) => {
//   e.preventDefault()
// })
var spinnerEl = document.querySelector('.spinner-grow');
var statusTable = document.querySelector('.components table');
var typographyTable = document.querySelector('.typography table');
var colorTable = document.querySelector('.colors table');
var bodyEl = document.querySelector('body');
var iframe = document.querySelector('iframe');
var noResultEl = document.querySelector('.noResults');
var tabs = document.querySelectorAll('.nav-item');
var componentsEl = document.querySelector('.components');
var typographyEl = document.querySelector('.typography');
var colorsEl = document.querySelector('.colors');
var complianceEl = document.querySelector('.compliance');
var redlineEl = document.querySelector('.redline');
var redlineButton = document.querySelector('.redline .btn');
var redlineCheckboxes = document.querySelectorAll('.redline input[type=checkbox]');
iframe.style.display = 'none';

function renderComponent(component) {
  var row = document.createElement("tr");
  var nameTd = document.createElement("td");
  var statusTd = document.createElement("td");
  var storyTd = document.createElement("td");
  var specTd = document.createElement("td");
  var storyA = document.createElement("a");
  var specA = document.createElement("a");
  row.appendChild(nameTd);
  row.appendChild(statusTd);
  row.appendChild(storyTd);
  row.appendChild(specTd);
  storyTd.appendChild(storyA);
  specTd.appendChild(specA);
  nameTd.innerHTML = component.uiKitName;
  storyA.href = "#";
  storyA.innerHTML = component.storyBook ? "Storybook" : "";
  storyA.addEventListener('click', function (e) {
    e.preventDefault();
    statusTable.style.maxHeight = '400px';
    iframe.style.height = '800px';
    iframe.style.width = '100%';
    iframe.style.display = 'block';
    iframe.src = component.storyBook;
  });
  specA.href = "#";
  specA.innerHTML = component.designSpec ? "Spec." : "";
  specA.addEventListener('click', function (e) {
    e.preventDefault();
    window.postMessage('showAbstractSpec', {
      fileId: component.fileId,
      componentName: component.uiKitName
    });
  });

  if (component.status) {
    switch (component.status) {
      case "Released":
        statusTd.innerHTML = "<span class=\"badge badge-success\">".concat(component.status, "</span>");
        break;

      case "Not Started":
        statusTd.innerHTML = "<span class=\"badge badge-warning\">".concat(component.status, "</span>");
        break;

      case "Alpha":
        statusTd.innerHTML = "<span class=\"badge badge-success\">".concat(component.status, "</span>");
        break;

      case "Design Completed":
        statusTd.innerHTML = "<span class=\"badge badge-warning\">".concat(component.status, "</span>");
        break;

      case "Not in Particle":
        statusTd.innerHTML = "<span class=\"badge badge-danger\">".concat(component.status, "</span>");
        break;

      default:
        statusTd.innerHTML = "<span class=\"badge badge-info\">NOT FOUND</span>";
        break;
    }
  } else {
    statusTd.innerHTML = "<span class=\"badge badge-danger\">NOT FOUND</span>";
  }

  statusTable.querySelector('tbody').appendChild(row);
}

function renderTypograhy(typography) {
  var row = document.createElement("tr");
  var nameTd = document.createElement("td");
  var specTd = document.createElement("td"); // const mixinTd = document.createElement("td");

  var specA = document.createElement("a");
  row.appendChild(nameTd);
  row.appendChild(specTd); // row.appendChild(mixinTd);

  specTd.appendChild(specA);
  nameTd.innerHTML = typography.particleName; // mixinTd.innerHTML = typography.mixin;

  specA.href = "#";
  specA.innerHTML = "Spec.";
  specA.addEventListener('click', function (e) {
    e.preventDefault();
    window.postMessage('showAbstractSpec', {
      fileId: typography.fileId,
      componentName: "Typography"
    });
  });
  typographyTable.querySelector('tbody').appendChild(row);
}

function renderColor(color) {
  var row = document.createElement("tr");
  var nameTd = document.createElement("td");
  var specTd = document.createElement("td");
  var specA = document.createElement("a");
  row.appendChild(nameTd);
  row.appendChild(specTd);
  specTd.appendChild(specA);
  nameTd.innerHTML = color.particleName;
  specA.href = "#";
  specA.innerHTML = "Spec.";
  specA.addEventListener('click', function (e) {
    e.preventDefault();
    window.postMessage('showAbstractSpec', {
      fileId: color.fileId,
      componentName: "Colors"
    });
  });
  colorTable.querySelector('tbody').appendChild(row);
}

function renderMetrics(searched, components, typography, colors) {
  var searchedEl = document.querySelector('.metrics__searched');
  var componentsFound = document.querySelector('.metrics__components');
  var typographyFound = document.querySelector('.metrics__typography');
  var colorsFound = document.querySelector('.metrics__colors');
  searchedEl.innerHTML = searched;
  componentsFound.innerHTML = components;
  typographyFound.innerHTML = typography;
  colorsFound.innerHTML = colors;
}

function renderCompliance(components) {
  var compliancePercent = document.createElement('h1');
  complianceEl.appendChild(compliancePercent);
  compliancePercent.innerHTML = "".concat((components.filter(function (c) {
    return c !== false;
  }).length / components.length * 100).toFixed(0), "%");
}

function showSpinner() {
  componentsEl.style.display = "none";
  typographyEl.style.display = "none";
  colorsEl.style.display = "none";
  spinnerEl.style.display = "block";
}

function hideSpinner() {
  componentsEl.style.display = "block";
  spinnerEl.style.display = "none";
}

function renderError(error) {
  componentsEl.style.display = "none";
  typographyEl.style.display = "none";
  colorsEl.style.display = "none";
  bodyEl.innerHTML = error;
}

function renderNoResults() {
  componentsEl.style.display = "none";
  typographyEl.style.display = "none";
  colorsEl.style.display = "none";
  noResultEl.style.display = 'block';
}

function initiateTabs() {
  tabs.forEach(function (tab) {
    tab.addEventListener('click', function (e) {
      e.preventDefault();
      removeAllActives();
      var link = e.target;
      if (!link.classList.contains('active')) link.classList.add('active');

      if (link.innerHTML === 'Components') {
        componentsEl.style.display = "block";
        typographyEl.style.display = "none";
        colorsEl.style.display = "none";
        complianceEl.style.display = "none";
        redlineEl.style.display = "none";
      } else if (link.innerHTML === 'Typography') {
        componentsEl.style.display = "none";
        typographyEl.style.display = "block";
        colorsEl.style.display = "none";
        complianceEl.style.display = "none";
        redlineEl.style.display = "none";
      } else if (link.innerHTML === 'Compliance') {
        componentsEl.style.display = "none";
        typographyEl.style.display = "none";
        colorsEl.style.display = "none";
        complianceEl.style.display = "block";
        redlineEl.style.display = "none";
      } else if (link.innerHTML === 'Redline') {
        componentsEl.style.display = "none";
        typographyEl.style.display = "none";
        colorsEl.style.display = "none";
        complianceEl.style.display = "none";
        redlineEl.style.display = "block";
      } else {
        componentsEl.style.display = "none";
        typographyEl.style.display = "none";
        colorsEl.style.display = "block";
        complianceEl.style.display = "none";
        redlineEl.style.display = "none";
      }
    });
  });

  function removeAllActives() {
    tabs.forEach(function (tab) {
      var link = tab.querySelector('a');
      link.classList.remove('active');
    });
  }
}

window.renderStatus = function (_ref) {
  var symbolInstances = _ref.symbolInstances,
      components = _ref.components,
      typography = _ref.typography,
      colors = _ref.colors;
  var componentsApiUrl = "http://particlecms-1357493818.us-west-2.elb.amazonaws.com:1337/component-pages"; // const fontTokensApiUrl = "http://particlecms-1357493818.us-west-2.elb.amazonaws.com:1337/design-tokens?type_eq=text";

  var uniqueUiKitComponents = _babel_runtime_helpers_toConsumableArray__WEBPACK_IMPORTED_MODULE_0___default()(new Set(components.map(function (c) {
    return c.uiKitName;
  }))).sort();

  var totalSearched = parseInt(components.length) + parseInt(typography.length) + parseInt(colors.length);
  var rComponents = [];
  initiateTabs();
  showSpinner();
  fetch(componentsApiUrl).then(function (response) {
    return response.json();
  }).then(function (uiKitComponents) {
    hideSpinner();
    renderMetrics(totalSearched, uniqueUiKitComponents.filter(function (c) {
      return c !== undefined;
    }).length, typography.filter(function (t) {
      return t !== null && t !== undefined;
    }).length, colors.filter(function (t) {
      return t !== null && t !== undefined;
    }).length);
    renderCompliance(components);

    if (uniqueUiKitComponents.length > 0) {
      uniqueUiKitComponents.forEach(function (c) {
        if (c !== null && c !== undefined && c !== false) {
          var uiKitComponent = uiKitComponents.find(function (comp) {
            return c === comp.slug;
          });
          var rComponent = {
            uiKitName: c,
            fileId: components.filter(function (co) {
              return co.uiKitName === c;
            })[0].fileId,
            status: uiKitComponent ? uiKitComponent.componentStatus : null,
            storyBook: uiKitComponent ? "https://particle.appdynamics.com".concat(uiKitComponent.storybookUrl) : null,
            designSpec: uiKitComponent ? uiKitComponent.designSpec : null,
            uiKitSource: uiKitComponent ? uiKitComponent.uiKitSource : null
          };
          renderComponent(rComponent);
          rComponents.push(rComponent);
        }
      });
    } else {
      renderNoResults();
    }
  }) // .then(() => {
  // 	return fetch(fontTokensApiUrl)
  // 					.then(response => response.json())
  // })
  .then(function () {
    if (typography.length > 0) {
      typography.forEach(function (t) {
        if (t && t !== null) {
          // const token = designTokens.find(dt => dt.mixin.includes(t.particleName));
          // const temp = {
          // 	...t,
          // 	mixin: token.mixin === null ? "" : token.mixin
          // };
          renderTypograhy(t);
        }
      });
    }

    if (colors.length > 0) {
      colors.forEach(function (c) {
        if (c && c !== null && c !== undefined) renderColor(c);
      });
    }

    redlineButton.addEventListener('click', function (e) {
      e.preventDefault();
      var checkboxes = [];
      redlineCheckboxes.forEach(function (c) {
        checkboxes.push({
          name: c.name,
          checked: c.checked
        });
      });
      window.postMessage('renderRedlines', {
        components: rComponents,
        checkboxes: checkboxes
      });
    });
  }).catch(function (error) {
    hideSpinner();
    renderError(error);
  });
};

/***/ })

/******/ });
//# sourceMappingURL=resources_webview.js.map