/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./resources/webview.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./resources/webview.js":
/*!******************************!*\
  !*** ./resources/webview.js ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

// disable the context menu (eg. the right click menu) to have a more native feel
// document.addEventListener('contextmenu', (e) => {
//   e.preventDefault()
// })
var primaryButton = document.querySelector('.btn-primary');
var cancelButton = document.querySelector('.btn-link');
var entitySelect = document.querySelector('#dataSet__entities_entity');
var metricSelect = document.querySelector('#dataSet__metrics_metric');
var timeSelect = document.querySelector('#dataSet__timeSelect');
var timeStart = document.querySelector('#dataSet__timeStart');
var timeEnd = document.querySelector('#dataSet__timeEnd');
var dataSetContainer = document.querySelector('.dataSet');
var dataSetCount = document.querySelector('#dataSet__count');
var dataSetPoints = document.querySelector('#dataSet__points');
var hintTexts = document.querySelectorAll('.text-muted');
var entityOptions = [{
  value: 'application',
  displayName: 'Applications',
  metrics: [{
    value: 'memory',
    displayName: 'Memory (%)'
  }, {
    value: 'cpu',
    displayName: 'CPU (%)'
  }, {
    value: 'cpm',
    displayName: 'Calls per minute'
  }, {
    value: 'epm',
    displayName: 'Errors per minute'
  }, {
    value: 'responseTime',
    displayName: 'Response Time (ms)'
  }]
}, {
  value: 'server',
  displayName: 'Servers',
  metrics: [{
    value: 'memory',
    displayName: 'Memory (%)'
  }, {
    value: 'cpu',
    displayName: 'CPU (%)'
  }]
}, {
  value: 'bt',
  displayName: 'Business Transactions',
  metrics: [{
    value: 'responseTime',
    displayName: 'Response Time (ms)'
  }, {
    value: 'cpm',
    displayName: 'Calls per minute'
  }, {
    value: 'epm',
    displayName: 'Errors per minute'
  }]
}, {
  value: 'database',
  displayName: 'Databases',
  metrics: [{
    value: 'cpu',
    displayName: 'CPU (%)'
  }, {
    value: 'queries',
    displayName: 'Queries'
  }]
}];
var timeOptions = [{
  granularity: 'Hours',
  options: [],
  selected: true
}, {
  granularity: 'Days',
  options: [],
  selected: false
}];
entityOptions.forEach(function (o, i) {
  var option = document.createElement('option');
  option.text = o.displayName;
  option.value = o.value;
  entitySelect.add(option, i);
});
entityOptions.find(function (o) {
  return o.value === entitySelect.value;
}).metrics.forEach(function (o, i) {
  var option = document.createElement('option');
  option.text = o.displayName;
  option.value = o.value;
  metricSelect.add(option, i);
});
timeOptions.forEach(function (o, i) {
  var option = document.createElement('option');
  option.text = o.granularity;
  option.value = o.granularity;
  option.selected = o.selected;
  timeSelect.add(option, i);
});
primaryButton.addEventListener('click', function (e) {
  var selectedOptions = {
    entity: entitySelect.value,
    metric: metricSelect.value,
    dataPoints: dataSetPoints.value,
    dataSets: dataSetCount.value,
    timeType: timeSelect.value,
    timeStart: timeStart.value,
    timeEnd: timeEnd.value
  };
  window.postMessage('onApply', selectedOptions);
});
cancelButton.addEventListener('click', function (e) {
  window.postMessage('close');
});
entitySelect.addEventListener('change', function () {
  return handleEntityChange();
});
timeSelect.addEventListener('change', function () {
  return handleTimeChange();
});

function handleEntityChange() {
  document.querySelectorAll('#dataSet__metrics_metric option').forEach(function (o) {
    return o.remove();
  });
  entityOptions.find(function (o) {
    return o.value === entitySelect.value;
  }).metrics.forEach(function (o, i) {
    var option = document.createElement('option');
    option.text = o.displayName;
    option.value = o.value;
    metricSelect.add(option, i);
  });
}

function handleTimeChange() {
  if (timeSelect.value === 'Hours') {
    timeStart.value = "0600";
    timeEnd.value = "1800";
    hintTexts.forEach(function (ht) {
      ht.innerHTML = "HHMM (24 Hr)";
    });
  } else {
    timeStart.value = "05/01/20";
    timeEnd.value = "05/06/20";
    hintTexts.forEach(function (ht) {
      ht.innerHTML = "MM/DD/YY";
    });
  }
}

window.showAppropriateFields = function (visualizationType) {
  switch (visualizationType) {
    case 'column-chart':
    default:
      return;
  }
};

/***/ })

/******/ });
//# sourceMappingURL=resources_webview.js.map